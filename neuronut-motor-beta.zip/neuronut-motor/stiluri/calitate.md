# Podeaua tehnică: obligatorie pe orice stil
Regulile de aici sunt tehnice. Fără ele reel-ul e stricat, oricare ar fi stilul.
Estetica vine din rețeta omului, `fundament/reteta-montaj.md`: tipul și mărimea tranzițiilor, zoom-ul, fonturile, mărimile, locul subtitrărilor, pragurile de tăiere. Dacă rețeta nu există, estetica vine din stilul ales (`stiluri/`). La conflict pe estetică, câștigă rețeta.

## Cadrul
- Niciodată deformat. Raportul de aspect se păstrează. Dacă sursa nu e 9:16, se decupează (crop) centrat pe față. Nu se întinde și nu se umple prin oglindire.
- Decuparea urmărește fața, nu centrul geometric. Fața nu e tăiată de marginea cadrului.
- Fără salt de încadrare (cadrul care sare instant la altă mărime pe o tăietură).

## Textul
- Poziția textului se calculează pe cadrele reale (`faces.json` din `face_zones.py`). Omul se mișcă, deci textul se verifică pe toate cadrele în care apare, nu pe primul.
- NICIODATĂ pe față, pe gură sau pe mâini. Zona feței merge de la păr (+45 % din înălțimea feței) până sub bărbie (+25 %).
- Zonele moarte ale platformei: nimic sub 85 % din înălțime (butoanele Instagram) și nimic în primii 8 % (bara de sus).
- Textul se citește pe telefon: contrast de cel puțin 3:1 față de fundal, nimic tăiat de marginea cadrului. Dacă nu încape, se scurtează textul, nu se micșorează sub mărimea din rețetă sau din stil.
- Nu Montserrat, nu Impact, nu Arial. Fonturile vin din rețetă, din stil sau din pachet (Fraunces, Space Grotesk).
- Diacritice corecte. Cuvintele omului se scriu cum le scrie el.

## Tăieturile
- **Nicio literă pierdută.** Nu tai niciodată în interiorul unui cuvânt: la fiecare tăietură, vocea a coborât sub −45 dB. Dacă e de ales între a tăia o literă și a păstra 0,3 s în plus, păstrezi. „Spoiler”, nu „poiler”; „zece”, nu „ece”.
- **Nicio frază tăiată înainte să se termine.** Bucata se închide la sfârșitul propoziției.
- **Pauzele ies.** Respirațiile, gândirea, umpluturile, cuvintele duble și luările repetate ies. Pragurile exacte sunt în rețetă sau în stil.
- **Niciun cadru înghețat.** Un B-roll nu e mai scurt decât bucata lui; bucățile nu trec de lungimea clipului.
- **Asculți rezultatul**, nu doar te uiți la cadre: nu rămân respirații între tăieturi.

## Montajul după sens (regulile Elenei, 18 noiembrie 2026, la fiecare montaj)
1. **O singură variantă pe idee.** Când omul spune aceeași idee de mai multe ori, rămâne o singură variantă: cea mai clară și completă, de obicei ultima, pentru că omul se corectează după ce greșește. Bâlbâielile, frazele începute și reluate și variantele greșite ale poveștii ies toate. Unești după sens, nu după ordinea filmării.
2. **Toate pauzele ies**, fără excepție.
3. **Tranziție între idei**: fiecare idee nouă începe cu o tranziție. Secundele ideilor intră în lista `"idei"` din cuts.json, iar render.py taie respirația și pune alunecarea.
4. **Ce a adăugat omul cu vorbele lui rămâne**, chiar dacă nu era în script. Scriptul e harta, nu cușca: tai doar repetiții, variante greșite, bâlbâieli și pauze, niciodată un sens nou spus de om.

## Tranzițiile
- **La fiecare idee nouă există o tranziție vizibilă**, oricare ar fi unealta, termenul sau tipul montajului. Elena, 25.11: „ține minte asta o dată și pentru totdeauna, pentru toate reel-urile”. O idee nouă = hook-ul, fiecare rehook, CTA-ul sau o temă nouă în vorbire. Un reel fără tranziții se vede ca o singură bucată și arată neîngrijit.
- Tipul, durata și sunetul tranziției vin din rețetă sau din stil. Implicit e alunecarea: cadrul vechi iese spre stânga, cel nou intră din dreapta, cu blur de mișcare, în 0,4 s. O face `scripts/efecte.py`, iar `render.py` o pune singur.
- Fără flash alb sau de lumină, fără margini oglindite, fără clipiri la fiecare intrare de B-roll sau de panou.

## Sunetul
- Fără sunete sintetizate de script. Efectele vin din biblioteca omului (CapCut sau `inbox/sfx/`).
- Niciun efect nu cade peste cuvinte: efectele stau în pauze sau după cuvânt.
- Muzică doar dacă omul pune o piesă în `inbox/muzica/` sau alege una din biblioteca lui. Nu se descarcă muzică de pe net. Nimic nu acoperă vocea.
- Vocea rămâne a lui: doar curățată de zgomot și adusă la −14 LUFS, fără compresor care o îngroașă.

## Ce nu faci niciodată (3 noiembrie)
- Nu livrezi varianta de verificare ca final: finalul e `reel-final.mp4`, 1080×1920, randat fără `--preview`. Varianta de verificare (`reel-preview.mp4`, 540×960) e doar pentru feedback.
- Nu refaci clipul mare după o corectură: corecturile se fac pe varianta de verificare, finalul o singură dată.
- Nu ghicești între două sunete: arăți cuvintele cu timpii lor și întrebi o dată.
- Nu scoți o frază rostită și n-o înlocuiești cu text: cauți luarea bună în toate clipurile (`find_take.py`) sau ceri refilmarea frazei.
- Nu promiți „30 de minute” fără să fi verificat: spui timpul după ce știi ce randezi.

## Verificarea înainte de livrare (obligatorie)
1. Citești transcrierea bucăților păstrate, de la cap la coadă, ca un spectator. Nicio frază nu se repetă, nicio variantă greșită n-a rămas și nimic din ce a adăugat omul cu sensul lui n-a fost tăiat.
2. Extragi cadre la 10 %, 35 %, 60 % și 85 % din durată, plus un cadru din mijlocul unei tranziții, și te uiți la ele. Fața e întreagă și nedeformată? Textul stă departe de față, gură și mâini? Tranziția se vede?
3. Numeri tranzițiile: cel puțin una la fiecare idee nouă.
4. Transformi din nou în text sunetul final, pe bucăți de ~15 s, cu context înainte. Nicio pauză rămasă, toate finalurile de cuvânt întregi.
5. Dacă oricare răspuns e „nu”, repari înainte să trimiți. Nu livrezi ce n-ai văzut.
6. Apoi îi spui omului pe scurt ce ai tăiat și unde (secunde din filmarea originală), în 3–6 rânduri.
