#!/usr/bin/env python3
"""Efectele de montaj aprobate de Elena, într-un singur loc, ca fiecare reel să le folosească pe aceleași.
Valorile vin din rețetă (fundament/reteta-montaj.md, §1) și din codul reperului R18 1.4–1.6 (push + mblur).

Alunecarea: la fiecare schimbare de cadru și la fiecare idee nouă, cadrul vechi iese spre stânga, cel nou intră
din dreapta, cu blur de mișcare orizontal, în 0,4 s centrate pe tăietură. Înainte de tăietură se mișcă imaginea
veche, iar noua stă pe primul ei cadru; după tăietură, invers. Durata videoului nu se schimbă, deci subtitrările
rămân sincronizate. Fără flash și fără margini oglindite: se folosesc doar cadre reale.

Folosire:
  python3 scripts/efecte.py alunecare <in.mp4> <out.mp4> --la 3.20,8.75 [--durata 0.4] [--blur 160]
Din alt script:
  from efecte import alunecare; alunecare(src, dst, [3.20, 8.75], enc_args=[...])
"""
import argparse, json, math, subprocess, sys

ALUNECARE = {"durata_s": 0.4, "blur_max_px": 160}   # rețeta §1 (măsurat la R18: ±6 cadre la 30 fps, blur ≤ 160 px la 1080 lățime)


def _probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate",
                          "-of", "json", path], capture_output=True, text=True, check=True).stdout
    s = json.loads(out)["streams"][0]
    num, den = s["r_frame_rate"].split("/")
    return int(s["width"]), int(s["height"]), float(num) / float(den or 1)


def _has_audio(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", path],
                         capture_output=True, text=True).stdout.strip()
    return bool(out)


def _ez(u):
    """curbă lină la intrare și la ieșire (aceeași ca la R18)"""
    return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2


def _push(A, B, p):
    """cadrul vechi (A) pleacă spre stânga, cel nou (B) intră din dreapta; p = 0…1 din lățime"""
    import numpy as np
    out = []
    for a, b in zip(A, B):
        w = a.shape[1]; s = int(round(w * p)); o = np.empty_like(a)
        o[:, :w - s] = a[:, s:]; o[:, w - s:] = b[:, :s]
        out.append(o)
    return out


def _mblur(planes, L):
    """blur de mișcare orizontal: L pixeli pe luminanță, jumătate pe culoare"""
    import cv2
    if L < 3: return planes
    return [cv2.blur(planes[0], (int(L), 1))] + [cv2.blur(p, (max(1, int(L // 2)), 1)) for p in planes[1:]]


def alunecare(src, dst, la, enc_args=None, durata=None, blur_max=None, log=True):
    """Pune alunecarea la fiecare moment din `la` (secunde, pe cronologia videoului `src`). Întoarce câte a pus."""
    import numpy as np
    durata = ALUNECARE["durata_s"] if durata is None else durata
    blur_max = ALUNECARE["blur_max_px"] if blur_max is None else blur_max
    W, H, fps = _probe(src)
    pw = max(1, int(round(durata * fps / 2)))                       # jumătate de tranziție, în cadre (0,2 s → 6 la 30 fps)
    blur_cap = blur_max * W / 1080.0                                 # la varianta de verificare (540 lățime) blurul scade proporțional
    # tăieturile, pe cadre întregi; două alunecări nu se suprapun
    marks = []
    for t in sorted(float(x) for x in la):
        m = int(math.ceil(t * fps - 1e-3))                         # primul cadru cu imaginea nouă (timpul lui ≥ momentul tăieturii)
        if m - pw < 1: continue
        if marks and m - marks[-1] < 2 * pw: continue
        marks.append(m)
    if enc_args is None:
        enc_args = ["-c:v", "libx264", "-preset", "medium", "-crf", "17"]
    YS, CS = W * H, (W // 2) * (H // 2); FS = YS + 2 * CS
    dec = subprocess.Popen(["ffmpeg", "-v", "error", "-i", src, "-f", "rawvideo", "-pix_fmt", "yuv420p", "-"], stdout=subprocess.PIPE)
    audio = ["-i", src, "-map", "0:v", "-map", "1:a", "-c:a", "copy"] if _has_audio(src) else ["-map", "0:v"]
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "yuv420p", "-s", f"{W}x{H}", "-r", f"{fps:.6f}", "-i", "-"]
                           + audio + enc_args + ["-pix_fmt", "yuv420p", "-movflags", "+faststart", dst], stdin=subprocess.PIPE)

    def planes(b):
        a = np.frombuffer(b, np.uint8)
        return [a[:YS].reshape(H, W), a[YS:YS + CS].reshape(H // 2, W // 2), a[YS + CS:].reshape(H // 2, W // 2)]

    buf, last, n_read, n_out, eof, done = {}, {}, 0, 0, False, 0
    while True:
        while not eof and n_read <= n_out + pw + 1:              # citim înainte cât să avem primul cadru de după tăietură
            b = dec.stdout.read(FS)
            if len(b) < FS: eof = True; break
            buf[n_read] = planes(b); n_read += 1
        if n_out not in buf: break
        cur = buf[n_out]; outp = cur
        for m in marks:
            if m - pw <= n_out < m + pw:
                u = (n_out - (m - pw) + 0.5) / (2 * pw); p = _ez(u)
                spd = abs(_ez(min(1, u + 0.5 / (2 * pw))) - _ez(max(0, u - 0.5 / (2 * pw)))) * W
                if n_out < m: A, B = cur, buf.get(m, cur)                # înainte: vechiul se mișcă, noul stă pe primul lui cadru
                else: A, B = last.get(m, cur), cur                       # după: vechiul stă pe ultimul lui cadru, noul se mișcă
                outp = _mblur(_push(A, B, p), min(blur_cap, spd * 0.9))
                if n_out == m: done += 1
                break
        for m in marks:
            if n_out == m - 1: last[m] = cur
        enc.stdin.write(b"".join(p.tobytes() for p in outp))
        del buf[n_out]; n_out += 1
    enc.stdin.close(); dec.wait(); enc.wait()
    if enc.returncode:
        raise SystemExit("alunecarea nu s-a putut pregăti (encoderul video s-a oprit); urmează: rulezi din nou, iar dacă se repetă, verifici ffmpeg cu skill-ul instal")
    if log:
        print(f"alunecare: {done} tranziții · {durata:.2f} s · blur ≤ {blur_cap:.0f} px · {n_out} cadre")
    return done


def main():
    ap = argparse.ArgumentParser(description="Efectele de montaj aprobate (rețeta §1).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a1 = sub.add_parser("alunecare", help="alunecarea la momentele date (secunde)")
    a1.add_argument("src"); a1.add_argument("dst")
    a1.add_argument("--la", required=True, help="momentele tăieturilor, în secunde, despărțite prin virgulă")
    a1.add_argument("--durata", type=float, default=None); a1.add_argument("--blur", type=float, default=None)
    a = ap.parse_args()
    if a.cmd == "alunecare":
        la = [float(x) for x in a.la.split(",") if x.strip()]
        alunecare(a.src, a.dst, la, durata=a.durata, blur_max=a.blur)


if __name__ == "__main__":
    main()
