#!/usr/bin/env python3
"""Randează reel-ul din planul de tăieri.
Folosire:
  python3 scripts/render.py inbox/video.mp4 inbox/video.cuts.json --words inbox/video.words.json \
      --out output/2026-10-21-slug/ [--hook "Textul hook-ului"] [--hook-until 3.0] [--font "Space Grotesk"]
Livrează în --out:
  reel-curat.mp4   – tăiat, fără subtitrări (pentru CapCut)
  subtitrari.srt   – subtitrări pe cronologia tăiată (import în CapCut)
  subtitrari.ass   – aceleași, cu stilul NeuroLab (pentru ardere)
  reel-final.mp4   – tăiat + subtitrări arse + hook (gata de postat)
  taieturi.md      – lista tăieturilor și motivele
"""
import argparse, json, os, subprocess

def run(cmd):
    subprocess.run(cmd, check=True)

_ENC = None
FINAL_QUALITY = True
def encoder():
    """encoder video: hardware dacă există (Mac: videotoolbox; Windows/Linux: nvenc, qsv, amf), altfel libx264 veryfast"""
    global _ENC
    if _ENC: return _ENC
    try: encs = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    except Exception: encs = ""
    hq = FINAL_QUALITY
    for name, args in [("h264_videotoolbox", ["-c:v", "h264_videotoolbox", "-b:v", "14M" if hq else "4M", "-allow_sw", "1"]),
                       ("h264_nvenc", ["-c:v", "h264_nvenc", "-preset", "p5" if hq else "p1", "-cq", "18" if hq else "26"]),
                       ("h264_qsv", ["-c:v", "h264_qsv", "-global_quality", "18" if hq else "26"]),
                       ("h264_amf", ["-c:v", "h264_amf", "-quality", "quality" if hq else "speed"])]:
        if name in encs:
            # test rapid: encoderul e în listă dar poate să nu meargă pe mașina asta
            t = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=64x64:d=0.2"] + args + ["-f", "null", "-"], capture_output=True)
            if t.returncode == 0: _ENC = args; return _ENC
    _ENC = ["-c:v", "libx264", "-preset", "fast" if hq else "ultrafast", "-crf", "18" if hq else "26"]; return _ENC

def seg_render(src, start, end, height, cache_dir):
    """Randează UN segment (cu -ss/-to pe intrare = decodează doar bucata) și îl pune în cache: aceleași tăieturi nu se mai randează a doua oară.
    Fără fade-uri: tranzițiile (alunecarea din rețetă) se pun după lipire, cu scripts/efecte.py. Flash-ul alb e interzis (Elena, 17.11)."""
    import hashlib
    key = hashlib.md5(f"{os.path.abspath(src)}|{os.path.getmtime(src):.0f}|{start:.3f}|{end:.3f}|{height}|{encoder()[1]}".encode()).hexdigest()[:16]
    out = os.path.join(cache_dir, key + ".mp4")
    if os.path.exists(out): return out
    w = 1080 if height >= 1080 else 540
    vf = f"scale={w}:{height}:force_original_aspect_ratio=increase,crop={w}:{height},setsar=1,fps=30"
    run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{start:.3f}", "-to", f"{end:.3f}", "-i", src, "-vf", vf] + encoder() +
        ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", "-movflags", "+faststart", out])
    return out

def concat_copy(files, out):
    """lipește segmentele fără re-encodare (aceiași parametri) — secunde, nu minute"""
    lst = out + ".txt"
    with open(lst, "w", encoding="utf-8") as f:
        for p in files: f.write("file '" + os.path.abspath(p).replace("'", "'\\''") + "'\n")
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart", out])
    os.unlink(lst)

def split_at_ideas(keep, idei, words, main_src, after=0.08, before=0.04):
    """Ideile din script (rețeta §1): la fiecare secundă din `idei` (timp în filmare) începe o idee nouă.
    Dacă ideea începe în mijlocul unui segment, segmentul se taie în respirația dintre cele două cuvinte cele mai apropiate
    (rămân 0,08 s după ultimul sunet și 0,04 s înainte de primul), iar a doua parte primește "transition": true.
    Dacă ideea cade la începutul unui segment, acela primește direct tranziția. Așa, ideile au tranziție și când omul vorbește legat."""
    out = []
    for k in keep:
        segs = [dict(k)]
        same_src = k.get("src", main_src) == main_src
        for t in idei:
            cur = segs[-1]
            if abs(t - cur["start"]) <= 0.5:
                if out or len(segs) > 1: cur["transition"] = True
                continue
            if not same_src or not (cur["start"] + 0.5 < t < cur["end"] - 0.5):
                continue
            best = None                                          # golul dintre două cuvinte cel mai apropiat de idee (±0,6 s)
            for w0, w1 in zip(words, words[1:]):
                if w0["end"] > cur["start"] and w1["start"] < cur["end"] and abs(w1["start"] - t) <= 0.6 and w1["start"] >= w0["end"]:
                    if best is None or abs(w1["start"] - t) < abs(best[1] - t): best = (w0["end"], w1["start"])
            if best is None: continue
            a_end = min(best[0] + after, best[1]); b_start = max(best[1] - before, a_end)
            left = dict(cur); left["end"] = a_end
            right = dict(cur); right["start"] = b_start; right["transition"] = True
            segs[-1] = left; segs.append(right)
        out.extend(segs)
    return out

def remap(t, keep):
    """timp sursă → timp în cronologia tăiată; None dacă momentul a fost tăiat"""
    acc = 0.0
    for k in keep:
        if k["start"] <= t <= k["end"]:
            return acc + (t - k["start"])
        if t < k["start"]:
            return None
        acc += k["end"] - k["start"]
    return None

def srt_t(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60); ms = int(round((t - int(t)) * 1000))
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def ass_t(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60); cs = int(round((t - int(t)) * 100))
    return f"{h}:{m:02}:{s:02}.{cs:02}"

def group_words(words, max_words=3, max_dur=1.6):
    groups, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= max_words or (cur[-1]["end"] - cur[0]["start"]) >= max_dur or w["word"].rstrip().endswith((".", "?", "!", ",")):
            groups.append(cur); cur = []
    if cur: groups.append(cur)
    return groups

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("cuts_json")
    ap.add_argument("--words", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--hook", default=None); ap.add_argument("--hook-until", type=float, default=3.0)
    ap.add_argument("--font", default="Space Grotesk"); ap.add_argument("--size", type=int, default=64)
    ap.add_argument("--preset", default=None, choices=["neurolab", "lejer", "tech", "dinamic"], help="stil de montaj; fără el, subtitle_style din identitatea aleasă")
    ap.add_argument("--identity", default=None); ap.add_argument("--intensity", default=None)
    ap.add_argument("--faces", default=None, help="faces.json din face_zones.py: fiecare subtitrare se mută sub bărbie / peste cap, cadru cu cadru")
    ap.add_argument("--height", type=int, default=1920, help="înălțime țintă 9:16 (lățime = 1080)")
    ap.add_argument("--preview", action="store_true", help="randare rapidă la 540x960 pentru rundele de feedback (secunde, nu minute)")
    ap.add_argument("--sfx", default=None, help="fișier audio scurt (ex. inbox/sfx/whoosh.wav) pus pe fiecare tranziție")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    plan = json.load(open(a.cuts_json, encoding="utf-8")); keep = plan["keep"]
    words = json.load(open(a.words, encoding="utf-8"))["words"]
    # "idei": secundele din filmare unde începe fiecare idee (hook, fiecare rehook, CTA) → tăietură în respirație + alunecare
    idei = sorted(float(x) for x in plan.get("idei", []))
    if idei:
        keep = split_at_ideas(keep, idei, words, a.video)

    # 1) reel-curat: fiecare segment randat separat (cache) + lipire fără re-encodare. Segmentele pot veni din clipuri diferite ("src").
    if a.preview: a.height = 960; a.size = max(24, a.size // 2)
    else: a.height = max(a.height, 1920)  # finalul e MEREU 1080×1920, indiferent de model sau de abonament
    global FINAL_QUALITY; FINAL_QUALITY = not a.preview
    cache_dir = os.path.join(a.out, ".cache"); os.makedirs(cache_dir, exist_ok=True)
    seg_files = []
    for i, k in enumerate(keep):
        seg_files.append(seg_render(k.get("src", a.video), k["start"], k["end"], a.height, cache_dir))
    clean = os.path.join(a.out, "reel-curat-preview.mp4" if a.preview else "reel-curat.mp4")
    concat_copy(seg_files, clean)
    # tranzițiile (rețeta §1): la fiecare idee nouă ("transition": true) și la fiecare schimbare de clip ("src" diferit).
    # Momentele se iau din durata reală a fiecărui segment randat (cadre întregi), ca alunecarea să cadă fix pe tăietură.
    def _dur(p):
        # durata fișierului (nu doar a imaginii): așa calculează și lipirea fără re-encodare unde începe segmentul următor
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p],
                             capture_output=True, text=True).stdout.strip().strip(",")
        return float(out or 0)
    hits, t = [], 0.0
    for i, (k, p) in enumerate(zip(keep, seg_files)):
        if i > 0 and (k.get("transition") or k.get("src", a.video) != keep[i - 1].get("src", a.video)):
            hits.append(round(t, 4))
        t += _dur(p)
    # efecte sonore pe tranziții (swish-ul omului, din folderul lui, nu generat): 0,14 din volum, cu 0,16 s înainte de tăietură
    if a.sfx and os.path.exists(a.sfx):
        if hits:
            inputs = ["-i", clean] + sum([["-i", a.sfx] for _ in hits], [])
            delays = "".join(f"[{i+1}:a]adelay={int(max(0.0, h-0.16)*1000)}|{int(max(0.0, h-0.16)*1000)},volume=0.14[s{i}];" for i, h in enumerate(hits))
            mix = "[0:a]" + "".join(f"[s{i}]" for i in range(len(hits))) + f"amix=inputs={len(hits)+1}:normalize=0[am]"
            mixed = clean + ".sfx.mp4"
            run(["ffmpeg", "-y", "-loglevel", "error"] + inputs + ["-filter_complex", delays + mix, "-map", "0:v", "-map", "[am]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", mixed])
            os.replace(mixed, clean)

    # 2) subtitrări remapate
    kept_words = []
    for w in words:
        mid = (w["start"] + w["end"]) / 2
        s = remap(w["start"], keep); e = remap(w["end"], keep)
        if remap(mid, keep) is None:
            continue  # cuvântul a fost tăiat
        if s is None: s = remap(mid, keep) - (mid - w["start"])
        if e is None: e = remap(mid, keep) + (w["end"] - mid)
        if e - s > 0.05:
            kept_words.append({"word": w["word"], "start": max(0.0, s), "end": e})
    PRESETS = {  # max_words, max_dur, upper, alignment(ASS), marginV, primary(BGR), outline, shadow, size_mult
        "neurolab": (3, 1.6, True,  2, 420, "&H00FFFFFF", 4, 0, 1.0),
        "lejer":    (3, 1.6, False, 8, 300, "&H00140A0A", 0, 0, 1.0),  # sus (~16 %); hook-ul e chiar textul, nu card separat
        "tech":     (3, 1.4, False, 2, 560, "&H00FFFFFF", 2, 3, 1.05),  # sub bărbie (~71 %), nu pe față
        "dinamic":  (1, 0.8, False, 2, 700, "&H00FFFFFF", 5, 0, 1.25),
    }
    sys_path = os.path.dirname(os.path.abspath(__file__))
    import sys as _sys; _sys.path.insert(0, sys_path)
    from identity import load as _load, ass_color
    cfg = _load(a.identity, a.intensity); ss = cfg.get("subtitle_style", {}); ff = cfg["font_family"]
    if not a.preset: a.preset = ss.get("preset", "neurolab")
    mw, md, upper, align, mv, prim, outl, shad, smul = PRESETS[a.preset]
    if a.height < 1920: mv = int(mv * a.height / 1920)
    # identitatea decide fontul, culorile, nr. de cuvinte și majusculele (presetul decide doar poziția/ritmul)
    sub_font = ff.get("body_ass", a.font); hook_font = ff.get("title_ass", "Fraunces")
    mw = ss.get("words", mw); upper = ss.get("upper", upper); prim = ass_color(ss.get("fill", "#FFFFFF")); outline_c = ass_color(ss.get("outline", "#140A0A")); outl = ss.get("outline_w", outl)
    hook_c = ass_color(cfg["color_palette"]["accent"]); box = 3 if ss.get("box") else 1
    groups = group_words(kept_words, max_words=mw, max_dur=md)
    srt_path = os.path.join(a.out, "subtitrari.srt")
    with open(srt_path, "w", encoding="utf-8") as f:
        for i, g in enumerate(groups, 1):
            f.write(f"{i}\n{srt_t(g[0]['start'])} --> {srt_t(g[-1]['end'])}\n{' '.join(x['word'].strip() for x in g)}\n\n")
    ass_path = os.path.join(a.out, "subtitrari.ass")
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write("[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 0\n\n" % (1080 if a.height >= 1080 else 540, a.height))
        f.write("[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        # subtitrări: alb, contur ink, jos-centru, mari (lizibile pe telefon)
        f.write(f"Style: Sub,{sub_font},{int(a.size*smul)},{prim},&H00FFFFFF,{outline_c},{ass_color(ss.get('box_color', '#000000')) if ss.get('box') else '&H80000000'},-1,0,0,0,100,100,0,0,{box},{outl},{shad},{align},80,80,{mv},1\n")
        # hook: mai mare, sus, lavandă NeuroLab (BGR în ASS: 8B7CF6 → F67C8B)
        f.write(f"Style: Hook,{hook_font},{int(a.size*1.35)},{hook_c},&H00FFFFFF,{outline_c},&H80000000,-1,0,0,0,100,100,0,0,1,5,0,8,80,80,260,1\n\n")
        f.write("[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        hook_mv = int(260 * a.height / 1920)
        if a.faces:
            fz = json.load(open(a.faces, encoding="utf-8"))
            heads = [fc["y"] - fc["h"] * 0.15 for fr in fz["frames"] if fr["t"] <= a.hook_until for fc in fr["faces"]]
            if heads and int(min(heads) * a.height) < hook_mv + int(a.size * 1.35 * 2.6) + 30:
                hook_mv = max(int(a.height * 0.06), int(min(heads) * a.height) - int(a.size * 1.35 * 2.6) - 30)
        if a.hook and a.preset != "lejer":
            hook_txt = a.hook.replace("\\n", "\n").replace("\n", "\\N")   # în afara f-string-ului: Python 3.11 nu acceptă \ în expresii
            f.write(f"Dialogue: 1,{ass_t(0)},{ass_t(a.hook_until)},Hook,,0,0,{hook_mv},,{hook_txt}\n")
        faces = json.load(open(a.faces, encoding="utf-8")) if a.faces else None
        line_h = int(a.size * smul * 1.3)  # înălțimea unei linii de subtitrare, px
        def occupied(t0, t1):
            """zona (y_min, y_max normalizat) ocupată de față între t0 și t1"""
            if not faces: return None
            ys = [(fc["y"] - fc["h"] * 0.15, fc["y"] + fc["h"] * 1.12) for fr in faces["frames"] if t0 - 0.3 <= fr["t"] <= t1 + 0.3 for fc in fr["faces"]]
            return (max(0.0, min(y for y, _ in ys)), min(1.0, max(y for _, y in ys))) if ys else None
        mv_default = mv
        for g in groups:
            txt = " ".join(x["word"].strip() for x in g)
            txt = txt.upper() if upper else txt
            t0, t1 = g[0]["start"], g[-1]["end"]
            occ = occupied(t0, t1); mv = mv_default; al = align
            if occ:
                top, chin = occ
                chin_px = int(chin * a.height) + 40          # textul începe la 40 px sub bărbie
                below_mv = a.height - chin_px - line_h         # MarginV de jos pentru ca textul să stea sub bărbie
                if below_mv >= int(a.height * 0.15):           # e loc jos (peste zona butoanelor, 15 %)
                    al = 2; mv = min(below_mv, mv_default if align == 2 else below_mv)
                    mv = max(int(a.height * 0.15), mv)
                else:                                          # nu e loc jos: sus, deasupra capului
                    al = 8; mv = max(int(a.height * 0.08), int(top * a.height) - line_h - 30)
                    if int(top * a.height) - line_h - 30 < int(a.height * 0.08): al = 8; mv = int(a.height * 0.08)
            f.write(f"Dialogue: 0,{ass_t(t0)},{ass_t(t1)},Sub,,0,0,{mv},,{{\\an{al}}}{txt}\n")

    # 3) reel-final: subtitrări arse
    final = os.path.join(a.out, "reel-preview.mp4" if a.preview else "reel-final.mp4")
    # căi fără spații/diacritice pentru filtrul subtitles (Windows + foldere cu nume lungi)
    import shutil, tempfile
    tmpd = tempfile.mkdtemp(prefix="nrn_"); tmp_ass = os.path.join(tmpd, "s.ass"); shutil.copy(ass_path, tmp_ass)
    fonts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts")
    tmp_fonts = os.path.join(tmpd, "fonts"); shutil.copytree(fonts_dir, tmp_fonts) if os.path.isdir(fonts_dir) else os.makedirs(tmp_fonts)
    ass_esc = tmp_ass.replace("\\", "/").replace(":", "\\:"); fd_esc = tmp_fonts.replace("\\", "/").replace(":", "\\:")
    # alunecarea (scripts/efecte.py) pe o copie; reel-curat rămâne fără tranziții, pentru CapCut
    base_for_final = clean
    n_trans = 0
    if hits:
        try:
            from efecte import alunecare
            slid = os.path.join(tmpd, "alunecare.mp4")
            n_trans = alunecare(clean, slid, hits, enc_args=encoder(), log=False)
            base_for_final = slid
        except (SystemExit, Exception) as e:
            print(f"ATENȚIE: alunecarea n-a mers de data asta ({e}). Urmează: rulezi din nou render.py; dacă se repetă, "
                  "verifici că numpy și opencv-python sunt instalate (instal). Videoul de acum e fără tranziții: nu-l livrezi așa.")
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", base_for_final, "-vf", f"subtitles='{ass_esc}':fontsdir='{fd_esc}'"] + encoder() +
        ["-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart", final])

    shutil.rmtree(tmpd, ignore_errors=True)

    # 4) lista tăieturilor
    with open(os.path.join(a.out, "taieturi.md"), "w", encoding="utf-8") as f:
        f.write(f"# Tăieturi\n\nSursă: {a.video}\nDurată sursă: {plan['duration']:.1f}s · scos: {plan['removed_seconds']}s · "
                f"durată finală: {sum(k['end']-k['start'] for k in keep):.1f}s\n\n| De la | Până la | Motiv |\n|---|---|---|\n")
        for c in plan["cuts"]:
            f.write(f"| {c['start']:.2f}s | {c['end']:.2f}s | {c['why']} |\n")
        f.write(f"\nTranziții (alunecare): {n_trans}, la secundele " + ", ".join(f"{h:.2f}" for h in hits) + ".\n" if hits else "\nTranziții: niciuna (niciun segment cu \"transition\": true).\n")
        f.write("\nDacă o tăietură e greșită: șterge-o din cuts.json și rulează din nou render.py. Ce corectezi aici schimbă rândul regulii în `fundament/reteta-montaj.md` (cu data) și intră în istoricul din `fundament/preferinte-montaj.md`.\n")
    if not a.preview:
        pr = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", final], capture_output=True, text=True).stdout.strip()
        if not pr.startswith("1080,"):
            raise SystemExit(f"FINAL_NOT_HD: reel-final.mp4 a ieșit {pr}, nu 1080×1920. Nu se livrează. Rulează din nou fără --preview.")
    print(f"OK → {a.out}: reel-curat.mp4, subtitrari.srt, subtitrari.ass, {os.path.basename(final)}, taieturi.md ({cfg['name']} · {cfg['intensity']} · preset {a.preset} · {n_trans} tranziții)")
    dur_final = sum(k["end"] - k["start"] for k in keep)
    if not hits:
        print("ATENȚIE: nicio tranziție. Fiecare idee nouă are nevoie de o tranziție: pune secundele ideilor în \"idei\" din cuts.json (stiluri/calitate.md).")
    elif dur_final > 20 and dur_final / (len(hits) + 1) > 15:
        print(f"ATENȚIE: doar {len(hits)} tranziții în {dur_final:.0f} s (una la ~{dur_final / (len(hits) + 1):.0f} s). Probabil lipsesc ideile: "
              "verifică hook-ul, fiecare rehook și CTA-ul din script și pune-le secundele în \"idei\" din cuts.json.")

if __name__ == "__main__":
    main()
