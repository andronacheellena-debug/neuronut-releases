---
name: feedback
description: Cum primești feedback ca să devii al omului. Folosește când omul scrie „feedback”, dă un feedback vag („nu-mi place”, „mai cald”, „nu e ok”), sau după fiecare livrare de reel/carusel. Oferi cele 3 modele (tehnic, estetic, emoțional) din GHID-FEEDBACK.md, aplici ce e concret, întrebi o dată ce e vag, și transformi corecturile în reguli.
---
# Feedback

## După fiecare livrare
Închei cu o propoziție, nu cu un formular: „Spune-mi ce schimb — tehnic (tăieturi, text, sunet), estetic (ritm, font, culori, copertă) sau emoțional (sună a tine?). Dacă vrei, îți dau modelul de feedback.”

## Când feedback-ul e vag
Aplici regula din `fundament/reguli-voce.md` („Feedback vag: întreabă înainte să rescrii”) și oferi modelul potrivit din `GHID-FEEDBACK.md`:
- „nu-mi place cum e tăiat / se aude / arată textul” → modelul TEHNIC
- „mai dinamic / mai curat / nu-mi place fontul / coperta” → modelul ESTETIC
- „nu sună a mine / prea rece / prea guru / nu simt” → modelul EMOȚIONAL
Îl trimiți scurt, gata de completat, cu un exemplu dintr-o linie. Nu rescrii până nu primești ceva concret.

## Ce faci cu feedback-ul concret
1. Tehnic → corectezi pe preview, arăți bucata (snippet.py), confirmi, abia apoi finalul.
2. Estetic → aplici și, dacă omul are rețetă, schimbi rândul regulii în `fundament/reteta-montaj.md` (valoarea, sursa, data); corectura intră și în istoricul din `fundament/preferinte-montaj.md`. Fără rețetă, scrii regula în `preferinte-montaj.md` / `preferinte-vizual.md` („tranziții doar la schimbarea de idee”, „fără majuscule”). Înainte să scrii, verifici în glosar ce înseamnă cuvântul omului: „mai puțină mișcare” se referă la cadru, nu la tranziții.
3. Emoțional → „fraza X → eu aș spune Y” intră în `fundament/reguli-voce.md` ca pereche (nu / da). „Fraza cea mai bună” intră în `reguli-voce.md` la „Fraze care sunt el”.
Confirmi într-un rând ce ai reținut ca regulă. Omul poate cere oricând „ce reguli ai notat despre mine?”.

## În limba omului
Modelele și întrebările le dai în limba în care îți scrie omul (vezi CLAUDE.md, „Limba”).
