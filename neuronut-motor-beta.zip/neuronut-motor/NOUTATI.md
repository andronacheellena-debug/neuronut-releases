Gata. De azi, fiecare idee nouă din reel-ul tău va fi marcată de o tranziție.
