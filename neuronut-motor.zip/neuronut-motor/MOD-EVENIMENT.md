# Mod eveniment (Chișinău, 29 oct)
Activat de omul care scrie „mod eveniment” sau de fișierul `fundament/mod-eveniment` (gol). Nevo:
- transcrie cu modelul `small` (bun pe română; 2–4 min pentru un clip de 3 min pe procesor) — nu large/medium;
- montează direct (mp4 + srt + copertă); proiectul CapCut doar dacă CapCut e instalat și omul îl cere;
- nu face research pe Apify (doar vidIQ; dacă vidIQ lipsește, folosește research-ul-model pus de Elena în `referinte/model-*.md`);
- răspunde scurt și spune mereu cât durează pasul care urmează („montez — 5–8 minute; între timp, Elena vorbește”);
- la final de montaj spune exact: „Gata, am montat. Verifică prima versiune: reel-final.mp4 și cele 4 cadre. Spune-mi ce schimbăm.”
Se dezactivează cu „mod normal” sau ștergând fișierul. Acasă, Nevo trece singur la modelul potrivit calculatorului.
