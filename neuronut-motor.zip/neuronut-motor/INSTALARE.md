# Nevo · ghid de pornire (citește pe telefon, fă pe laptop)

Cât durează, sincer: Etapa 1 (instalare) 10–15 min · Etapa 2 (ne cunoaștem) 20 min · Etapa 3 (primul material) în aceeași zi. Nevo îți spune mereu la ce etapă ești.

## Înainte (acasă, 5 minute)
1. Cont Claude Pro + aplicația Claude pe laptop (claude.ai/download). Fără Pro, tab-ul Code nu există.
2. Cont gratuit pe vidiq.com (butonul de înregistrare, nu prețurile).
3. Opțional: CapCut desktop, dacă vrei să retușezi singur.
Atât. Metricool și Apify NU trebuie acum — Nevo ți le cere mai târziu, doar dacă ai nevoie.

## Etapa 1 · Instalarea (10–15 min)
4. Dezarhivează `neuronut-motor` în Documents. Nu-l mai muți după.
5. Claude → tab-ul **Code** → chat nou → la „+” alege folderul `neuronut-motor`.
6. Jos: **Bypass permissions** · model **Sonnet**.
7. Dacă te întreabă de serverul „vidiq”: **Da** → loghează-te în pagina care se deschide.
8. Scrie un singur cuvânt: **start**. Răspunzi „da” când întreabă. Nu deschizi Terminalul.
9. Când citești **„Felicitări, Nevo e instalat. Etapa 1 e gata.”** — ai terminat instalarea.

## Etapa 2 · Ne cunoaștem (20 min)
10. 5 întrebări cu cifre (unde vrei video-ul, stilul, identitatea, designul, limba).
11. 11 întrebări cu voce — una pe cameră. Ai workbook-ul completat? Pune PDF-ul în `fundament/` și sare peste ce știe deja.
12. „Simți că acesta te reprezintă?” → da / ce lipsește.

## Etapa 3 · Primul material (azi)
13. Spui 3 situații din săptămână (sau îi ceri planul pe 7 zile) → primești scriptul în chat.
14. Filmezi 1–3 minute cu telefonul, pe părți. Pui video-ul în `inbox/`.
15. Scrii **montează** → preview în câteva minute → spui ce schimbi → **aprobat** → primești reel + 2 coperți + carusel + caption-uri.

## În fiecare zi
Scrii **start** → Nevo spune unde ai rămas și îți dă meniul: 1 situații · 2 montaj · 3 carusel · 4 programare · 5 reguli/feedback.

## Dacă ceva nu merge
Spune-i lui Nevo exact ce vezi. Dacă nici el nu rezolvă, trimite-i Elenei ultimul lui mesaj.
