# Cum vorbești cu Nevo (ca să devină al tău)

Nevo nu e un buton. E un colaborator care ține minte. Diferența dintre un om care obține reel-uri bune de la el și unul care renunță după două încercări e felul în care îi vorbește. Reguli simple, verificate:

## 1. Spune ce nu-ți place, concret, nu „nu-mi place”
Slab: „Nu-mi place montajul.”
Bun: „Textul e pe fața mea. Pune-l sub bărbie.” / „Tranzițiile sunt învechite, scoate-le, vreau tăieturi simple.” / „Prea multe cuvinte pe ecran, vreau maxim 2.”
Fiecare corectură concretă devine o regulă pe care o aplică data viitoare. „Nu-mi place” nu devine nimic.

## 2. Spune cum vrei, cu un exemplu
„Vreau ca reel-ul ăsta: [link]” sau „ca proiectul meu din CapCut «…»” îl ajută mai mult decât orice descriere. Pune în inbox 2–3 reel-uri care îți plac când pornești.

## 3. Verifică ce a reținut
Din când în când: „Ce reguli ai notat despre montajul meu?” El îți arată lista. Ștergi ce e greșit: „Regula X nu mai e valabilă.”

## 4. Dacă a inventat ceva, spune-i
„Asta n-am spus-o eu. De unde ai luat-o?” Nevo are voie să folosească doar ce i-ai spus tu și ce a găsit în research. Dacă a completat de la el, corectezi și devine regulă: „Nu adăuga detalii despre mine.”

## 5. Nu-l lăsa să sară peste pași
Dacă îți propune ceva „provizoriu”, „fără research”, „revin după” — răspunde: „Nu. Fă research-ul întâi.” Sistemul funcționează doar în ordine.

## 6. Când nu merge ceva tehnic
Spune-i exact ce vezi: „Nu s-a deschis nimic.” / „Scrie: [mesajul de eroare].” Nu încerca să repari tu. El îți spune ce a încercat și ce urmează. Dacă nici el nu rezolvă, trimite-i Elenei ultimul lui mesaj.

## 7. Vorbește normal
Nu-i scrie comenzi. Îi spui ca unui om care lucrează pentru tine: „Montează video-ul din inbox în stilul Tech, subtitrări mai mari.” Răspunde cu voce dacă ți-e mai ușor.

## Fraze care funcționează
- „Ține minte: …” → devine regulă permanentă.
- „De acum încolo …” → la fel.
- „Arată-mi 4 cadre înainte să exporți.” → verificare vizuală.
- „Nu publica, doar pregătește.” → nimic nu pleacă fără tine.
- „Ce ai învățat din reel-ul ăsta?” → îți spune ce a notat.

## Cele 3 modele de feedback (copiază, completează, trimite)
Un feedback bun are trei straturi. Nu trebuie să le folosești pe toate de fiecare dată — dar când nu știi ce să-i spui, ia modelul potrivit și completează liniile.

### 1 · Feedback tehnic (ce nu merge, exact)
Ce verifici: tăieturi, litere lipsă, respirații, goluri, text pe față, sincronizarea subtitrărilor, sunet, culori deformate.
```
TEHNIC
- La [secunda sau fraza „…”]: [ce se aude / ce se vede] → [ce vreau: taie / păstrează / lărgește / mută textul mai jos]
- Subtitrări: [prea devreme / prea târziu / cuvânt greșit „…” → corect „…”]
- Sunet: [se aude respirație la „…” / volum prea mic la „…” / efectul la „…” deranjează]
- Imagine: [deformat / prea întunecat / textul pe față la „…”]
```
Exemplu: „La «zece minute» se aude «ece» → lărgește ca să prindă tot cuvântul. Subtitrarea la «fraudă» apare cu o secundă mai devreme.”

### 2 · Feedback estetic (cum vreau să arate)
Ce verifici: ritmul, fontul, culorile, poziția textului, tranzițiile, coperta, dacă seamănă cu referințele tale.
```
ESTETIC
- Ritm: [prea lent / prea rapid / bun] — vreau ca [reel-ul de referință „…” / proiectul meu CapCut „…”]
- Text pe ecran: [mai mare / mai mic / alt font: „…” / altă culoare: „…” / fără majuscule]
- Tranziții: [scoate-le / pune ca în „…” / doar la schimbarea de idee]
- Copertă: [titlul „…” în loc de „…” / alt cadru: cel în care … / cuvântul accentuat: „…”]
- PĂSTREZ: [ce îmi place, ca să nu-l schimbe]
```
Exemplu: „Ritmul e bun. Textul mai mare și fără majuscule. Tranzițiile doar la schimbarea de idee, ca în reel-ul lui Kallaway. PĂSTREZ coperta.”

### 3 · Feedback emoțional (cum vreau să se simtă)
Ce verifici: dacă reel-ul sună a tine, dacă hook-ul te reprezintă, dacă tonul e cald sau rece, dacă pare sfat sau experiență.
```
EMOȚIONAL
- Sună a mine? [da / nu — fraza „…” n-aș spune-o niciodată; eu aș spune: „…”]
- Hook-ul: [mă reprezintă / prea tare / prea moale — eu aș începe cu: „…”]
- Tonul: [prea rece / prea „guru” / prea sfat — vreau din experiența mea, nu lecție]
- Ce am simțit când l-am văzut: [o propoziție sinceră]
- Fraza cea mai bună din reel: „…” (ca s-o țină minte)
```
Exemplu: „«Trebuie să înțelegi că…» sună a lecție. Eu aș spune: «Mie mi-a luat 5 ani să pricep asta.» Hook-ul mă reprezintă. Cea mai bună frază: «sistemul m-a ținut când eu n-am putut».”

Regula de aur rămâne: concret bate vag. „Nu-mi place" nu devine nimic; „fraza «…» → eu aș spune «…»" devine regulă.
