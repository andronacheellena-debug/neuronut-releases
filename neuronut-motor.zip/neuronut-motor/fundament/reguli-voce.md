# Reguli de voce
Se completează din mostrele reale (transcrierile din Brain Download + 2–3 mesaje/voice note-uri) și din corecturile omului pe scripturi. Fiecare regulă: scurtă, datată, cu exemplu.

## Cum vorbește
- 

## Cuvinte pe care le folosește
- 

## Cuvinte pe care NU le folosește
- 

## Corecturi învățate
- 

## Feedback vag: întreabă înainte să rescrii
Când omul dă feedback la un script, verifici întâi dacă e concret. E VAG dacă: descrie tonul doar cu adjective („mai artistic”, „mai cald”, „mai conversațional”, „mai natural”), fără nicio frază de exemplu; trimite la versiuni după număr sau ordine („prima”, „a doua”, „ultima”, „v3”) fără să citeze din ele; cere 2 sau mai multe direcții deodată („înapoi la prima, dar și o combinație, dar mai caldă”).
Dacă e vag, NU scrii o versiune nouă:
1. Rezumi într-o propoziție ce ai înțeles deja clar (miezul, ce să eviți).
2. Arăți primul rând (hook-ul) al versiunilor la care face trimitere, ca să aleagă după text, nu după număr.
3. Pui cel mult 2 întrebări scurte: „Care frază anume sună a sfat? Cum ai spune-o tu, cu voce tare?” și „Dacă schimbăm un singur lucru acum, care e?”.
4. Rescrii doar după ce primești fraze concrete. Păstrezi cuvintele omului exact cum le-a spus.
Feedbackul CONCRET (fraze citate, PĂSTREZ / SCOT / SCHIMB, „eu aș spune: …”) se aplică direct, fără întrebări. Regula funcționează în orice limbă scrie omul.
