# Preferințe de montaj
Pornire: pauze > 0,6 s se taie; umpluturi se taie; subtitrări 1–3 cuvinte, majuscule, jos-centru; hook 3 s sus.
Se actualizează după fiecare reel aprobat, datat.

## Reguli învățate
- 

## Dicționar (cuvinte pe care transcrierea le greșește → forma corectă)
- 
