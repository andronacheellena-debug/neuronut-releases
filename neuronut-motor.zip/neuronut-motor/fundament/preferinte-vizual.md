# Preferințe vizuale
Pornire: ink #0a0a14 / paper #f6f4fb / lavandă #8b7cf6 / roz #ff3d8a doar pe CTA. Fonturi: Fraunces (titluri), Space Grotesk (corp) — dacă omul are brandul lui, se trec aici.

## Brandul omului
- fonturi: 
- culori: 
- handle: 

## Reguli învățate
- 
