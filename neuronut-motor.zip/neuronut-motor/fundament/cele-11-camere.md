# Cele 11 camere (din workbook-ul „Conținutul care îți aduce clienți”)
Banca completă de întrebări. Neuronuț NU le pune pe toate la început: Etapa 2 („hai să ne cunoaștem”) = o întrebare-cheie pe cameră, cu voce, 20 de minute. Restul se deschid la cerere („aprofundăm camera 4”) sau când lipsește ceva pentru un script.

## 1 · Motivația (de ce creezi conținut)
CHEIE: Dacă social media ar funcționa exact cum vrei, ce s-ar schimba concret în afacerea ta?
- Cum arată o lună ideală de lucru: câte proiecte, cu ce clienți, cât timp faci ce știi cel mai bine?
- Cea mai frustrantă problemă din felul în care atragi clienți azi?
- Ce te împiedică să fii mai vizibil: teama de judecată, lipsa timpului, perfecționismul, comparația?
- Ce obiectiv e destul de important încât să publici constant și când primele postări nu primesc reacții?
- „Vreau să creez conținut pentru că …” / „Accept disconfortul de a fi vizibil deoarece …”

## 2 · Obiective și monetizare
CHEIE: Ce rezultat principal vrei din conținut în următoarele 90 de zile (oferte, clienți noi, colaborări, produs digital, comunitate, listă de emailuri)?
- Ce servicii/produse vinzi acum, cui, la ce preț? Pe care vrei să-l vinzi mai des și de ce?
- Ce proiecte nu mai accepți, chiar plătite?
- Ce trebuie să înțeleagă un client despre tine înainte să ceară o ofertă? Ce vrei să asocieze imediat cu numele tău? Ce percepție eviți?
- Sursa principală de monetizare pe 90 de zile: platforme / branduri / audiența mea / afacerea mea.

## 3 · Pilonii de conținut
CHEIE: Ce activități profesionale repeți aproape în fiecare săptămână și ar fi interesante de urmărit?
- Ce probleme vezi atât de des la clienți încât ai vorbi despre ele fără pregătire?
- Ce subiecte din domeniu urmărești din proprie inițiativă? Despre ce ai vorbi o oră fără să te plictisești?
- Ce proces poți documenta în următoarele 3 luni? Ce ai putea publica un an fără să te prefaci?
- Cele 4 dimensiuni: personal (omul din spatele expertizei), relatable (în ce se recunosc oamenii), value (ce învață de la tine), curiosity (de ce revin).
- 3–5 piloni finali + ideea comună + cum apare oferta natural în ei.

## 4 · Banca de povești
CHEIE: Cum ai ajuns să lucrezi în domeniul tău — versiunea reală, cu momentele nesigure?
- 3 greșeli care te-au învățat ceva esențial; 3 proiecte de care ești mândru, cu dovezi.
- Un proiect cu o problemă dificilă: ce ai făcut, ce s-a schimbat.
- Momentul în care te-ai privit ca antreprenor, nu doar specialist.
- Ce trăiești chiar acum și poți documenta în timp real? Ce te întreabă clienții înainte să semneze? Când ai gândit „trebuia să filmez asta”?

## 5 · Convingeri și perspective
CHEIE: Ce sfat popular din domeniul tău consideri incomplet sau greșit — și cum vezi tu lucrurile?
- „Ce se spune” vs „ce cred eu” — minimum 5 perechi.
- Ce comportamente din industrie te frustrează? Ce principiu nu compromiți nici pentru un proiect bine plătit?
- Ce ai învățat despre clienți și puțini începători înțeleg? Ce se schimbă în domeniu în 3 ani? O opinie pe care o susții chiar dacă colegii nu sunt de acord?

## 6 · Clientul ideal
CHEIE: Gândește-te la un client cu care ai lucrat foarte bine — cine era, ce făcea afacerea lui, ce apreciai la felul în care colabora?
- Despre ce ați vorbi cu interes la o cafea? Ce contează pentru el dincolo de afacere?
- Ce impresie să aibă după 5 postări de-ale tale? Ce sentiment transmiți: claritate, inspirație, siguranță, creativitate?
- În ce etapă e afacerea lui? Cine NU e clientul ideal?
- „Creez conținut pentru persoana care … / conduce un business care … / încearcă să … / are nevoie de un specialist care …”

## 7 · Lumea clientului
CHEIE: Cum își descrie clientul problema în propriile cuvinte — expresii auzite efectiv în conversații sau mesaje?
- 5 probleme pe care le are azi; 5 întrebări pe care și le pune despre investiție dar nu le adresează.
- Ce sfaturi a primit și nu l-au ajutat? Ce a încercat singur? De ce îi e teamă când investește?
- Rezultatul ideal pentru el; ce nu vrea sub nicio formă; ce întreabă înainte de preț vs înainte de semnare.

## 8 · Expertiza, vocea, poziționarea
CHEIE: Cum ai explica ce faci într-un mesaj vocal de 30 de secunde către un prieten?
- Ce știi și un client obișnuit nu știe? Ce greșeli fac cei care încearcă singuri? Ce testezi acum și poți documenta? Ce metode ai dezvoltat?
- Expresii pe care le folosești des; umorul care te caracterizează; tonul care NU te reprezintă.
- „Ajut [client] să obțină [rezultat] prin [metodă], folosind [diferențiator]” + dovezile + ce elimini din comunicarea actuală.

## 9 · Pâlnia ATM (Attention → Trust → Money)
CHEIE: Ce problemă a clienților tăi ar opri un om din scroll — și cu ce propoziție ai începe acel reel?
- Attention: comparație, greșeală, experiment. Trust: proiect real, culise, dovadă. Money: serviciul promovat, ce înțelege clientul despre colaborare, acțiunea simplă (ofertă / consultație / rezultate / ghid / email).
- Mini-pâlnia: 3 piese (A, T, M).

## 10 · Lista de emailuri
CHEIE: Ce informație utilă ai oferi gratuit unui client înainte să fie pregătit să lucreze cu tine?
- Problema rezolvată, formatul (checklist, ghid, mini-training, șablon), titlul, postarea care îl promovează, primul email + încă 3, dezabonarea transparentă.

## 11 · Formatele pe care le susții
CHEIE: Cât timp poți aloca realist pe săptămână și ce parte a conținutului îți mănâncă cel mai mult timp?
- Ce îți vine natural: vorbit la cameră / voiceover / carusel / studii de caz / tutoriale / documentare. Ce eviți.
- Ce materiale colectezi din munca cu clienții fără filmare separată? Ce standardizezi? Frecvența realistă pe 4 săptămâni; cele 3 formate; planul B pentru săptămâna fără timp.

## 12 · Planul pe 7 zile — NU e întrebare, e livrabilul lui Neuronuț
Din camerele 1–11, Neuronuț construiește planul: un proiect recent → 7 piese cu scop A/T/M, hook, acțiune. Asta e „primul material”.
