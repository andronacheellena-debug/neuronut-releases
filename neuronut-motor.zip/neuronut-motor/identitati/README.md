# Sistemul de identități vizuale (v1.0)
HUMAN FIRST, DIGITAL SECOND. Omul creează, Nevo execută. Identitatea se alege O SINGURĂ DATĂ și se aplică apoi la tot: reel-uri (subtitrări, hook), coperți, carusele, stories.

## Cele 3 identități (+ NeuroLab)
| style_id | Nume | Fonturi | Când |
|---|---|---|---|
| `raw-human` | Raw Human — autentic, natural, personal (IMPLICIT) | DM Sans + Caveat | fotografii reale, cadre spontane, text simplu |
| `experimental-creative` | Experimental Creative — expresiv, îndrăzneț | Archivo Black + Space Grotesk + Playfair Italic | tipografie supradimensionată, blocuri de culoare, decupaje |
| `digital-editorial` | Digital Editorial — modern, structurat | Space Grotesk Bold + Inter + IBM Plex Mono | grile, ierarhie, carusele educaționale |
| `neurolab` | identitatea NeuroLab | Fraunces + Space Grotesk | materialele NeuroLab |

Fiecare are 3 intensități: `soft` (discret), `balanced` (echilibrat, implicit), `bold` (contrast, tipografie dominantă). 9 preseturi.

## Cum funcționează (scripts/identity.py)
Config = `identitati/<style_id>.json` (bază) → secțiunea `intensity.<nivel>` → `fundament/identitate-mea.json` (omul câștigă întotdeauna).
Câmpuri: style_id, intensity, color_palette (bg, fg, accent, surface, cta, cta_fg), font_family (title/body/accent + varianta + numele pentru subtitrări), typography_rules (case, mărimi, max linii), background_rules, subtitle_style (preset, fill, outline, words, upper, box), cover_layout, carousel_layout, motion_rules, story_layout, user_overrides.

Scripturile citesc identitatea automat: `cover.py`, `carousel.py`, `story.py`, `render.py` (subtitrări + hook). Fără `--identity/--intensity` se ia alegerea omului din `fundament/identitate-mea.json`; fără fișier → Raw Human · balanced.

## fundament/identitate-mea.json (ADN-ul vizual al omului)
```json
{
  "style_id": "raw-human",
  "intensity": "balanced",
  "user_overrides": {
    "color_palette": {"accent": "#C04A2B"},
    "font_family": {"title": "FontulMeu-Bold.ttf", "title_var": "Bold", "title_ass": "Fontul Meu"},
    "subtitle_style": {"words": 2, "upper": false},
    "typography_rules": {"title_size": 92}
  },
  "assets": {"photos": "inbox/poze/", "logo": "fundament/logo.png", "brandbook": "fundament/brandbook.pdf"},
  "notes": "ce a spus omul despre cum vrea să arate"
}
```
Fonturile omului: fișierele .ttf/.otf în `fundament/fonturi/` (identity.py le caută întâi acolo). Pentru subtitrări (ASS) numele familiei trebuie să fie cel din fișier (`title_ass`/`body_ass`).

## Ce rămâne de dezvoltat (raportat separat)
- **Raw Human, în reel-uri (v1.1, decizie Elena 23 oct):** mișcarea, tranzițiile, sunetele și graficele de pe ecran se iau ca bază din stilul reel-urilor Kallaway (referința din `inbox/referinte`): carduri de capitol, inserții de unelte, hit-uri sonore pe cuvinte-cheie — aplicate în proiectul CapCut din biblioteca omului. Identitatea statică (coperți, carusele) rămâne Raw Human.
- Animațiile tipografice și elementele grafice în mișcare (motion_rules) se aplică în proiectul CapCut, nu în mp4-ul randat.
- Decupajele fotografice reale (cutout) pentru Experimental Creative: acum = bloc de culoare + poză încadrată; decupajul pe contur vine cu rembg (v1.1).
- Identitatea 2 și 3 au referințe vizuale doar din capturi; link-urile Behance/Dribbble nu sunt accesibile din motor.
- Colajele asimetrice multi-foto (Experimental) — v1.1.
