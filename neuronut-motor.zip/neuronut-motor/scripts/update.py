#!/usr/bin/env python3
"""Update Neuronuț fără să atingă ce e al omului.
  python3 scripts/update.py check    → spune dacă există versiune nouă și ce aduce
  python3 scripts/update.py apply    → descarcă și înlocuiește DOAR fișierele de sistem
Sursa versiunilor: UPDATE_URL (fișier versiune.json publicat de NeuroLab).
versiune.json: {"version": "0.3", "zip_url": "https://…/neuronut-motor-v0.3.zip", "notes": "…"}
"""
import io, json, os, shutil, sys, urllib.request, zipfile

UPDATE_URL = os.environ.get("NEURONUT_UPDATE_URL", "https://elenaandronache.com/neuronut/versiune.json")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Ce NU se atinge niciodată la update (al omului):
PROTECTED = ["fundament/", "inbox/", "output/", "referinte/", "stiluri/al-meu.md", ".claude/settings.local.json"]
# Ce se înlocuiește (sistemul):
SYSTEM = ["CLAUDE.md", "INSTALARE.md", "VERSION", "scripts/", ".claude/skills/", "stiluri/README.md",
          "stiluri/lejer.md", "stiluri/tech.md", "stiluri/dinamic.md"]

def ver(s): return tuple(int(x) for x in s.strip().split("."))

def local_version():
    try: return open(os.path.join(ROOT, "VERSION"), encoding="utf-8").read().strip()
    except FileNotFoundError: return "0.0"

def fetch_manifest():
    with urllib.request.urlopen(UPDATE_URL, timeout=15) as r:
        return json.load(r)

def is_protected(rel):
    return any(rel == p or rel.startswith(p) for p in PROTECTED)

def is_system(rel):
    return any(rel == p or rel.startswith(p) for p in SYSTEM)

def check():
    m = fetch_manifest(); lv, rv = local_version(), m["version"]
    if ver(rv) > ver(lv):
        print(f"UPDATE_AVAILABLE {lv} -> {rv}\n{m.get('notes','')}")
    else:
        print(f"UP_TO_DATE {lv}")

def apply():
    m = fetch_manifest(); lv, rv = local_version(), m["version"]
    if ver(rv) <= ver(lv):
        print(f"UP_TO_DATE {lv}"); return
    with urllib.request.urlopen(m["zip_url"], timeout=60) as r:
        data = r.read()
    z = zipfile.ZipFile(io.BytesIO(data))
    # arhiva poate avea un folder rădăcină (neuronut-motor/...) — îl sărim
    names = z.namelist(); prefix = names[0].split("/")[0] + "/" if all(n.startswith(names[0].split("/")[0] + "/") for n in names) else ""
    backup = os.path.join(ROOT, ".backup-" + lv); os.makedirs(backup, exist_ok=True)
    changed = 0
    for n in names:
        rel = n[len(prefix):]
        if not rel or rel.endswith("/") or is_protected(rel) or not is_system(rel):
            continue
        dst = os.path.join(ROOT, rel)
        if os.path.exists(dst):
            os.makedirs(os.path.dirname(os.path.join(backup, rel)), exist_ok=True)
            shutil.copy2(dst, os.path.join(backup, rel))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with z.open(n) as src, open(dst, "wb") as out: out.write(src.read())
        changed += 1
    open(os.path.join(ROOT, "VERSION"), "w", encoding="utf-8").write(rv + "\n")
    print(f"UPDATED {lv} -> {rv}: {changed} fișiere de sistem înlocuite; copia versiunii vechi în {backup}")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "check"
    try:
        {"check": check, "apply": apply}[cmd]()
    except Exception as e:
        print(f"UPDATE_ERROR {type(e).__name__}: {e}")
