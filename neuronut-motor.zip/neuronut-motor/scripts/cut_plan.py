#!/usr/bin/env python3
"""Construiește planul de tăieri dintr-o transcriere cu timpi pe cuvânt. IMPLICIT: tăiere strânsă, dinamică —
ies respirațiile, gândirea, pauzele, umpluturile, cuvintele duble. Pauzele intenționate se păstrează doar dacă le marchezi în --keep-at (secunde).
Folosire: python3 scripts/cut_plan.py inbox/video.words.json [--max-pause 0.6] [--pad 0.08] [--out cuts.json]
Scoate: pauzele lungi, umpluturile (ăă, îî, hm), repetițiile consecutive (dubluri de filmare).
Rezultatul e un JSON cu segmentele PĂSTRATE + motivele tăieturilor. Claude îl poate edita înainte de randare.
"""
import argparse, json, re

FILLERS = {"ăă", "ăăă", "ăăăă", "ă", "îî", "îîî", "hm", "hmm", "mm", "mmm", "ăm", "îm", "ee", "eee", "eeee", "aa", "aaa", "aaaa", "ii", "iii", "uh", "um", "em"}
def is_filler(word):
    n = word.strip().lower().strip(".,!?…;:-")
    return n in FILLERS or (len(n) >= 2 and len(set(n)) == 1 and n[0] in "aăeiîou")  # orice vocală lungă: aaa, eeee, ooo

def norm(w):
    return re.sub(r"[^\wăâîșț]", "", w.lower())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("words_json"); ap.add_argument("--max-pause", type=float, default=0.28, help="pauză maximă păstrată între cuvinte (dinamic: 0.28; lejer: 0.5)")
    ap.add_argument("--pad", type=float, default=0.08, help="aer lăsat la margini de tăietură (s)")
    ap.add_argument("--keep-pause", type=float, default=0.10, help="cât din pauză rămâne (aer minim, nu respirație)")
    ap.add_argument("--out", default=None)
    ap.add_argument("--keep-at", default="", help="momente (secunde, separate prin virgulă) unde pauza se păstrează intenționat, ex. 12.4,31.0")
    ap.add_argument("--edge", type=float, default=0.12, help="aer de siguranță la marginea fiecărui segment păstrat (s): nicio literă nu se pierde")
    a = ap.parse_args()
    data = json.load(open(a.words_json, encoding="utf-8"))
    words = data["words"]; duration = data.get("duration") or (words[-1]["end"] if words else 0)
    cuts, keep_words = [], []

    # 1) umpluturi
    for w in words:
        n = norm(w["word"])
        if is_filler(w["word"]) and (w["end"] - w["start"]) < 1.2:
            cuts.append({"start": w["start"], "end": w["end"], "why": f"umplutură „{w['word'].strip()}”"})
        else:
            keep_words.append(w)

    # 2) repetiții: aceeași secvență de 3+ cuvinte reluată imediat (dublu de filmare) → păstrăm ultima
    i, n = 0, len(keep_words)
    while i < n:
        found = False
        for L in range(8, 0, -1):
            if i + 2 * L <= n:
                a1 = [norm(x["word"]) for x in keep_words[i:i+L]]
                a2 = [norm(x["word"]) for x in keep_words[i+L:i+2*L]]
                if a1 == a2:
                    cuts.append({"start": keep_words[i]["start"], "end": keep_words[i+L-1]["end"],
                                 "why": f"dublu: „{' '.join(x['word'].strip() for x in keep_words[i:i+L])}” (păstrată a doua luare)"})
                    i += L; found = True; break
        if not found: i += 1

    # 3) pauze între cuvinte păstrate (respirații, gândire) — ies toate peste prag, mai puțin cele marcate
    keep_at = [float(x) for x in a.keep_at.split(",") if x.strip()]
    for p, q in zip(words, words[1:]):
        gap = q["start"] - p["end"]
        if gap > a.max_pause and not any(p["end"] - 0.3 <= k <= q["start"] + 0.3 for k in keep_at):
            cuts.append({"start": p["end"] + a.keep_pause / 2, "end": q["start"] - a.keep_pause / 2, "why": f"pauză de {gap:.1f}s"})
    if words and words[0]["start"] > a.max_pause:
        cuts.append({"start": 0.0, "end": max(0.0, words[0]["start"] - a.keep_pause), "why": "liniște la început"})
    if words and duration - words[-1]["end"] > a.max_pause:
        cuts.append({"start": words[-1]["end"] + a.keep_pause, "end": duration, "why": "liniște la final"})

    # unește tăieturile suprapuse, apoi derivă segmentele păstrate
    cuts = sorted([c for c in cuts if c["end"] > c["start"]], key=lambda c: c["start"])
    merged = []
    for c in cuts:
        if merged and c["start"] <= merged[-1]["end"] + 0.02:
            merged[-1]["end"] = max(merged[-1]["end"], c["end"]); merged[-1]["why"] += " + " + c["why"]
        else:
            merged.append(dict(c))
    keep, t = [], 0.0
    for c in merged:
        if c["start"] - t > 0.15:
            keep.append({"start": max(0.0, t - a.pad if t > 0 else 0.0), "end": c["start"] + a.pad})
        t = c["end"]
    if duration - t > 0.15:
        keep.append({"start": max(0.0, t - a.pad), "end": duration})
    # NICIO LITERĂ PIERDUTĂ: fiecare segment păstrat se aliniază la marginile cuvintelor (timpii Whisper sunt decalați 0,1–0,2 s)
    # și primește aer de siguranță (--edge); dacă două segmente ajung să se atingă, se unesc.
    kept_words = [w for w in words if not is_filler(w["word"])]
    for k in keep:
        for w in kept_words:
            if w["start"] < k["start"] < w["end"]: k["start"] = w["start"]      # începea în mijlocul unui cuvânt
            if w["start"] < k["end"] < w["end"]: k["end"] = w["end"]            # se termina în mijlocul unui cuvânt
        k["start"] = max(0.0, k["start"] - a.edge); k["end"] = min(duration, k["end"] + a.edge)
    merged_keep = []
    for k in sorted(keep, key=lambda k: k["start"]):
        if merged_keep and k["start"] <= merged_keep[-1]["end"]: merged_keep[-1]["end"] = max(merged_keep[-1]["end"], k["end"])
        else: merged_keep.append(k)
    keep = merged_keep
    removed = round(duration - sum(k["end"] - k["start"] for k in keep), 2)
    out = {"source": a.words_json, "duration": duration, "removed_seconds": round(removed, 2),
           "keep": keep, "cuts": merged}
    path = a.out or a.words_json.replace(".words.json", ".cuts.json")
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"OK: {len(merged)} tăieturi, -{removed:.1f}s din {duration:.1f}s → {path}")

if __name__ == "__main__":
    main()
