#!/usr/bin/env python3
"""Construiește planul de tăieri dintr-o transcriere cu timpi pe cuvânt. IMPLICIT: tăiere strânsă, dinamică —
ies respirațiile, gândirea, TOATE pauzele, umpluturile, cuvintele duble și variantele greșite ale aceleiași fraze (rămâne ultima). Segmentul care deschide o idee nouă primește "transition": true.
Folosire: python3 scripts/cut_plan.py inbox/video.words.json [--max-pause 0.6] [--pad 0.08] [--out cuts.json]
Scoate: pauzele lungi, umpluturile (ăă, îî, hm), repetițiile consecutive (dubluri de filmare).
Rezultatul e un JSON cu segmentele PĂSTRATE + motivele tăieturilor. Claude îl poate edita înainte de randare.
"""
import argparse, json, re

FILLERS = {"ăă", "ăăă", "ăăăă", "ă", "îî", "îîî", "hm", "hmm", "mm", "mmm", "ăm", "îm", "ee", "eee", "eeee", "aa", "aaa", "aaaa", "ii", "iii", "uh", "um", "em"}
def is_filler(word):
    n = word.strip().lower().strip(".,!?…;:-")
    return n in FILLERS or (len(n) >= 2 and len(set(n)) == 1 and n[0] in "aăeiîou")  # orice vocală lungă: aaa, eeee, ooo

def norm(w):
    return re.sub(r"[^\wăâîșț]", "", w.lower())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("words_json"); ap.add_argument("--max-pause", type=float, default=0.28, help="pauză maximă păstrată între cuvinte (dinamic: 0.28; lejer: 0.5)")
    ap.add_argument("--pad", type=float, default=0.08, help="aer lăsat la margini de tăietură (s)")
    ap.add_argument("--keep-pause", type=float, default=0.10, help="cât din pauză rămâne (aer minim, nu respirație)")
    ap.add_argument("--out", default=None)
    ap.add_argument("--edge", type=float, default=0.12, help="aer de siguranță la marginea fiecărui segment păstrat (s): nicio literă nu se pierde")
    a = ap.parse_args()
    data = json.load(open(a.words_json, encoding="utf-8"))
    words = data["words"]; duration = data.get("duration") or (words[-1]["end"] if words else 0)
    cuts, keep_words = [], []

    # 1) umpluturi
    for w in words:
        n = norm(w["word"])
        if is_filler(w["word"]) and (w["end"] - w["start"]) < 1.2:
            cuts.append({"start": w["start"], "end": w["end"], "why": f"umplutură „{w['word'].strip()}”"})
        else:
            keep_words.append(w)

    # 2) repetiții: aceeași secvență de 3+ cuvinte reluată imediat (dublu de filmare) → păstrăm ultima
    i, n = 0, len(keep_words)
    while i < n:
        found = False
        for L in range(8, 0, -1):
            if i + 2 * L <= n:
                a1 = [norm(x["word"]) for x in keep_words[i:i+L]]
                a2 = [norm(x["word"]) for x in keep_words[i+L:i+2*L]]
                if a1 == a2:
                    cuts.append({"start": keep_words[i]["start"], "end": keep_words[i+L-1]["end"],
                                 "why": f"dublu: „{' '.join(x['word'].strip() for x in keep_words[i:i+L])}” (păstrată a doua luare)"})
                    i += L; found = True; break
        if not found: i += 1

    # 2b) variante ale aceleiași fraze, nu doar lipite: fraza reluată mai târziu (greșită → corectă), începuturi abandonate.
    #     Se păstrează ULTIMA variantă (omul se corectează după ce greșește); cele dinainte ies.
    import difflib
    tăiate = {(c["start"], c["end"]) for c in cuts}
    rămase = [w for w in keep_words if not any(c["start"] <= w["start"] and w["end"] <= c["end"] for c in cuts)]
    fraze, cur = [], []
    for w in rămase:
        if cur and (w["start"] - cur[-1]["end"] > 0.45 or cur[-1]["word"].strip()[-1:] in ".?!"):
            fraze.append(cur); cur = []
        cur.append(w)
    if cur: fraze.append(cur)
    NUM = {"unu":"1","una":"1","doi":"2","două":"2","trei":"3","patru":"4","cinci":"5","șase":"6","șapte":"7","opt":"8","nouă":"9","zece":"10"}
    def toks(f): return [NUM.get(norm(x["word"]), norm(x["word"])) for x in f if norm(x["word"])]
    for i, fi in enumerate(fraze):
        ti = toks(fi)
        if len(ti) < 2: continue
        for fj in fraze[i+1:i+7]:
            tj = toks(fj)
            if len(tj) < 2: continue
            r = difflib.SequenceMatcher(None, ti, tj).ratio()
            început_abandonat = len(ti) < len(tj) and ti[:min(3, len(ti))] == tj[:min(3, len(ti))]
            STOP = {"și","la","în","pe","de","un","o","a","că","să","nu","e","eu","tu","mi","mia","am","ai","cu","din","ce","mai","asta","este","sunt","care","dar","sau","le","lui","ei","al","ale"}
            ci, cj = set(ti) - STOP, set(tj) - STOP
            comune = len(ci & cj) / max(1, min(len(ci), len(cj))) if min(len(ci), len(cj)) >= 2 else 0
            aceeași_frază = min(len(ti), len(tj)) >= 3 and (r >= 0.6 or comune >= 0.6)
            if început_abandonat or aceeași_frază:
                cuts.append({"start": fi[0]["start"], "end": fi[-1]["end"],
                             "why": f"variantă reluată mai târziu: „{' '.join(x['word'].strip() for x in fi)}” → păstrată varianta de la {fj[0]['start']:.1f}s"})
                break

    # 2c) tranziții: fiecare frază care începe după o pauză lungă sau după sfârșit de propoziție deschide o idee nouă
    idei_noi = [f[0]["start"] for k, f in enumerate(fraze) if k > 0 and (f[0]["start"] - fraze[k-1][-1]["end"] > 0.8 or fraze[k-1][-1]["word"].strip()[-1:] in ".?!")]

    # 3) pauze între cuvinte păstrate (respirații, gândire) — ies toate peste prag, mai puțin cele marcate
    # Toate pauzele ies, fără excepție (regula Elenei, 18 nov 2026): reelul poate fi cinematic, dar e dinamic.
    for p, q in zip(words, words[1:]):
        gap = q["start"] - p["end"]
        if gap > a.max_pause:
            cuts.append({"start": p["end"] + a.keep_pause / 2, "end": q["start"] - a.keep_pause / 2, "why": f"pauză de {gap:.1f}s"})
    if words and words[0]["start"] > a.max_pause:
        cuts.append({"start": 0.0, "end": max(0.0, words[0]["start"] - a.keep_pause), "why": "liniște la început"})
    if words and duration - words[-1]["end"] > a.max_pause:
        cuts.append({"start": words[-1]["end"] + a.keep_pause, "end": duration, "why": "liniște la final"})

    # unește tăieturile suprapuse, apoi derivă segmentele păstrate
    cuts = sorted([c for c in cuts if c["end"] > c["start"]], key=lambda c: c["start"])
    merged = []
    for c in cuts:
        if merged and c["start"] <= merged[-1]["end"] + 0.02:
            merged[-1]["end"] = max(merged[-1]["end"], c["end"]); merged[-1]["why"] += " + " + c["why"]
        else:
            merged.append(dict(c))
    keep, t = [], 0.0
    for c in merged:
        if c["start"] - t > 0.15:
            keep.append({"start": max(0.0, t - a.pad if t > 0 else 0.0), "end": c["start"] + a.pad})
        t = c["end"]
    if duration - t > 0.15:
        keep.append({"start": max(0.0, t - a.pad), "end": duration})
    # NICIO LITERĂ PIERDUTĂ: fiecare segment păstrat se aliniază la marginile cuvintelor (timpii Whisper sunt decalați 0,1–0,2 s)
    # și primește aer de siguranță (--edge); dacă două segmente ajung să se atingă, se unesc.
    kept_words = [w for w in words if not is_filler(w["word"])]
    for k in keep:
        for w in kept_words:
            if w["start"] < k["start"] < w["end"]: k["start"] = w["start"]      # începea în mijlocul unui cuvânt
            if w["start"] < k["end"] < w["end"]: k["end"] = w["end"]            # se termina în mijlocul unui cuvânt
        k["start"] = max(0.0, k["start"] - a.edge); k["end"] = min(duration, k["end"] + a.edge)
    merged_keep = []
    for k in sorted(keep, key=lambda k: k["start"]):
        if merged_keep and k["start"] <= merged_keep[-1]["end"]: merged_keep[-1]["end"] = max(merged_keep[-1]["end"], k["end"])
        else: merged_keep.append(k)
    keep = merged_keep
    for i, k in enumerate(keep):
        if i > 0 and any(k["start"] - 0.35 <= t <= k["start"] + 0.35 for t in idei_noi):
            k["transition"] = True
    # ce pică între două segmente păstrate e o tăietură vizibilă → tranziție și acolo, dacă segmentul nou începe o frază
    removed = round(duration - sum(k["end"] - k["start"] for k in keep), 2)
    out = {"source": a.words_json, "duration": duration, "removed_seconds": round(removed, 2),
           "keep": keep, "cuts": merged}
    path = a.out or a.words_json.replace(".words.json", ".cuts.json")
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"OK: {len(merged)} tăieturi, -{removed:.1f}s din {duration:.1f}s, {sum(1 for k in keep if k.get('transition'))} tranziții → {path}")
    for c in merged:
        if "variant" in c["why"] or "dublu" in c["why"]:
            print(f"  {c['start']:.1f}–{c['end']:.1f}s: {c['why']}")

if __name__ == "__main__":
    main()
