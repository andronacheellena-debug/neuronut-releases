#!/usr/bin/env python3
"""Licența Nevo: o licență = o persoană = adresa contului Claude.
  python3 scripts/licenta.py            → verifică și scrie o linie de stare
  python3 scripts/licenta.py confirmat  → omul a trimis confirmarea (formular); 7 zile de grație
Starea e în fundament/licenta.json. Amprenta = sha256(adresa în litere mici); adresa nu pleacă nicăieri.
"""
import hashlib, json, os, sys, time, urllib.request, urllib.parse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LISTA_URL = os.environ.get("NEURONUT_LICENTE_URL", "https://raw.githubusercontent.com/andronacheellena-debug/neuronut-releases/main/licente.json")
FORM_URL = "https://tally.so/r/2jAj2L"
STARE = os.path.join(ROOT, "fundament", "licenta.json")
GRATIE = 7 * 86400

def email_claude():
    for p in [os.path.expanduser("~/.claude.json"), os.path.join(os.environ.get("USERPROFILE", ""), ".claude.json")]:
        try:
            d = json.load(open(p, encoding="utf-8"))
            e = (d.get("oauthAccount") or {}).get("emailAddress")
            if e: return e.strip().lower()
        except Exception: pass
    return None

def amprenta(e): return hashlib.sha256(e.encode()).hexdigest()

def citeste_stare():
    try: return json.load(open(STARE, encoding="utf-8"))
    except Exception: return {}

def scrie_stare(s):
    os.makedirs(os.path.dirname(STARE), exist_ok=True)
    json.dump(s, open(STARE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

def lista():
    with urllib.request.urlopen(LISTA_URL, timeout=15) as r:
        return set(json.load(r).get("licente", []))

def instalat_de_dinainte():
    # instalat înainte de licențe = a trecut printr-un update (are .backup-*), sau are deja setări/stare/identitate/lucru în inbox-output
    f = os.path.join(ROOT, "fundament")
    if any(n.startswith(".backup-") for n in os.listdir(ROOT)): return True
    if any(os.path.exists(os.path.join(f, n)) for n in ("setari.json", "stare.json", "identitate-mea.json")): return True
    for d in ("inbox", "output"):
        for r, _, files in os.walk(os.path.join(ROOT, d)):
            if any(not n.startswith(".") for n in files): return True  # orice fișier adus de om
    return False

def verifica():
    e = email_claude(); s = citeste_stare(); acum = int(time.time())
    if not e:
        print("LICENTA_FARA_EMAIL"); return
    h = amprenta(e); s.update({"amprenta": h, "email_mascat": e[:2] + "…@" + e.split("@")[-1]})
    try:
        ok = h in lista(); online = True
    except Exception:
        ok = False; online = False
    if ok:
        s.update({"ok": True, "verificat_la": acum}); s.pop("confirmat_la", None); scrie_stare(s)
        print(f"LICENTA_OK {s['email_mascat']}"); return
    if not online and s.get("ok") and acum - s.get("verificat_la", 0) < GRATIE:
        print(f"LICENTA_OK_OFFLINE {s['email_mascat']}"); return
    if s.get("confirmat_la") and acum - s["confirmat_la"] < GRATIE:
        scrie_stare(s); print(f"LICENTA_IN_ASTEPTARE {s['email_mascat']} zile_ramase={(GRATIE-(acum-s['confirmat_la'])+86399)//86400}"); return
    s["ok"] = False; scrie_stare(s)
    # în link nu pleacă adresa: doar un cod scurt din amprentă (omul își scrie adresa în formular)
    link = FORM_URL + "?" + urllib.parse.urlencode({"cod": h[:12], "versiune": open(os.path.join(ROOT, "VERSION")).read().strip() if os.path.exists(os.path.join(ROOT, "VERSION")) else ""})
    if instalat_de_dinainte():
        print(f"LICENTA_DE_CONFIRMAT {s['email_mascat']}\n{link}")
    else:
        print(f"LICENTA_LIPSA {s['email_mascat']}")

def confirmat():
    s = citeste_stare(); s["confirmat_la"] = int(time.time()); scrie_stare(s); print("LICENTA_IN_ASTEPTARE zile_ramase=7")

if __name__ == "__main__":
    {"confirmat": confirmat}.get(sys.argv[1] if len(sys.argv) > 1 else "", verifica)()
