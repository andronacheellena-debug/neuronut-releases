#!/usr/bin/env python3
"""Scrie un proiect CapCut editabil DIRECT în folderul de draft-uri — fără să deschidă aplicația, fără click-uri.
Folosire:
  python3 scripts/capcut_draft.py list
  python3 scripts/capcut_draft.py create --template "<nume proiect existent>" --video output/x/reel-curat.mp4 \
         --cuts inbox/video.cuts.json --name "Numele reel-ului 1.0"
Metoda: clonează un proiect existent al omului (ca șablon: își păstrează fonturile, stilul, pistele), înlocuiește clipul,
rescrie segmentele video după planul de tăieri (dacă --cuts; altfel un singur segment cu tot clipul) și salvează.
Textul (subtitrări) îl adaugă Claude după, editând draft_content.json pe baza unui segment de text existent din șablon,
sau omul importă subtitrari.srt în CapCut. Nu se atinge proiectul original: se lucrează pe copie.
"""
import argparse, json, os, platform, shutil, sys, time, uuid

def drafts_dir():
    s = platform.system()
    cands = []
    if s == "Darwin":
        cands = [os.path.expanduser("~/Movies/CapCut/User Data/Projects/com.lveditor.draft")]
    elif s == "Windows":
        la = os.environ.get("LOCALAPPDATA", "")
        cands = [os.path.join(la, "CapCut", "User Data", "Projects", "com.lveditor.draft")]
    for c in cands:
        if os.path.isdir(c): return c
    sys.exit("CAPCUT_NOT_FOUND: nu găsesc folderul de proiecte CapCut. CapCut desktop e instalat și a fost deschis măcar o dată?")

def probe_duration_us(video):
    import subprocess
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video], capture_output=True, text=True).stdout.strip()
    return int(float(out) * 1_000_000)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cmd", choices=["list", "create"])
    ap.add_argument("--template"); ap.add_argument("--video"); ap.add_argument("--cuts"); ap.add_argument("--name")
    ap.add_argument("--fx-from-template", action="store_true", help="copiază tranziția și efectul sonor din șablon pe fiecare tăietură")
    ap.add_argument("--hits", default="", help="secunde (în cronologia tăiată) unde se pune un hit sonor, ex. 3.2,11.8")
    a = ap.parse_args(); d = drafts_dir()
    if a.cmd == "list":
        for n in sorted(os.listdir(d)):
            if os.path.exists(os.path.join(d, n, "draft_content.json")): print(n)
        return
    if not (a.template and a.video and a.name): sys.exit("create: trebuie --template, --video, --name")
    src = os.path.join(d, a.template)
    if not os.path.exists(os.path.join(src, "draft_content.json")): sys.exit(f"TEMPLATE_NOT_FOUND: {a.template}")
    dst = os.path.join(d, a.name)
    if os.path.exists(dst): sys.exit(f"EXISTS: {a.name} există deja; alege alt nume")
    shutil.copytree(src, dst)
    video = os.path.abspath(a.video); dur = probe_duration_us(video)
    cj = os.path.join(dst, "draft_content.json"); c = json.load(open(cj, encoding="utf-8"))
    vids = c.get("materials", {}).get("videos", [])
    if not vids: sys.exit("TEMPLATE_HAS_NO_VIDEO: șablonul nu are clip video")
    v = vids[0]; v["path"] = video; v["duration"] = dur
    for k in ("material_name",): v[k] = os.path.basename(video)
    # segmentele pistei video
    keep = [{"start": 0, "end": dur}]
    if a.cuts:
        plan = json.load(open(a.cuts, encoding="utf-8"))
        keep = [{"start": int(k["start"] * 1e6), "end": int(k["end"] * 1e6)} for k in plan["keep"]]
    vtrack = next((t for t in c.get("tracks", []) if t.get("type") == "video" and t.get("segments")), None)
    if not vtrack: sys.exit("TEMPLATE_HAS_NO_VIDEO_TRACK")
    proto = vtrack["segments"][0]; segs = []; t = 0
    for k in keep:
        s = json.loads(json.dumps(proto)); s["id"] = str(uuid.uuid4()).upper(); s["material_id"] = v["id"]
        s["source_timerange"] = {"start": k["start"], "duration": k["end"] - k["start"]}
        s["target_timerange"] = {"start": t, "duration": k["end"] - k["start"]}
        t += k["end"] - k["start"]; segs.append(s)
    vtrack["segments"] = segs
    # tranziții + efecte sonore din șablon, pe fiecare tăietură
    fx_note = ""
    if a.fx_from_template:
        mats = c.get("materials", {})
        trans = (mats.get("transitions") or [None])[0]
        sfx = next((x for x in mats.get("audios", []) if str(x.get("type", "")).lower() in ("sound_effect", "sound-effect", "sfx")), None)
        if trans:
            mats["transitions"] = [trans]
            for sg in segs[:-1]:
                refs = [r for r in sg.get("extra_material_refs", []) if r != trans["id"]]
                sg["extra_material_refs"] = refs + [trans["id"]]
        if sfx:
            mats["audios"] = [sfx]
            cut_times = [sg["target_timerange"]["start"] for sg in segs[1:]]
            hit_times = [int(float(h) * 1e6) for h in a.hits.split(",") if h.strip()]
            sdur = int(sfx.get("duration", 500000))
            aseg_proto = {"id": "", "material_id": sfx["id"], "source_timerange": {"start": 0, "duration": sdur},
                          "target_timerange": {"start": 0, "duration": sdur}, "speed": 1.0, "volume": 1.0, "visible": True,
                          "extra_material_refs": [], "render_index": 0, "track_render_index": 0}
            asegs = []
            for tt in sorted(set(cut_times + hit_times)):
                sg = json.loads(json.dumps(aseg_proto)); sg["id"] = str(uuid.uuid4()).upper(); sg["target_timerange"]["start"] = tt; asegs.append(sg)
            c["tracks"].append({"id": str(uuid.uuid4()).upper(), "type": "audio", "attribute": 0, "flag": 0, "segments": asegs})
        fx_note = f" · tranziție: {'da' if trans else 'nu găsesc în șablon'} · efect sonor: {'da, pe ' + str(len(c['tracks'][-1]['segments'])) + ' puncte' if sfx else 'nu găsesc în șablon'}"
    # scoatem celelalte piste (text/audio vechi) ca să nu rămână materialul altui reel; Claude adaugă subtitrările după
    keep_new_audio = c["tracks"][-1] if (a.fx_from_template and c["tracks"] and c["tracks"][-1].get("type") == "audio" and c["tracks"][-1] is not vtrack) else None
    c["tracks"] = [tr for tr in c["tracks"] if tr is vtrack or tr is keep_new_audio or tr.get("type") not in ("text", "audio", "sticker", "effect")]
    for key in ("texts", "stickers", "effects"):
        if key in c.get("materials", {}): c["materials"][key] = []
    if not a.fx_from_template:
        for key in ("audios", "transitions"):
            if key in c.get("materials", {}): c["materials"][key] = []
    c["duration"] = t
    json.dump(c, open(cj, "w", encoding="utf-8"), ensure_ascii=False)
    mj = os.path.join(dst, "draft_meta_info.json")
    if os.path.exists(mj):
        m = json.load(open(mj, encoding="utf-8")); m["draft_name"] = a.name; m["draft_fold_path"] = dst
        m["tm_draft_modified"] = int(time.time() * 1e6); m["tm_duration"] = t
        json.dump(m, open(mj, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"OK: proiect CapCut „{a.name}” creat din „{a.template}”, {len(segs)} segmente, {t/1e6:.1f}s{fx_note} → {dst}\nDeschide CapCut: apare în lista de proiecte. Subtitrările: importă subtitrari.srt (Text → Import) sau Claude le scrie în draft_content.json.")

if __name__ == "__main__":
    main()
