#!/usr/bin/env python3
"""Planșă + culori dominante din 10–15 imagini de referință ale omului.
Folosire: python3 scripts/analyze_images.py inbox/referinte-vizuale/ [--out referinte/adn-vizual/]
Scoate: contact-sheet.png (Claude se uită la ea) + culori.json (cele 6 culori dominante pe set, hex)."""
import argparse, os, json
from PIL import Image
ap = argparse.ArgumentParser(); ap.add_argument("folder"); ap.add_argument("--out", default="referinte/adn-vizual"); a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
files = sorted(f for f in os.listdir(a.folder) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp")))[:20]
if not files: raise SystemExit("Nicio imagine în folder.")
thumbs = []; counts = {}
for f in files:
    im = Image.open(os.path.join(a.folder, f)).convert("RGB"); im.thumbnail((360, 360)); thumbs.append(im)
    small = im.copy(); small.thumbnail((60, 60)); q = small.quantize(colors=6, method=2).convert("RGB")
    for c, n in [(px, 1) for px in q.getdata()]: counts[c] = counts.get(c, 0) + 1
cols = 4; rows = (len(thumbs) + cols - 1) // cols; W = 360 * cols + 10 * (cols - 1); H = 360 * rows + 10 * (rows - 1)
sheet = Image.new("RGB", (W, H), (40, 40, 40))
for i, t in enumerate(thumbs): sheet.paste(t, ((i % cols) * 370, (i // cols) * 370))
sheet.save(os.path.join(a.out, "contact-sheet.png"))
top = sorted(counts.items(), key=lambda kv: -kv[1])[:12]
json.dump({"files": files, "dominant_colors": ["#%02x%02x%02x" % c for c, _ in top]}, open(os.path.join(a.out, "culori.json"), "w"), indent=1)
print(f"OK → {a.out}: contact-sheet.png ({len(files)} imagini), culori.json")
