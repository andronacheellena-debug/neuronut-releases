#!/usr/bin/env python3
"""Story 9:16 în identitatea aleasă. python3 scripts/story.py --text "..." [--sub "..."] [--photo inbox/poza.jpg] --out x/story-1.jpg [--identity] [--intensity]"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from identity import load
from layouts import story
ap = argparse.ArgumentParser(); ap.add_argument("--text", required=True); ap.add_argument("--sub", default=None); ap.add_argument("--photo", default=None)
ap.add_argument("--out", required=True); ap.add_argument("--identity", default=None); ap.add_argument("--intensity", default=None)
a = ap.parse_args(); cfg = load(a.identity, a.intensity)
story(cfg, a.text.replace("\\n", "\n"), a.photo, a.out, a.sub); print(f"OK → {a.out} ({cfg['name']} · {cfg['intensity']})")
