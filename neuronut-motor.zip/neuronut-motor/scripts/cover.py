#!/usr/bin/env python3
"""Copertă de reel (4:5) în identitatea aleasă. Textul evită fața (detecție).
Folosire: python3 scripts/cover.py <video sau imagine> [--time 1.2] --title "Titlul\ncopertei" [--accent "cuvânt"] --out x/coperta.jpg
          [--identity raw-human|experimental-creative|digital-editorial|neurolab] [--intensity soft|balanced|bold] [--label "01 — TEMA"]
Fără --identity/--intensity se ia alegerea omului din fundament/identitate-mea.json (sau Raw Human · balanced).
"""
import argparse, os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from identity import load
from layouts import cover
ap = argparse.ArgumentParser(); ap.add_argument("src"); ap.add_argument("--time", type=float, default=1.0)
ap.add_argument("--title", required=True); ap.add_argument("--accent", default=None); ap.add_argument("--out", required=True)
ap.add_argument("--identity", default=None); ap.add_argument("--intensity", default=None); ap.add_argument("--label", default=None)
a = ap.parse_args(); cfg = load(a.identity, a.intensity)
src = a.src
if src.lower().endswith((".mp4", ".mov", ".m4v", ".webm")):
    src = tempfile.NamedTemporaryFile(suffix=".png", delete=False).name
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(a.time), "-i", a.src, "-frames:v", "1", src], check=True)
cover(cfg, src, a.title.replace("\\n", "\n"), a.accent, a.out, a.label)
print(f"OK → {a.out} ({cfg['name']} · {cfg['intensity']})")
