#!/usr/bin/env python3
"""Carusel 4:5 (1080×1350) din JSON, în identitatea aleasă.
Folosire: python3 scripts/carousel.py carusel.json --out dir/ [--identity …] [--intensity …]
carusel.json: {"handle": "@cont", "slides": [{"title": "...", "accent": "...", "image": "inbox/poza.jpg", "body": "...", "cta": true, "cta_text": "...", "label": "01"}]}
("brand" din vechiul format e ignorat: identitatea vine din identitati/ + fundament/identitate-mea.json)
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from identity import load
from layouts import slide
ap = argparse.ArgumentParser(); ap.add_argument("spec"); ap.add_argument("--out", required=True)
ap.add_argument("--identity", default=None); ap.add_argument("--intensity", default=None)
a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
spec = json.load(open(a.spec, encoding="utf-8")); cfg = load(a.identity, a.intensity)
handle = spec.get("handle") or spec.get("brand", {}).get("handle", "")
n = len(spec["slides"])
for i, s in enumerate(spec["slides"], 1):
    slide(cfg, s, i, n, os.path.join(a.out, f"slide-{i:02}.png"), handle)
print(f"OK → {a.out}: {n} slide-uri 1080x1350 ({cfg['name']} · {cfg['intensity']})")
