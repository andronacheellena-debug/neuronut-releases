#!/usr/bin/env python3
"""Pregătește orice video de telefon pentru montaj: aplică rotația din metadate, convertește HEVC→H.264,
normalizează sunetul. Folosire: python3 scripts/prep.py inbox/IMG_1234.MOV → inbox/IMG_1234.prep.mp4
Rulează ÎNTOTDEAUNA înainte de transcribe.py pe fișiere .MOV/.HEIC/.hevc sau filmate pe iPhone.
"""
import os, subprocess, sys
src = sys.argv[1]; dst = os.path.splitext(src)[0] + ".prep.mp4"
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-map", "0:v:0", "-map", "0:a:0?",
                "-vf", "scale='min(1080,iw)':-2", "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-movflags", "+faststart", dst], check=True)
print(f"OK → {dst} (rotație aplicată, H.264, sunet normalizat)")
