#!/usr/bin/env python3
"""Montaj narativ (opțional): rearanjează ce există deja în clip după o structură psihologică — hook → rehook → problemă → valoare → dovadă → CTA.
Claude alege frazele din transcriere (words.json) și le dă ca intervale, în ordinea finală. Scriptul construiește cuts.json cu segmentele în acea ordine,
tăiat strâns (fără respirații), ca render.py să le lipească exact așa.
Folosire:
  python3 scripts/narrative_plan.py inbox/video.words.json --order "hook=41.2-44.0,rehook=3.1-6.4,problema=7.0-15.2,valoare=18.0-31.5,dovada=33.0-38.0,cta=45.0-49.0" --out inbox/video.cuts.json
Intervalele sunt în secunde din SURSĂ; se aliniază automat la începutul/sfârșitul cuvintelor (nu tai niciodată un cuvânt la mijloc).
"""
import argparse, json
ap = argparse.ArgumentParser(); ap.add_argument("words_json"); ap.add_argument("--order", required=True); ap.add_argument("--out", required=True)
ap.add_argument("--pad", type=float, default=0.06)
a = ap.parse_args(); d = json.load(open(a.words_json, encoding="utf-8")); words = d["words"]
def snap(t0, t1):
    """lărgește intervalul la marginile de cuvânt"""
    ws = [w for w in words if w["end"] > t0 and w["start"] < t1]
    if not ws: return None
    return max(0.0, ws[0]["start"] - a.pad), ws[-1]["end"] + a.pad, " ".join(w["word"].strip() for w in ws)
keep, roles = [], []
for part in a.order.split(","):
    role, rng = part.split("=") if "=" in part else ("", part); t0, t1 = [float(x) for x in rng.split("-")]
    s = snap(t0, t1)
    if not s: continue
    keep.append({"start": round(s[0], 3), "end": round(s[1], 3), "role": role.strip()}); roles.append((role.strip(), s[2]))
total = sum(k["end"] - k["start"] for k in keep)
json.dump({"source": a.words_json, "duration": d.get("duration"), "narrative": True, "removed_seconds": None, "keep": keep,
           "cuts": [{"start": 0, "end": 0, "why": f"montaj narativ: {len(keep)} segmente reordonate (" + " → ".join(r for r, _ in roles) + ")"}]},
          open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"OK → {a.out}: {len(keep)} segmente, {total:.1f}s")
for r, t in roles: print(f"  [{r}] {t[:90]}")
