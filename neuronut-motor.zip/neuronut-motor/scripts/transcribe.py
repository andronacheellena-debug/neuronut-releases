#!/usr/bin/env python3
"""Transcrie un video/audio cu faster-whisper, cu timpi pe fiecare cuvânt.
Folosire: python3 scripts/transcribe.py inbox/video.mp4 ro [--model large-v3]
Scrie lângă video: <nume>.words.json și <nume>.srt
"""
import argparse, json, os, subprocess, sys, tempfile

def extract_audio(src):
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False).name
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-vn", "-ac", "1", "-ar", "16000", tmp], check=True)
    return tmp

def to_srt_time(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60); ms = int(round((t - int(t)) * 1000))
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def words_to_srt(words, max_words=3, max_dur=1.6):
    """Subtitrări scurte (1–3 cuvinte), ritm de reel."""
    lines, cur = [], []
    for w in words:
        cur.append(w)
        dur = cur[-1]["end"] - cur[0]["start"]
        if len(cur) >= max_words or dur >= max_dur or w["word"].rstrip().endswith((".", "?", "!", ",")):
            lines.append(cur); cur = []
    if cur: lines.append(cur)
    out = []
    for i, grp in enumerate(lines, 1):
        text = " ".join(x["word"].strip() for x in grp)
        out.append(f"{i}\n{to_srt_time(grp[0]['start'])} --> {to_srt_time(grp[-1]['end'])}\n{text}\n")
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("lang", nargs="?", default="ro")
    ap.add_argument("--model", default="large-v3")
    ap.add_argument("--initial-prompt", default="Transcriere în limba română, cu diacritice: ă, â, î, ș, ț.")
    a = ap.parse_args()
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        sys.exit("Lipsește faster-whisper. Instalează: pip install faster-whisper")
    audio = extract_audio(a.src)
    model = WhisperModel(a.model, device="auto", compute_type="auto")
    segments, info = model.transcribe(audio, language=a.lang, word_timestamps=True,
                                      vad_filter=True, initial_prompt=a.initial_prompt)
    words, segs = [], []
    for seg in segments:
        segs.append({"start": seg.start, "end": seg.end, "text": seg.text.strip()})
        for w in (seg.words or []):
            words.append({"word": w.word, "start": w.start, "end": w.end, "p": round(w.probability, 3)})
    base = os.path.splitext(a.src)[0]
    with open(base + ".words.json", "w", encoding="utf-8") as f:
        json.dump({"language": info.language, "duration": info.duration, "segments": segs, "words": words}, f, ensure_ascii=False, indent=1)
    with open(base + ".srt", "w", encoding="utf-8") as f:
        f.write(words_to_srt(words))
    os.unlink(audio)
    print(f"OK: {len(words)} cuvinte, {info.duration:.1f}s → {base}.words.json, {base}.srt")

if __name__ == "__main__":
    main()
