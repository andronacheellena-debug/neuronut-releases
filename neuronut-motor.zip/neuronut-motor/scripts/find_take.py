#!/usr/bin/env python3
"""Caută o frază în TOATE clipurile transcrise din inbox și arată fiecare luare cu timpii ei — ca să alegi luarea corectă, nu să scoți fraza.
Folosire: python3 scripts/find_take.py "regele leu" [--dir inbox/]
Ieșire: clip · start–end · textul exact din acea luare. Înlocuirea: în cuts.json pui segmentul cu "src": "<clipul bun>".
"""
import argparse, glob, json, os, re, unicodedata
ap = argparse.ArgumentParser(); ap.add_argument("phrase"); ap.add_argument("--dir", default="inbox"); a = ap.parse_args()
def norm(t): return re.sub(r"[^a-z0-9 ]", "", unicodedata.normalize("NFKD", t.lower()).encode("ascii", "ignore").decode()).strip()
target = norm(a.phrase).split(); n = len(target); found = 0
for wj in sorted(glob.glob(os.path.join(a.dir, "**", "*.words.json"), recursive=True)):
    words = json.load(open(wj, encoding="utf-8"))["words"]; toks = [norm(w["word"]) for w in words]
    for i in range(len(toks) - n + 1):
        if [t for t in toks[i:i+n]] == target or (n >= 2 and sum(1 for x, y in zip(toks[i:i+n], target) if x == y) >= n - 1 and toks[i] == target[0]):
            seg = words[i:i+n]; found += 1
            print(f"{os.path.basename(wj).replace('.words.json','')} · {seg[0]['start']:.2f}–{seg[-1]['end']:.2f}s · „{' '.join(w['word'].strip() for w in seg)}”")
if not found: print(f"Nicio luare cu „{a.phrase}” în {a.dir}. Transcrie toate clipurile (transcribe.py) sau cere omului clipul.")
