#!/usr/bin/env python3
"""Bucata de verificare: 3 secunde înainte și după un moment, plus cuvintele cu timpii lor din jur — ca omul să confirme tăietura ÎNAINTE de re-randare.
Folosire: python3 scripts/snippet.py inbox/video.mp4 --at 124.0 [--words inbox/video.words.json] [--out output/x/verifica-2m04.mp4]
"""
import argparse, json, os, subprocess
ap = argparse.ArgumentParser(); ap.add_argument("video"); ap.add_argument("--at", type=float, required=True); ap.add_argument("--words", default=None)
ap.add_argument("--span", type=float, default=3.0); ap.add_argument("--out", default=None); a = ap.parse_args()
out = a.out or os.path.join(os.path.dirname(a.video), f"verifica-{int(a.at//60)}m{int(a.at%60):02d}.mp4")
s0 = max(0, a.at - a.span)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{s0:.3f}", "-t", f"{2*a.span:.3f}", "-i", a.video, "-vf", "scale=540:-2,fps=30",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-c:a", "aac", "-b:a", "128k", out], check=True)
print(f"OK → {out} ({s0:.1f}s–{a.at+a.span:.1f}s)")
if a.words:
    words = json.load(open(a.words, encoding="utf-8"))["words"]
    print(f"Cuvintele din jurul secundei {a.at:.1f} (timp sursă):")
    for w in words:
        if s0 <= w["start"] <= a.at + a.span:
            mark = "  ◀ aici" if w["start"] <= a.at <= w["end"] else ""
            print(f"  {w['start']:7.2f}–{w['end']:6.2f}  {w['word'].strip()}{mark}")
