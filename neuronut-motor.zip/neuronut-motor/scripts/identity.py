#!/usr/bin/env python3
"""Sistemul de identități vizuale. Rezolvă: preset (identitati/<style_id>.json) + intensitate + suprascrierile omului
(fundament/identitate-mea.json, dacă există). Ordinea: preset → intensitate → user_overrides (omul câștigă mereu).
Folosire din alte scripturi: from identity import load, font ; cfg = load("raw-human", "balanced")
CLI: python3 scripts/identity.py show raw-human bold
"""
import json, os, sys, copy
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ID_DIR = os.path.join(ROOT, "identitati"); FONTS = os.path.join(ROOT, "fonts"); USER = os.path.join(ROOT, "fundament", "identitate-mea.json")
INTENSITIES = ("soft", "balanced", "bold")

def deep_merge(a, b):
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        out[k] = deep_merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else copy.deepcopy(v)
    return out

def list_ids():
    return sorted(f[:-5] for f in os.listdir(ID_DIR) if f.endswith(".json"))

def load(style_id=None, intensity=None, apply_user=True):
    user = json.load(open(USER, encoding="utf-8")) if (apply_user and os.path.exists(USER)) else {}
    style_id = style_id or user.get("style_id") or "raw-human"
    intensity = intensity or user.get("intensity") or "balanced"
    p = os.path.join(ID_DIR, f"{style_id}.json")
    if not os.path.exists(p): sys.exit(f"IDENTITY_NOT_FOUND: {style_id} (disponibile: {', '.join(list_ids())})")
    base = json.load(open(p, encoding="utf-8"))
    cfg = deep_merge({k: v for k, v in base.items() if k != "intensity"}, base.get("intensity", {}).get(intensity, {}))
    cfg["intensity"] = intensity
    if apply_user: cfg = deep_merge(cfg, user.get("user_overrides", {}))
    cfg["_user"] = user
    return cfg

CYRILLIC_OK = {"Inter.ttf", "Caveat.ttf", "PlayfairDisplay-Italic.ttf", "IBMPlexMono.ttf", "IBMPlexMono-Bold.ttf", "SpaceGrotesk.ttf"}
def font(cfg, role, size, text=None):
    """PIL ImageFont pentru rolul title|body|accent, din fonts/ (sau fontul omului din fundament/fonturi/).
    Dacă textul are chirilice și fontul nu le are, cade pe Inter (title/body) sau Playfair Italic (accent)."""
    from PIL import ImageFont
    ff = cfg["font_family"]; name = ff.get(role) or ff["body"]; var = ff.get(role + "_var", "Regular")
    if text and any("\u0400" <= ch <= "\u04FF" for ch in text) and name not in CYRILLIC_OK:
        name, var = ("PlayfairDisplay-Italic.ttf", "Italic") if role == "accent" else ("Inter.ttf", "Bold" if role == "title" else "Regular")
    for d in (os.path.join(ROOT, "fundament", "fonturi"), FONTS):
        p = os.path.join(d, name)
        if os.path.exists(p):
            f = ImageFont.truetype(p, size)
            try: f.set_variation_by_name(var)
            except Exception: pass
            return f
    return ImageFont.load_default()

def hexc(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def ass_color(h):  # #RRGGBB → &H00BBGGRR
    h = h.lstrip("#"); return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}".upper()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "list": print("\n".join(list_ids())); sys.exit()
    cfg = load(sys.argv[2] if len(sys.argv) > 2 else None, sys.argv[3] if len(sys.argv) > 3 else None)
    cfg.pop("_user", None); print(json.dumps(cfg, ensure_ascii=False, indent=1))
