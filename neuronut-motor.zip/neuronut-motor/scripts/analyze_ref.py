#!/usr/bin/env python3
"""Analizează un reel de referință (screen record de pe telefon) ca să extragă stilul de montaj.
Folosire: python3 scripts/analyze_ref.py inbox/referinte/reel1.mp4 [--out referinte/stil-reel1/]
Scoate: contact-sheet.png (un cadru pe secundă) + taieturi.json (momentele de tăietură detectate, ritmul) + rezumat.md
Claude se uită la contact-sheet și completează stiluri/al-meu.md: poziția textului, font, culori, B-roll, zoom.
"""
import argparse, json, os, subprocess, re
ap = argparse.ArgumentParser(); ap.add_argument("video"); ap.add_argument("--out", default=None); ap.add_argument("--thr", type=float, default=0.25)
a = ap.parse_args()
out = a.out or os.path.join("referinte", "stil-" + os.path.splitext(os.path.basename(a.video))[0]); os.makedirs(out, exist_ok=True)
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.video], capture_output=True, text=True).stdout.strip() or 0)
# 0) proxy mic, doar cadrele-cheie (screen record-urile au ~1/s): rapid pe orice calculator
proxy = os.path.join(out, "proxy.mp4")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-skip_frame", "nokey", "-i", a.video, "-an", "-vf", "scale=270:-2", "-vsync", "vfr", "-c:v", "libx264", "-preset", "ultrafast", proxy], check=True)
nproxy = int(subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-show_entries", "stream=nb_read_frames", "-of", "csv=p=0", proxy], capture_output=True, text=True).stdout.strip() or 1)
# 1) cadre, 1/s, în grilă (ecranul telefonului include UI-ul Instagram — se decupează 12% sus și 18% jos)
cols = 8; rows = max(1, int(dur // cols) + 1)
rows = max(1, (nproxy + cols - 1) // cols)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", proxy, "-vf", f"crop=iw:ih*0.70:0:ih*0.12,tile={cols}x{rows}", "-frames:v", "1", os.path.join(out, "contact-sheet.png")], check=True)
# 2) tăieturi (schimbări de scenă)
r = subprocess.run(["ffmpeg", "-loglevel", "info", "-i", proxy, "-vf", f"crop=iw:ih*0.70:0:ih*0.12,select='gt(scene,{a.thr})',showinfo", "-an", "-f", "null", "-"], capture_output=True, text=True)
times = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", r.stderr)]
# proxy-ul are ~1 cadru/s: timpii sunt în secunde reale (vsync vfr păstrează timestamp-urile)
gaps = [round(b - x, 2) for x, b in zip(times, times[1:])]
avg = round(sum(gaps) / len(gaps), 2) if gaps else None
json.dump({"duration": dur, "cuts": times, "cut_count": len(times), "avg_seconds_between_cuts": avg, "gaps": gaps}, open(os.path.join(out, "taieturi.json"), "w"), indent=1)
with open(os.path.join(out, "rezumat.md"), "w", encoding="utf-8") as f:
    f.write(f"# Referință: {os.path.basename(a.video)}\nDurată: {dur:.1f}s · tăieturi detectate: {len(times)} · în medie una la {avg}s\n\n")
    f.write("Claude completează din contact-sheet.png:\n- Poziția textului (sus / sub bărbie / centru) și dacă e un cuvânt sau fraze:\n- Font (serif / sans / bold / italic) și culori:\n- Cât B-roll (nimic / rar / la fiecare tăietură):\n- Zoom-uri (deloc / rare / dese):\n- Lumină și cadru (studio întunecat / lumină de zi / exterior):\n- Ritm: lent (>3s între tăieturi) / mediu (1.5–3s) / rapid (<1.5s):\n")
print(f"OK → {out}: contact-sheet.png, taieturi.json ({len(times)} tăieturi, ~1 la {avg}s), rezumat.md")
