#!/usr/bin/env python3
"""Detectează fața pe tot video-ul și scrie o cronologie a zonelor ocupate (cap, bărbie), ca textul să nu cadă niciodată pe față.
Folosire: python3 scripts/face_zones.py output/x/reel-curat.mp4 [--fps 4] [--out output/x/faces.json]
Scrie faces.json: {"fps":4,"frames":[{"t":0.25,"faces":[{"x":0.31,"y":0.12,"w":0.38,"h":0.28}]}, ...], "chin_max":0.52, "head_min":0.10}
Coordonatele sunt normalizate (0–1, y în jos). chin_max = cea mai joasă bărbie din tot clipul; head_min = cel mai înalt creștet.
"""
import argparse, json, subprocess, sys, tempfile, os
try:
    import cv2
except ImportError:
    sys.exit("Lipsește OpenCV. Instalează: pip install opencv-python-headless")
ap = argparse.ArgumentParser(); ap.add_argument("video"); ap.add_argument("--fps", type=float, default=4); ap.add_argument("--out", default=None)
a = ap.parse_args()
out = a.out or os.path.join(os.path.dirname(a.video), "faces.json")
tmp = tempfile.mkdtemp(prefix="faces_")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", a.video, "-vf", f"fps={a.fps},scale=360:-2", os.path.join(tmp, "f%05d.jpg")], check=True)
casc = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
prof = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml")
frames = []; files = sorted(os.listdir(tmp)); last = None
for i, fn in enumerate(files):
    img = cv2.imread(os.path.join(tmp, fn)); H, W = img.shape[:2]; g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    det = casc.detectMultiScale(g, 1.1, 5, minSize=(40, 40))
    if len(det) == 0: det = prof.detectMultiScale(g, 1.1, 5, minSize=(40, 40))
    faces = [{"x": round(x / W, 3), "y": round(y / H, 3), "w": round(w / W, 3), "h": round(h / H, 3)} for (x, y, w, h) in det]
    if not faces and last: faces = last  # cadru fără detecție: păstrăm ultima poziție (fața nu dispare, detectorul clipește)
    last = faces or last
    frames.append({"t": round(i / a.fps, 3), "faces": faces})
for f in os.listdir(tmp): os.unlink(os.path.join(tmp, f))
os.rmdir(tmp)
# bărbia ≈ y + h*1.12 (cascada taie sub buză); creștetul ≈ y - h*0.15 (păr)
chins = [f["y"] + f["h"] * 1.12 for fr in frames for f in fr["faces"]]
heads = [f["y"] - f["h"] * 0.15 for fr in frames for f in fr["faces"]]
res = {"fps": a.fps, "frames": frames, "chin_max": round(max(chins), 3) if chins else None, "head_min": round(max(0, min(heads)), 3) if heads else None,
       "detected_ratio": round(sum(1 for fr in frames if fr["faces"]) / max(1, len(frames)), 2)}
json.dump(res, open(out, "w"), indent=0)
print(f"OK → {out}: {len(frames)} cadre, față detectată în {int(res['detected_ratio']*100)}%; bărbia cel mai jos la {res['chin_max']}, creștetul cel mai sus la {res['head_min']}")
