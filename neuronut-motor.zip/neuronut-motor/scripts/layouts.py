#!/usr/bin/env python3
"""Aplică o identitate vizuală (identity.load) pe copertă, slide de carusel și story.
Reguli comune: text mare, lizibil pe telefon; zone sigure Instagram; textul nu stă pe față (detecție OpenCV când există).
"""
import os
from PIL import Image, ImageDraw, ImageFilter
from identity import font, hexc

W4x5, H4x5 = 1080, 1350
W9x16, H9x16 = 1080, 1920

def wrap(d, text, f, max_w, max_lines=None):
    lines = []
    for para in str(text).split("\n"):
        cur = ""
        for w in para.split():
            t = (cur + " " + w).strip()
            if d.textlength(t, font=f) <= max_w: cur = t
            else: lines.append(cur); cur = w
        lines.append(cur)
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]; lines[-1] = lines[-1].rstrip(".,") + "…"
    return lines

def fit_photo(path, W, H):
    im = Image.open(path).convert("RGB"); r = max(W / im.width, H / im.height)
    im = im.resize((int(im.width * r) + 1, int(im.height * r) + 1))
    x, y = (im.width - W) // 2, (im.height - H) // 2
    return im.crop((x, y, x + W, y + H))

def face_box(im):
    """(x,y,w,h) normalizat al feței celei mai mari, sau None"""
    try:
        import cv2, numpy as np
        g = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2GRAY)
        c = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        det = c.detectMultiScale(g, 1.1, 5, minSize=(60, 60))
        if len(det) == 0: return None
        x, y, w, h = max(det, key=lambda b: b[2] * b[3]); H, Wd = g.shape
        return (x / Wd, y / H, w / Wd, h / H)
    except Exception:
        return None

def gradient(im, color, start=0.45, strength=0.85, top=False):
    W, H = im.size; m = Image.new("L", (1, H))
    for y in range(H):
        t = (y / H - start) / (1 - start) if not top else ((1 - y / H) - start) / (1 - start)
        m.putpixel((0, y), int(255 * max(0, min(1, t)) ** 1.2 * strength))
    im.paste(Image.new("RGB", im.size, color), (0, 0), m.resize((W, H)))
    return im

def grid(d, W, H, color, step=120):
    for x in range(0, W, step): d.line([(x, 0), (x, H)], fill=color, width=1)
    for y in range(0, H, step): d.line([(0, y), (W, y)], fill=color, width=1)

def draw_title(d, cfg, title, accent, x, y, max_w, size, align="left", color=None):
    """Scrie titlul cu un cuvânt accentuat în fontul/culoarea de accent. Returnează înălțimea folosită."""
    tr = cfg["typography_rules"]; pal = cfg["color_palette"]
    txt = title.upper() if tr.get("case") == "upper" else title
    # micșorăm fontul (nu tăiem textul) până încape în max_title_lines, dar nu sub 62 % din mărime
    max_lines = tr.get("max_title_lines"); size0 = size
    while True:
        tf = font(cfg, "title", size, txt); lines = wrap(d, txt, tf, max_w)
        if not max_lines or len(lines) <= max_lines or size <= int(size0 * 0.55): break
        size = int(size * 0.92)
    lines = wrap(d, txt, tf, max_w, max_lines)
    af = font(cfg, "accent", int(size * (1.05 if cfg["style_id"] != "raw-human" else 0.95)), accent or txt)
    lh = int(size * 1.08); fg = color or hexc(pal["fg"]); acc = hexc(pal["accent"])
    acc_l = (accent or "").upper() if tr.get("case") == "upper" else (accent or "")
    for line in lines:
        lw = d.textlength(line, font=tf); cx = x if align == "left" else x + (max_w - lw) / 2
        if acc_l and acc_l.lower() in line.lower():
            k = line.lower().index(acc_l.lower()); parts = [(line[:k], tf, fg), (line[k:k+len(acc_l)], af, acc), (line[k+len(acc_l):], tf, fg)]
            for p, f, c in parts:
                d.text((cx, y), p, font=f, fill=c); cx += d.textlength(p, font=f)
        else:
            d.text((cx, y), line, font=tf, fill=fg)
        y += lh
    return lh * len(lines)

def cover(cfg, photo, title, accent, out, label=None):
    """Copertă 4:5. photo = cale imagine (cadru din reel sau poză). Textul evită fața."""
    W, H = W4x5, H4x5; pal = cfg["color_palette"]; tr = cfg["typography_rules"]; sid = cfg["style_id"]; M = 84
    base = fit_photo(photo, W, H) if photo and os.path.exists(photo) else Image.new("RGB", (W, H), hexc(pal["bg"]))
    fb = face_box(base) if photo else None
    im = base; d = ImageDraw.Draw(im)
    face_low = fb and (fb[1] + fb[3]) > 0.55   # fața e în jumătatea de jos → textul merge sus
    if sid == "raw-human":
        gradient(im, hexc(pal["bg"] if cfg["intensity"] != "bold" else pal["bg"]), start=0.35 if not face_low else 0.0, strength=0.9, top=face_low)
        d = ImageDraw.Draw(im); size = tr["title_size"]
        lines_h = int(size * 1.08) * min(tr.get("max_title_lines", 3), 3)
        y = M + 60 if face_low else H - 120 - lines_h
        used = draw_title(d, cfg, title, None, M, y, W - 2 * M, size, color=hexc(pal["fg"]))
        if accent:
            af = font(cfg, "accent", int(size * 0.9)); d.text((M, y + used + 6), accent, font=af, fill=hexc(pal["accent"]))
    elif sid == "experimental-creative":
        # bloc de culoare peste poză (decupaj), titlu supradimensionat care iese din margine
        ov = Image.new("RGB", (W, H), hexc(pal["surface"])); mask = Image.new("L", (W, H), 0)
        md = ImageDraw.Draw(mask); md.rectangle((0, 0, W, int(H * 0.58)) if not face_low else (0, int(H * 0.45), W, H), fill=215)
        im.paste(ov, (0, 0), mask); d = ImageDraw.Draw(im); size = tr["title_size"]
        y = M if not face_low else int(H * 0.47) + 30
        used = draw_title(d, cfg, title, accent, M - 10, y, W - M, size, color=hexc(pal["fg"]))
        d.rectangle((M, y + used + 24, M + 260, y + used + 46), fill=hexc(pal["accent"]))
    elif sid == "digital-editorial":
        canvas = Image.new("RGB", (W, H), hexc(pal["bg"])); d = ImageDraw.Draw(canvas)
        if cfg["background_rules"].get("grid"): grid(d, W, H, tuple(min(255, c + 22) for c in hexc(pal["bg"])))
        if photo and os.path.exists(photo):
            ph = fit_photo(photo, W - 2 * M, int(H * 0.46))
            canvas.paste(ph, (M, H - M - ph.height)); d.rectangle((M, H - M - ph.height, W - M, H - M), outline=hexc(pal["accent"]), width=3)
        mf = font(cfg, "accent", 30); d.text((M, M), (label or "01 — NEVO").upper(), font=mf, fill=hexc(pal["accent"]))
        d.rectangle((M, M + 48, M + 120, M + 52), fill=hexc(pal["accent"]))
        draw_title(d, cfg, title, accent, M, M + 84, W - 2 * M, tr["title_size"], color=hexc(pal["fg"]))
        im = canvas
    else:  # neurolab
        gradient(im, hexc(pal["bg"]), start=0.35, strength=0.85); d = ImageDraw.Draw(im); size = tr["title_size"]
        lines_h = int(size * 1.08) * 3; y = M if face_low else H - 120 - lines_h
        draw_title(d, cfg, title, accent, M, y, W - 2 * M, size)
    im.save(out, quality=92); return out

def slide(cfg, s, i, n, out, handle=""):
    """Un slide 4:5 de carusel. s = {title, body?, accent?, image?, cta?, cta_text?, label?}"""
    W, H = W4x5, H4x5; pal = cfg["color_palette"]; tr = cfg["typography_rules"]; sid = cfg["style_id"]; M = 90
    has_img = s.get("image") and os.path.exists(s["image"])
    if sid == "raw-human":
        im = fit_photo(s["image"], W, H) if has_img else Image.new("RGB", (W, H), hexc(pal["surface"] if i % 2 else pal["bg"]))
        if has_img: gradient(im, hexc(pal["bg"]), start=0.3, strength=0.9)
        d = ImageDraw.Draw(im); fg = hexc(pal["fg"]) if (not has_img or cfg["intensity"] == "bold") else hexc(pal["fg"])
        if has_img and cfg["intensity"] != "bold": fg = hexc(pal["fg"])
        size = tr["title_size"]; bf = font(cfg, "body", tr["body_size"])
        bl = wrap(d, s.get("body", ""), bf, W - 2 * M) if s.get("body") else []; blh = int(tr["body_size"] * 1.4)
        tl = len(wrap(d, s["title"], font(cfg, "title", size), W - 2 * M, tr.get("max_title_lines"))); block = int(size * 1.08) * tl + (30 + blh * len(bl) if bl else 0) + (70 if s.get("accent") else 0)
        y = H - M - 60 - block if has_img else (H - block) // 2
        used = draw_title(d, cfg, s["title"], None, M, y, W - 2 * M, size, color=fg); y += used
        if s.get("accent"): af = font(cfg, "accent", int(size * 0.85)); d.text((M, y + 4), s["accent"], font=af, fill=hexc(pal["accent"])); y += 70
        if bl: y += 24
        for line in bl: d.text((M, y), line, font=bf, fill=fg); y += blh
        if s.get("cta"):
            ct = s.get("cta_text", "Scrie-mi în DM"); cw = d.textlength(ct, font=bf) + 80
            d.rounded_rectangle((M, H - M - 100, M + cw, H - M - 10), radius=45, fill=hexc(pal["cta"])); d.text((M + 40, H - M - 78), ct, font=bf, fill=hexc(pal["cta_fg"]))
    elif sid == "experimental-creative":
        blocks = [pal["bg"], pal["surface"], pal["fg"]]; bgc = blocks[i % 3] if not has_img else pal["bg"]
        fgc = pal["fg"] if bgc != pal["fg"] else pal["bg"]
        im = Image.new("RGB", (W, H), hexc(bgc)); d = ImageDraw.Draw(im)
        if has_img:
            ph = fit_photo(s["image"], int(W * 0.62), int(H * 0.5)); im.paste(ph, (W - ph.width, H - ph.height))
            d.rectangle((W - ph.width, H - ph.height, W, H), outline=hexc(pal["accent"]), width=8)
        size = tr["title_size"]; y = M
        used = draw_title(d, cfg, s["title"], s.get("accent"), M - 8, y, W - M, size, color=hexc(fgc)); y += used + 20
        if s.get("body"):
            bf = font(cfg, "body", tr["body_size"]); blh = int(tr["body_size"] * 1.4)
            for line in wrap(d, s["body"], bf, int(W * 0.6) if has_img else W - 2 * M): d.text((M, y), line, font=bf, fill=hexc(fgc)); y += blh
        if s.get("cta"):
            d.rectangle((0, H - 170, W, H), fill=hexc(pal["accent"])); cf = font(cfg, "title", 52)
            d.text((M, H - 125), (s.get("cta_text", "Scrie-mi în DM")).upper(), font=cf, fill=hexc(pal["cta_fg"]))
    elif sid == "digital-editorial":
        im = Image.new("RGB", (W, H), hexc(pal["bg"])); d = ImageDraw.Draw(im)
        if cfg["background_rules"].get("grid"): grid(d, W, H, tuple(min(255, c + 22) if sum(hexc(pal["bg"])) < 380 else max(0, c - 18) for c in hexc(pal["bg"])))
        mf = font(cfg, "accent", 30); d.text((M, M), (s.get("label") or f"{i:02d} / {n:02d}").upper(), font=mf, fill=hexc(pal["accent"]))
        d.rectangle((M, M + 48, M + 120, M + 52), fill=hexc(pal["accent"])); y = M + 84
        y += draw_title(d, cfg, s["title"], s.get("accent"), M, y, W - 2 * M, tr["title_size"], color=hexc(pal["fg"])) + 24
        if s.get("body"):
            bf = font(cfg, "body", tr["body_size"]); blh = int(tr["body_size"] * 1.45)
            for line in wrap(d, s["body"], bf, W - 2 * M): d.text((M, y), line, font=bf, fill=hexc(pal["fg"])); y += blh
        if has_img:
            ph = fit_photo(s["image"], W - 2 * M, max(300, H - M - 40 - y - 20))
            if y + ph.height < H - M: im.paste(ph, (M, H - M - ph.height)); d.rectangle((M, H - M - ph.height, W - M, H - M), outline=hexc(pal["accent"]), width=3)
        if s.get("cta"):
            cf = font(cfg, "body", 44); ct = s.get("cta_text", "Scrie-mi în DM"); cw = d.textlength(ct, font=cf) + 72
            d.rectangle((M, H - M - 96, M + cw, H - M - 10), fill=hexc(pal["cta"])); d.text((M + 36, H - M - 76), ct, font=cf, fill=hexc(pal["cta_fg"]))
    else:  # neurolab (comportamentul vechi)
        im = fit_photo(s["image"], W, H) if has_img else Image.new("RGB", (W, H), hexc(pal["bg"]))
        if has_img: gradient(im, hexc(pal["bg"]), start=0.3, strength=0.9)
        d = ImageDraw.Draw(im); size = tr["title_size"]; bf = font(cfg, "body", tr["body_size"])
        bl = wrap(d, s.get("body", ""), bf, W - 2 * M) if s.get("body") else []; blh = int(tr["body_size"] * 1.35)
        tl = len(wrap(d, s["title"], font(cfg, "title", size), W - 2 * M)); block = int(size * 1.1) * tl + (30 + blh * len(bl) if bl else 0)
        y = H - M - 70 - block if has_img else (H - block) // 2
        y += draw_title(d, cfg, s["title"], s.get("accent"), M, y, W - 2 * M, size)
        if bl: y += 30
        for line in bl: d.text((M, y), line, font=bf, fill=hexc(pal["fg"])); y += blh
        if s.get("cta"):
            ct = s.get("cta_text", "Scrie-mi în DM"); cw = d.textlength(ct, font=bf) + 80
            d.rounded_rectangle((M, H - M - 100, M + cw, H - M - 10), radius=45, fill=hexc(pal["cta"])); d.text((M + 40, H - M - 78), ct, font=bf, fill=hexc(pal["cta_fg"]))
    # subsol
    d = ImageDraw.Draw(im); sf = font(cfg, "body", 30); fc = hexc(pal["accent"])
    d.text((M, H - 50), handle, font=sf, fill=fc); d.text((W - M - 80, H - 50), f"{i}/{n}", font=sf, fill=fc)
    if i < n: d.text((W - M - 10, H - 50), "→", font=sf, fill=fc)
    im.save(out); return out

def story(cfg, text, photo, out, sub=None):
    """Story 9:16: text în zona sigură (nu în primii 14 % și nu în ultimii 20 %)."""
    W, H = W9x16, H9x16; pal = cfg["color_palette"]; tr = cfg["typography_rules"]; sid = cfg["style_id"]; M = 90
    im = fit_photo(photo, W, H) if photo and os.path.exists(photo) else Image.new("RGB", (W, H), hexc(pal["bg"]))
    fb = face_box(im) if photo else None; face_low = fb and (fb[1] + fb[3]) > 0.5
    d = ImageDraw.Draw(im)
    if sid == "digital-editorial" and not photo: grid(d, W, H, tuple(min(255, c + 22) for c in hexc(pal["bg"])))
    if photo: gradient(im, hexc(pal["bg"]), start=0.0 if face_low else 0.45, strength=0.85, top=face_low); d = ImageDraw.Draw(im)
    size = int(tr["title_size"] * 0.95); tf = font(cfg, "title", size); lines = wrap(d, text.upper() if tr.get("case") == "upper" else text, tf, W - 2 * M, 4)
    block = int(size * 1.08) * len(lines) + (70 if sub else 0)
    y = int(H * 0.16) if face_low else H - int(H * 0.22) - block
    if sid == "digital-editorial": mf = font(cfg, "accent", 30); d.text((M, y - 50), "STORY".upper(), font=mf, fill=hexc(pal["accent"]))
    y += draw_title(d, cfg, text, None, M, y, W - 2 * M, size, color=hexc(pal["fg"]))
    if sub:
        sf = font(cfg, "accent" if sid == "raw-human" else "body", 56 if sid == "raw-human" else 46); d.text((M, y + 12), sub, font=sf, fill=hexc(pal["accent"]))
    im.save(out, quality=92); return out
