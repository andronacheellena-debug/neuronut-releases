# Licență de utilizare · Nevo by NeuroLab
Versiunea 1.1.1 · octombrie 2026 · © Elena Andronache / NeuroLab · elenaandronache.com

1. **Ce primești.** O licență personală, pentru o singură persoană, de a instala și folosi Nevo (acest pachet: instrucțiuni, skill-uri, scripturi, stiluri, identități vizuale) pe calculatoarele tale, pentru conținutul tău și al afacerii tale.
2. **Ce include.** Toate actualizările versiunii 1.x, livrate prin funcția de update din interiorul lui Nevo. Suportul se face prin NeuroLab, în condițiile comunicate la achiziție.
3. **Ce nu ai voie.** Să distribui, să revinzi, să închiriezi sau să publici pachetul ori părți din el (inclusiv CLAUDE.md, skill-urile și scripturile), să-l oferi altor persoane sau firme, ori să construiești din el un produs concurent. O licență = un om.
4. **Ce rămâne al tău.** Tot ce creezi cu Nevo — Fundamentul tău, scripturile, reel-urile, caruselele, caption-urile — îți aparține în întregime. Nevo nu trimite nimic din ele nicăieri; lucrează pe calculatorul tău.
5. **Ce nu e inclus.** Abonamentul Claude (Anthropic), conturile vidIQ, Apify, Metricool și CapCut — sunt ale tale, pe condițiile lor.
6. **Fonturile** din folderul `fonts/` sunt sub licența SIL Open Font License (vezi `fonts/OFL.txt`) și pot fi folosite liber în materialele tale.
7. **Fără garanție de rezultat.** Nevo e o unealtă; rezultatele depind de ce îi dai și de platformele externe (Claude, vidIQ, Instagram), care se pot schimba. NeuroLab nu răspunde pentru pierderi indirecte.
8. **Încălcarea licenței** duce la oprirea actualizărilor și a suportului, fără rambursare.
9. **Rambursare.** [de completat de Elena — ex.: 14 zile, dacă nu ai instalat; sau fără rambursare pentru produse digitale]

Prin instalare și folosire accepți termenii de mai sus. Întrebări: info@elenaandronache.com
