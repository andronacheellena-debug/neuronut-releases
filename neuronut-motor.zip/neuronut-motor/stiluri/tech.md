# Stil 2 · Tech (educațional, expert)
Referință: reel-ul Kallaway (studio întunecat, podcast), 21.10.2026.

Se aplică peste `stiluri/calitate.md` — regulile de acolo câștigă.

## Cadru și lumină
- Fundal întunecat, lumină de studio pe față, microfon vizibil e ok. Omul centrat.
- Punch-in de cel mult 10–15 % doar la schimbarea ideii (alternanță plan mediu / plan apropiat), niciodată la fiecare tăietură.

## Text pe ecran
- Subtitrări în MIJLOC (centru), albe, cu strălucire discretă, 2–4 cuvinte.
- Cuvântul-cheie în serif italic (Fraunces Italic) sau în ROȘU când e un cuvânt de contrast („generic”, „saturated”).
- Carduri de capitol: „01 · Numele pasului” cu o iconiță simplă, pe fundal întunecat cu grid fin, 1,5–2 s, între secțiuni.
- Nume + rol în colțul stânga-jos la prima apariție (bară roșie verticală + text monospace).

## Inserturi
- Diagrame simple animate (o formă, un gradient, o linie care urcă) pentru conceptele abstracte.
- Screenshot-uri ale uneltelor (interfața reală) cu omul în picture-in-picture jos.
- Inserție la fiecare 5–8 s. Omul nu stă niciodată mai mult de 8 s fără schimbare de cadru sau inserție.

## Ritm
- Toate pauzele se taie. Tăieturi dese. 40–60 s.

## Sunet
- Voce apropiată (microfon); muzică electronică joasă la -22 dB.

## Preset render
`--preset tech` → subtitrări centru, alb cu umbră, 3 cuvinte, fără uppercase, hook sus.
