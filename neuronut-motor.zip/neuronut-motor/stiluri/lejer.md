# Stil 1 · Lejer (educațional, creator)
Referință: reel-ul jun_yuh (bucătărie, lumină de zi), 15.10.2026.

Se aplică peste `stiluri/calitate.md` — regulile de acolo câștigă.

## Cadru și lumină
- Telefon sprijinit pe masă sau în mână, ușor de jos; omul la masă, relaxat. Lumină naturală, fundal luminos (bucătărie, birou).
- Filmare dintr-un singur cadru; fără zoom-uri agresive.

## Text pe ecran
- Subtitrări SUS (treimea de sus), 1–3 cuvinte, text întunecat (ink) pe fundal luminos, fără contur gros.
- Cuvântul-cheie al frazei în serif italic (Fraunces Italic) — „finally take action”, „believe it”.
- Fără majuscule forțate. Punctuație normală.
- Hook-ul: nu există card separat — primele cuvinte spuse SUNT hook-ul, în aceeași poziție. (render.py ignoră --hook pe acest preset.)

## Inserturi
- La fiecare 8–12 s o inserție de 1–2 s: screenshot (notițe, aplicație), o carte de text pe fundal luminos („day in my life”), un sticker-emoji (📅) lângă cuvântul spus.
- Inserțiile acoperă partea de sus, omul rămâne vizibil jos.

## Ritm
- Pauze > 0,7 s se taie; se păstrează râsul și reacțiile.
- Tăieturi la schimbarea ideii, nu la fiecare propoziție. 30–45 s.

## Sunet
- Vocea curată; muzică ambientală la -25 dB sau deloc.

## Preset render
`--preset lejer` → subtitrări sus, ink pe fundal deschis, 3 cuvinte, fără uppercase.
