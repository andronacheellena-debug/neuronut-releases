# Reguli de calitate — obligatorii, pe orice stil
Se aplică înaintea oricărui stil. Dacă un stil le contrazice, câștigă acestea.

## Cadrul
- Niciodată deformat. Raportul de aspect se păstrează; dacă sursa nu e 9:16, se decupează (crop) centrat pe față sau se completează cu fundal blurat. Nu se întinde.
- Fața e în treimea de sus a cadrului. Decuparea urmărește fața, nu centrul geometric.
- Zoom-urile sunt rare și mici: cel mult 10–15 % și doar la schimbarea ideii, nu la fiecare tăietură. Fără zoom in/out alternat ca un balansoar.

## Textul
- Poziția textului se calculează cadru cu cadru din `faces.json` (face_zones.py): omul se mișcă, textul se mută — sub bărbie când capul coboară, deasupra capului când jos nu e loc. O poziție fixă „bună la început” nu e suficientă.
- NICIODATĂ pe față, pe gât, pe piept-sus sau pe mâini când gesticulează. Nimic între sprâncene și claviculă. Zone sigure: hook-ul în 10–20 % de sus; subtitrările sub bărbie, între 68 % și 78 % din înălțime; pe stilul Dinamic, cuvântul singur la 60–70 %. Dacă persoana e filmată foarte de aproape, textul coboară, nu urcă.
- Zonele moarte ale platformei: nimic sub 85 % (butoane Instagram) și nimic în primii 8 % (bara de sus).
- Un singur element de text pe ecran la un moment dat. Hook-ul dispare înainte să apară prima subtitrare.
- Fonturile din pachet (Fraunces, Space Grotesk) sau cele din stilul omului. Nu Montserrat, nu Impact, nu Arial.
- Text mare, lizibil pe telefon: minim 60 px la 1080 lățime pentru subtitrări, 90 px pentru hook. Dacă nu încape, scurtezi textul, nu micșorezi fontul.

## Tăieturile (dinamica e regula)
- **Nicio literă pierdută.** Nu tai niciodată în interiorul unui cuvânt: tăietura se mută la marginea cuvântului, cu 0,12 s aer (cut_plan.py o face automat). Dacă e de ales între a tăia o literă și a păstra 0,3 s în plus, păstrezi. „Spoiler”, nu „poiler”; „zece”, nu „ece”.
- **Niciun gol.** Respirații, priviri într-o parte, „aaa”, „ăăă”, „mm” — ies toate, și cele scurte. Între două propoziții rămâne doar aerul minim.
- **Nicio frază tăiată înainte să se termine.** Segmentul se închide la sfârșitul propoziției.
- **Între idei: tranziție din biblioteca CapCut a omului**, nu tăietură seacă.
- **Asculți rezultatul** înainte să-l dai, nu doar te uiți la cadre.
- Ies: respirațiile, gândirea, pauzele, umpluturile, cuvintele duble, luările repetate. Reel-ul e strâns ca al referințelor — nimic nu „așteaptă”. Pragul implicit: pauze > 0,28 s se taie; rămâne aer minim (0,1 s), nu respirație.
- O pauză rămâne doar dacă e intenționată și marcată în script („[pauză]” înainte de ideea importantă) — atunci o treci în `--keep-at`.
- Verifici și SUNETUL, nu doar cadrele: asculți (sau citești forma de undă) ca să nu rămână respirații între tăieturi.

## Tranzițiile și efectele sonore (din CapCut-ul omului, nu generate)
- Tranzițiile și sunetele de tranziție vin DOAR din biblioteca CapCut a omului: cele folosite în proiectele lui sau cele din referințele lui. Scriptul nu generează whoosh/ding; `capcut_draft.py --fx-from-template` le copiază din proiectul-șablon pe fiecare tăietură.
- Fără tranziții generice de 2015 (fade alb, wipe, glisare) dacă nu sunt în referință.
- Un „hit” sonor pe cuvintele-cheie marcate în script (ex. „fraudă”, „țeapă”), tot din biblioteca lui.
- mp4-ul final randat de script e versiunea curată (tăieturi strânse, subtitrări). Versiunea cu tranziții și sunete e proiectul CapCut — asta e versiunea de postat când omul are CapCut.

## Sunetul
- Fără sunete sintetizate de script. Efectele vin din CapCut (vezi mai sus).
- Muzică doar dacă omul pune o piesă în `inbox/muzica/` sau alege una în CapCut din biblioteca lui. Nu se descarcă muzică de pe net.
- Vocea e normalizată (prep.py). Nimic nu acoperă vocea.

## Ce nu faci niciodată (3 noiembrie)
- Nu livrezi previewul ca final: finalul e `reel-final.mp4`, 1080×1920, randat fără `--preview`. Previewul (`reel-preview.mp4`, 540×960) e doar pentru feedback.
- Nu refaci clipul mare după o corectură: corecturile se fac pe preview, finalul o singură dată.
- Nu ghicești între două sunete: arăți cuvintele cu timpii lor și întrebi o dată.
- Nu scoți o frază rostită și n-o înlocuiești cu text: cauți luarea bună în toate clipurile (find_take.py) sau ceri refilmarea frazei.
- Nu promiți „30 de minute” fără să fi verificat: spui timpul după ce știi ce randezi.

## Verificarea înainte de livrare (obligatorie)
Extragi 4 cadre (la 10 %, 35 %, 60 %, 85 % din durată) și te uiți la ele. Pentru fiecare: fața e întreagă și nedeformată? textul e sub claviculă / peste cap — nu pe față, gât sau mâini? un singur text pe ecran? Dacă oricare e „nu”, corectezi și re-randezi. Nu livrezi ce n-ai văzut.
