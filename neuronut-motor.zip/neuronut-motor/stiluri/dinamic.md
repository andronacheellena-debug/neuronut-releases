# Stil 3 · Dinamic (publicitate, produs)
Referință: reel-ul wesmokefishmd (raci, știri citate), 20.10.2026.

Se aplică peste `stiluri/calitate.md` — regulile de acolo câștigă.

## Cadru și lumină
- Omul cu produsul în mână sau lângă produs; fundal de lucru real (bucătărie, atelier, magazin). Lumină puternică, culori saturate.

## Text pe ecran
- UN SINGUR CUVÂNT pe ecran, alb bold cu contur, jos-centru (puțin sub mijloc), apare exact pe cuvântul spus.
- Fără hook static: hook-ul e o întrebare spusă în primele 2 s, cu cuvântul-cheie pe ecran.

## Inserturi (esențiale în acest stil)
- Tăietură la fiecare 1–2 s pe B-roll: produsul de aproape, procesul, mâinile, apoi SURSE citate (screenshot de articol, studiu, știre) ca dovadă — cu titlul lizibil.
- Omul revine în cadru la fiecare 4–6 s. Nimic nu stă pe ecran mai mult de 2 s.
- B-roll-ul se filmează odată cu reel-ul: 10–15 clipuri de câte 3–5 s, listate de Nevo în script („B-ROLL: …”).

## Ritm
- Pauze > 0,4 s se taie. Vorbire rapidă. 20–35 s.

## Sunet
- Voce + muzică ritmată la -18 dB, doar dacă omul a dat o piesă. Fără efecte sonore sintetizate.

## Preset render
`--preset dinamic` → un cuvânt, alb bold cu contur, jos-centru, hook fără card.
B-roll-ul nu se montează automat în v0.2: Nevo pune clipurile în ordine în draft-ul CapCut sau în taieturi.md, cu secunda la care intră fiecare.
