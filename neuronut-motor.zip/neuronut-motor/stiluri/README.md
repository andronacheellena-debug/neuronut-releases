# Stilurile de montaj Neuronuț
La primul montaj, Neuronuț întreabă o singură dată: „În ce stil montăm?”
1. **Lejer** — stiluri/lejer.md
2. **Tech** — stiluri/tech.md
3. **Dinamic** — stiluri/dinamic.md
4. **Al meu** — omul dă 2–3 reel-uri care îi plac + fonturi + culori + un sunet; Neuronuț scrie stiluri/al-meu.md după aceleași rubrici
5. **Din CapCut-ul meu** — Neuronuț citește proiectele CapCut existente (fonturi, poziția textului, ritm, tranziții) și scrie stiluri/al-meu.md

Alegerea se notează în fundament/preferinte-montaj.md („Stil: tech, 21.10”) și nu se mai întreabă.
Fiecare stil are un preset în scripts/render.py (--preset lejer|tech|dinamic) și reguli pentru ce nu face scriptul (B-roll, carduri, zoom-uri) — acelea se aplică în CapCut sau în draft-ul CapCut generat.
