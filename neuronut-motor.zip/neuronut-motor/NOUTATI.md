Gata. De acum, înainte să scriu ceva, te întreb ce ai de spus și te ascult. La final îți arăt pe scurt ce am îndreptat din ce mi-ai dictat, ca să vezi că textul a rămas al tău.
