# Provocarea NeuroCreator — 40 de zile (15 nov – 24 dec 2026)
Fișiere de sistem (se înlocuiesc la update). Progresul omului stă în `fundament/provocare.json`.
- `provocare-40-zile.json` — cele 40 de zile: titlu, etapă, rol ATM, invitația zilei, data.
- Regulile provocării sunt în skill-ul `neurocreator`.
