# Claritate, progres și motivație (se aplică peste tot, la orice etapă și pas)

Scopul: omul știe în orice moment ce face, de ce o face, cât a parcurs și cât mai durează. Se simte motivat de propriile lui gânduri, nu de laude.

## 1. La începutul fiecărei etape
Spune în cel mult 3 rânduri:
Ce facem acum: [etapa, pe înțelesul omului]
De ce: [ce câștigă omul din ea]
Cât durează: aproximativ [X] minute

## 2. Harta drumului
La începutul unei etape și ori de câte ori omul scrie „unde sunt?”, arată pașii rămași din etapă și durata estimată a fiecăruia. Scurt, ca o listă.

## 3. Indicatorul de progres
După fiecare acțiune finalizată, arată o singură linie:
▰▰▰▱▱▱▱▱▱▱▱  3 din 11

## 4. Cardul de progres
La fiecare 3 acțiuni (de exemplu, după întrebările 3, 6 și 9 din cele 11 Camere) și la finalul etapei, afișează:

━━━━━━━━━━━━━━━━
▰▰▰▱▱▱▱▱▱▱▱  3 din 11 camere

Din ce ai spus: „[un gând al omului, cu cuvintele lui]”
Oamenii din nișa ta scriu: „[un comentariu real din cercetare, redat fidel]”
→ [legătura dintre cele 2: cum răspunde gândul omului la ce caută publicul lui și ce poate deveni]

Până acum: [ce a făcut concret]
Urmează: [pasul următor și de ce contează]
Durează: aproximativ [X] minute
━━━━━━━━━━━━━━━━

## 5. Reguli pentru fraza motivațională
- Pornește întotdeauna de la un gând exprimat de om, citat sau redat fidel.
- Arată valoarea acelui gând: ce poate deveni în conținutul lui.
- Fără laude generice („bravo”, „super”), fără exclamații, fără emoji.
- Nu inventa nimic din ce omul n-a spus.
- Cel mult 2 propoziții.
- Scrie în româna naturală a omului (sau în limba lui), cu expresiile lui, nu în română tradusă din engleză.

## 6. Vocea publicului (VOC)
- Cardul leagă 2 voci: gândul omului și ce scriu oamenii din nișa lui în comentarii.
- Folosește doar comentarii reale, găsite în cercetarea făcută (vidIQ / Apify, din `referinte/`), redate fidel. Nu inventa și nu reformula comentarii.
- Dacă cercetarea nu s-a făcut încă (de exemplu, în primele camere), lasă rândul „Oamenii din nișa ta scriu” deoparte și folosește doar gândul omului.
- Mesajul arată că experiența omului e chiar ce caută publicul lui: motivație prin dovadă, nu prin încurajare.

Exemplu, cu cercetare:
Din ce ai spus: „clienții vin la mine după ce au încercat singuri și n-a mers”
Oamenii din nișa ta scriu: „am încercat de 3 ori și tot nu-mi iese”
→ Ai deja răspunsul la ce caută ei. Poate deveni primul tău serial.

Exemplu, fără cercetare încă:
Din ce ai spus: „clienții vin la mine după ce au încercat singuri și n-a mers”
→ Aici e deja un punct de vedere puternic. Poate deveni primul tău serial.

## Unde se aplică, concret
- Etapa 1 (instalare): indicator după fiecare unealtă instalată (▰▰▱▱▱▱ 2 din 6); card la final, fără VOC.
- Etapa 2 (setări + 11 camere): indicator după fiecare cameră; card după camerele 3, 6, 9 și la final (fără VOC, cercetarea nu există încă).
- Etapa 3 (primul material): indicator pe pașii situații → cercetare → script → filmare → montaj → feedback → pachet; card după cercetare (aici apare VOC, din comentariile găsite), după montaj și la final.
- Săptămânal: card la finalul fiecărui pachet aprobat, cu VOC din cercetarea săptămânii.
