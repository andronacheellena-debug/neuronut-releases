---
name: caption
description: Funcțiile 8–9 — Caption-uri. Pentru reel: caption, primul comentariu, 3 stories de însoțire, CTA. Pentru carusel: caption + CTA. Toate în vocea omului, cu decizia ATTRACT/CONVERT. Folosește după montaj sau carusel.
---
# Caption-uri

## Reel
- Caption: 2–5 rânduri. Primul rând e un al doilea hook (altul decât cel din video), pentru cine citește înainte să dea sunetul. Apoi ideea într-o frază și pasul următor.
- Primul comentariu: contextul sau întrebarea care deschide discuția; aici pot sta și hashtag-urile (5–8, din nișă, nu generice).
- 3 stories de însoțire: (1) „am postat un reel despre…” cu întrebarea reel-ului, (2) un sondaj sau o întrebare deschisă pe același semnal, (3) CTA-ul reel-ului cu link/cuvânt-cheie.
- CTA: ATTRACT → salvează / trimite cuiva / comentează un cuvânt; CONVERT → scrie-mi „X” în DM / link în bio.

## Carusel
- Caption: 3–6 rânduri; primul rând reia hook-ul slide-ului 1 cu alte cuvinte; la final, CTA-ul de pe ultimul slide.

## Reguli
- Scrii după `stiluri/scriere.md` (regulile Elenei: română nativă, fără calcuri, fără antiteze-slogan, nimic inventat, un singur text) și vocea din `fundament/reguli-voce.md` + `fundament/corecturi.md`. Fără emoji-uri în cascadă, fără „✨”, fără clickbait.
- Niciun fapt nou față de script și Fundament.
- Livrezi tot într-un singur fișier `output/<dir>/captions.md`, gata de copiat, cu etichete clare: CAPTION REEL / PRIMUL COMENTARIU / STORY 1-3 / CAPTION CARUSEL.
