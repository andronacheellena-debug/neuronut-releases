---
name: indicatori
description: Cei 3 indicatori ai contului omului — trimiteri raportate la reach, aprecieri raportate la reach, timp mediu de vizionare — citiți din contul lui de Instagram prin vidIQ (vidiq_instagram_owner_insights). Folosește o dată pe săptămână, la „indicatori”, la „cum au mers reel-urile” sau înainte de semnalul săptămânal, ca scripturile noi să plece de la ce a funcționat la EL, nu doar în nișă.
---
# Indicatori

## Precondiție
Contul de Instagram al omului conectat în vidIQ (`vidiq_social_account_list` → platformAccountId). Dacă nu e: „Ca să văd cum merg reel-urile tale, am nevoie ca Instagramul tău să fie legat în vidIQ — o singură dată.” → `vidiq_social_account_connect` (platform INSTAGRAM, mode oauth). Fără cont conectat nu inventezi cifre; spui că folosești doar datele din nișă.

## Ce citești
`vidiq_instagram_owner_insights` cu `mode: reels`, ultimele 30 de zile (sau de la ultimul raport). Pentru fiecare reel: reach, shares, likes, saves, comentarii, timp mediu de vizionare, procent vizionat, skip rate.

## Ce calculezi și cum le spui omului (fără jargon)
- **Trimis mai departe**: shares ÷ reach. „Din 100 de oameni care l-au văzut, X l-au trimis cuiva.”
- **Apreciat**: likes ÷ reach. „Din 100, Y au apăsat inimioara.”
- **Timp de vizionare**: secundele medii și procentul vizionat. „Oamenii au stat Z secunde din N; cei mai mulți au plecat la secunda K.”
Tabel simplu, un rând per reel, ordonat după „trimis mai departe”. Sub tabel, în 3 propoziții: ce a fost trimis cel mai mult și de ce crezi (hook, subiect, dovadă), unde se pierde atenția (secunda, și ce era acolo în script), și o singură schimbare pentru reel-ul următor.

## Ce salvezi
`fundament/indicatori.md` — la fiecare rulare adaugi data și cele 3 propoziții + rândul celui mai bun reel. Scenariile (`scenariu-reel`) citesc fișierul ăsta: hook-urile și subiectele care au fost trimise mai departe au prioritate; secunda la care pleacă oamenii devine limita până la care miezul trebuie să fi apărut.

## Reguli
- Cifre doar din contul omului. Nu compari cu alte conturi (acolo trimiterile nu sunt publice).
- Nu lauzi, nu consolezi. Un reel netrimis nu e rău — e o informație: subiectul sau hook-ul nu a avut un „cui să-l trimit”.
- Întrebarea de verificat la fiecare script nou rămâne: „Ar trimite cineva asta unui prieten?”
