---
name: semnal-saptamanal
description: Funcția 3 — Brain Download săptămânal. Din voice note-ul cu 3 situații din afacere scoate 3 semnale clasificate Attract / Convert / Both / Neither, cu unghiul propus. Folosește când omul scrie „start”, pune un voice note în inbox/ sau dictează ce i s-a întâmplat săptămâna asta.
---
# Semnalul săptămânal

## Deschiderea
Prima dată, înainte să ceri situațiile: „Conținutul tău există deja în viața ta. Hai să te ajut să-l identifici.” Apoi: „Spune-mi 3 situații din săptămâna asta din afacerea ta care te-au atins într-un fel — emoțional, curios sau cu umor.”

## Ce intră
Un voice note (inbox/*.m4a|mp3|wav|mp4) sau text dictat: 3 situații care s-au întâmplat în afacerea omului și l-au atins într-un fel — emoțional, curios sau cu umor.

Dacă e audio: `python3 scripts/transcribe.py <fisier> ro --model medium` (modelul mediu e de ajuns pentru voice note).

## Ce faci
1. Citești `fundament/fundament.md` (client ideal, oferta, transformarea, scopul conținutului).
2. Pentru fiecare situație, extragi SEMNALUL, nu povestea (RAW → SIGNAL, ca în Misiunea 8):
   - RAW: „azi un client m-a întrebat X”
   - SIGNAL: „a treia oară când cineva întreabă X” / „aici e o convingere greșită în nișă” / „asta e dovadă că metoda merge”
3. Clasifici fiecare semnal:
   - ATTRACT — îl face pe omul potrivit să se recunoască și să vină mai aproape
   - CONVERT — îl ajută să înțeleagă, să aibă încredere, să vadă dovada, să considere oferta
   - BOTH
   - NEITHER — atunci nu publicăm doar ca să avem conținut; spui de ce
4. Propui pentru fiecare semnal: unghiul (ideea centrală într-o frază), formatul potrivit (reel / carusel / ambele) și de ce ar salva sau trimite cineva materialul.

## Ce livrezi
Un tabel scurt, în chat, nu un document:

| # | Situația (3 cuvinte) | Semnalul | Decizia | Unghiul | Format |

Salvezi rezultatul în `output/<data>-semnale.md`.

Apoi NU întrebi „cu care mergem?”. Decizia e a ta, pe date. Spui o singură propoziție — „Acum începem cercetarea: văd ce a performat în nișa ta pe aceste trei teme și îți propun cu care pornim.” — și treci direct la skill-ul `research`, pe toate semnalele valide (nu pe cele NEITHER).

## Reguli
- Nu adaugi situații. Dacă omul a dat două, lucrezi cu două.
- Nu inventezi detalii ca să „rotunjești” povestea. Ce lipsește → `[GOL: …]`.
- Dacă două situații duc la același semnal, le unești și spui asta.
- Omul nu alege între semnale. Tu alegi, după research, și îi arăți de ce. El corectează doar dacă vrea.

## Progres (PROGRES.md)
Indicator după fiecare situație (`▰▱▱  1 din 3`); la a 3-a, cardul de progres cu un gând al omului citat, fără VOC (urmează cercetarea).
