---
name: research
description: Funcția 4 — Research prin vidIQ. Pentru un semnal ales, găsește ce a performat în nișa omului pe Instagram Reels (și TikTok), ce întreabă oamenii în comentarii, și extrage hook-uri și structuri care au mers. Folosește înainte de orice scenariu.
---
# Research

## Precondiție: vidIQ conectat
Conexiunea vidIQ e deja în pachet (`.mcp.json`, în rădăcina folderului). Omul NU scrie nicio comandă. Verifică dacă uneltele vidIQ sunt vizibile (vidiq_instagram_tiktok_outlier_search, vidiq_comment_insights, vidiq_score_title…). Dacă nu sunt, îl ghidezi concret, pas cu pas, ca pe cineva care nu a mai făcut asta niciodată — fără termeni tehnici, fără „MCP”, fără comenzi:

„Pentru cercetare folosesc vidIQ — aplicația prin care văd ce reel-uri și carusele performează acum în nișa ta, pe subiectul tău, aliniat cu scopul tău. Fără ea aș ghici, și eu nu ghicesc. Trei pași, o singură dată:
1. Deschide vidiq.com și fă-ți un cont gratuit (butonul de înregistrare, nu pagina de prețuri). Contul gratuit e de ajuns pentru început.
2. Închide fereastra asta și deschide din nou folderul neuronut-motor în Claude (tab-ul Code). Vei fi întrebat dacă permiți serverul „vidiq” din proiect — apasă Da.
3. Se deschide o pagină în browser: loghează-te cu contul vidIQ pe care tocmai l-ai făcut. Apoi revino aici și scrie «gata».”

Dacă după „gata” uneltele tot nu apar: spune-i să închidă și să redeschidă folderul încă o dată (uneltele noi apar doar la început de sesiune). Dacă nici atunci — îi spui exact ce nu merge și îl rogi să-i trimită Elenei mesajul. Nu-l lași să se descurce singur.

Nu improvizezi date de research niciodată. Nu există „research simulat”. Dacă omul scrie „mergem mai departe” fără vidIQ, răspunzi: „Mai departe înseamnă research real. Hai să conectăm vidIQ — îți arăt pașii din nou” și îi dai cei 3 pași. Contul gratuit vidIQ ajunge pentru primele săptămâni; abonamentul e decizia omului, mai târziu, dacă sistemul îi place.

## Când vidIQ nu dă destule date → Apify
Praguri: sub 8 reel-uri relevante pe temă, sau zero comentarii din nișă → treci pe Apify (conexiunea e în `.mcp.json`; omul are nevoie de cont gratuit pe apify.com, creditele gratuite ajung pentru research). Folosești actorii Instagram (instagram-reel-scraper / instagram-scraper pe 3–5 conturi din nișă, instagram-comment-scraper pe cele mai bune 10 reel-uri). Ceri permisiunea înainte, într-o propoziție: „Pe tema asta vidIQ a găsit puțin; pot lua datele direct de pe Instagram prin Apify (contul tău gratuit). Da?” Notezi în referințe de unde vine fiecare dată. Dacă Apify nu e conectat, îi dai pașii (cont → redeschide folderul → „Da” → login) — nu improvizezi.

## Ce faci
1. Din `fundament/fundament.md` iei: nișa, clientul ideal, limba, 3–5 cuvinte-cheie ale nișei (în română și, dacă nișa e internațională, în engleză).
2. Pentru semnalul ales, cauți pe Instagram Reels (și TikTok) outlier-e din ultimele 30–90 de zile pe tema semnalului. Reții 10–20 de piese: hook-ul (primele 1–2 propoziții), structura (problemă → răsturnare → dovadă → CTA etc.), durata, de ce a mers.
3. Rulezi comment insights pe nișă: ce cer oamenii, de ce se plâng, cum formulează ei problema — cu cuvintele lor.
4. Sintetizezi în `referinte/<data>-<slug>.md`:
   - 5–8 hook-uri care au mers (reformulate în română, nu traduse cuvânt cu cuvânt), fiecare cu de ce a mers
   - 3 structuri de reel care revin
   - 10 formulări reale din comentarii (VOC), cu ghilimele
   - 3 lucruri pe care nișa le crede greșit sau nu le spune nimeni
5. Scorezi 3 variante de hook pentru fiecare semnal cu vidiq_score_title.
## Cei 3 indicatori (ordonarea reel-urilor)
Instagram împinge reel-urile după 3 lucruri: cât de des sunt TRIMISE unui prieten (sends per reach), câte aprecieri strâng raportat la câți le văd (likes per reach) și cât timp stau oamenii pe ele (average watch time). Research-ul se ordonează după ele, nu după vizualizări brute:
- Din datele publice ai: vizualizări, aprecieri, comentarii, multiplul față de media creatorului (`vidiq_ig_profile_reels`, outlier search). Calculezi aprecieri ÷ vizualizări și comentarii ÷ vizualizări și pui sus reel-urile cu raport mare, nu pe cele cu cele mai multe vizualizări. Un reel cu 40K vizualizări și 6% aprecieri bate unul cu 700K și 0,4%.
- Trimiterile și timpul de vizionare NU sunt publice. Pentru ele faci „testul prietenului”: la fiecare reel reținut răspunzi într-o propoziție „Cine ar trimite asta cui, și de ce?”. Dacă nu ai un răspuns concret, reel-ul nu intră în referințe, oricâte vizualizări are.
- În `referinte/` notezi la fiecare piesă: vizualizări, aprecieri ÷ vizualizări, multiplul și răspunsul la testul prietenului. Aceste 3 lucruri decid ordinea.
- Cifrele reale pentru trimiteri și timp de vizionare există doar pe contul omului: vezi skill-ul `indicatori`.


## Decizia (a ta, nu a omului)
După research pe toate semnalele, alegi UNUL cu care pornim, după: (a) scopul omului din Fundament (awareness / comunitate / vânzări), (b) ce a performat în nișă pe tema respectivă, (c) ce cer oamenii în comentarii, (d) dovada pe care o are omul. Îi spui în 3–4 propoziții: cu ce pornim, de ce (cu cifre din research), și ce facem cu celelalte două (săptămâna viitoare / carusel). Apoi treci direct la `scenariu-reel` și îi arăți scriptul. El corectează dacă vrea — nu alege dintr-o listă.

## Reguli
- Referințele sunt pentru structură și limbaj, nu pentru copiat. Nu reproduci textul altora în scenarii.
- Notezi sursa (cont, dată, performanță) la fiecare referință, ca omul să poată verifica.
- Dacă nișa e mică și nu ies destule date în română, extinzi la nișa-mamă și spui asta.

## Progres (PROGRES.md)
După cercetare, cardul de progres cu rândul VOC completat din comentariile REALE găsite (citate fidel, cu sursa în referinte/). Acesta e singurul loc din care vin comentariile pentru cardurile următoare.

## Protecția datelor
În interogările către vidIQ/Apify intră doar cuvinte-cheie despre nișă și temă. Niciodată fragmente din Fundament, nume de clienți, cifre de afaceri, mesaje sau comentarii primite de om.
