---
name: brain-download
description: Etapa 2 — „Hai să ne cunoaștem.” Nevo parcurge cu omul workbook-ul NeuroCreator „Conținutul care îți aduce clienți” (fundament/cele-11-camere.md, sau PDF-ul pe care omul îl atașează), întrebare cu întrebare, cu voce, pe bucăți dacă e nevoie; salvează răspunsurile cu cuvintele omului, învață cum vorbește, apoi scrie Fundamentul. Folosește când fundament.md e gol, când omul scrie „cunoaște-mă”, când atașează sau pune în fundament/ PDF-ul workbook-ului ori cere să răspundă la workbook împreună cu Nevo.
---
# Etapa 2 · Hai să ne cunoaștem (workbook-ul, cu voce)

## Deschiderea (exact, text aprobat de Elena)
„Etapa 2 din 4: hai să ne cunoaștem. Parcurgem împreună workbook-ul „Conținutul care îți aduce clienți”: 11 camere, câte o întrebare pe rând. Tu îmi răspunzi cu voce, cu cuvintele tale, cum ai vorbi cu un prieten. Eu notez tot și învăț cum vorbești, ca scripturile să sune a tine. Nu trebuie să fie perfect, iar la ce nu știi spui „sar”. Îl putem face pe bucăți: când te oprești, scrii „start” data viitoare și continuăm din camera în care am rămas.”

## De unde iei întrebările
- Implicit: toate întrebările din `fundament/cele-11-camere.md` (camerele 1–11, întrebarea CHEIE prima, apoi celelalte din cameră, în ordine). Camera 12 nu e întrebare: e planul pe 7 zile pe care îl construiești TU după.
- Dacă omul atașează în chat sau pune în `fundament/` PDF-ul workbook-ului: îl citești întâi.
  - Dacă e necompletat: iei întrebările din el, în ordinea lui (sunt aceleași camere).
  - Dacă are deja răspunsuri scrise: le preiei cu cuvintele omului în `fundament/workbook-raspunsuri.md` și pui doar întrebările rămase goale.
- La fel pentru Blueprint-ul NeuroLab sau documentul cu cele 11 camere din ChatGPT: ce e acoperit nu mai întrebi.

## Regulile
- O singură întrebare pe mesaj. Înainte de ea scrii unde suntem: „Camera 3 din 11 · întrebarea 2 din 5”.
- Omul răspunde cu voce, cum vorbește. Nu îi corectezi și nu îi rescrii răspunsul. Dacă e mai scurt de o propoziție, poți întreba o singură dată: „Îmi dai un exemplu?”. La „sar” treci mai departe și notezi întrebarea ca sărită.
- După FIECARE răspuns îl salvezi imediat, exact cum l-a spus, în `fundament/workbook-raspunsuri.md`, sub camera și întrebarea lui. Așa nu se pierde nimic dacă omul pleacă.
- Ții locul în `fundament/stare.json` → `workbook`: camera și întrebarea la care ați rămas. La următorul „start”: „Continuăm workbook-ul: camera N, întrebarea M.” Nu reiei de la început și nu întrebi a doua oară ce ai deja.
- Din felul în care vorbește omul actualizezi `fundament/reguli-voce.md` după fiecare cameră: expresiile lui, cum își construiește frazele, cuvintele pe care le folosește des. Doar ce a spus el; nu adaugi nimic.
- La sfârșitul fiecărei camere: o propoziție de reper („Camera 4 e gata. Urmează camera 5, despre convingerile tale.”) și cât mai e aproximativ.
- Nu Human Design, nu arhetipuri, nu astrologie: dacă omul le aduce, le notezi în fundament ca „ce vrea să transmită” (o linie) și mergi mai departe.

## Închiderea
Când toate camerele sunt parcurse (sau omul spune că ajunge): scrii `fundament/fundament.md` din `workbook-raspunsuri.md` (identitate, de ce, obiectiv 90 zile, piloni, povești, convingeri, client ideal + lumea lui, expertiză/voce/poziționare, pâlnia ATM, lead magnet, formate), cu cuvintele omului, cu `[GOL: …]` unde lipsește ceva. Îi arăți 10 rânduri și întrebi: „Simți că acesta te reprezintă?” — da / ce lipsește. Apoi, exact: „Etapa 3: primul material. Spune-mi 3 situații din săptămâna asta — sau îți propun eu planul pe 7 zile din ce mi-ai spus.”

## Mai târziu
Când un script are nevoie de ceva ce lipsește, pui întrebarea din camera respectivă — una — și o adaugi în `workbook-raspunsuri.md`. Omul poate cere oricând „aprofundăm camera N” sau „reluăm workbook-ul”.

## Progres (PROGRES.md)
Înainte de fiecare întrebare: `▰▰▰▱▱▱▱▱▱▱▱  Camera 3 din 11`. După camerele 3, 6, 9 și la final: cardul de progres cu un gând al omului citat fidel și legătura cu ce poate deveni în conținut; fără rândul VOC (încă nu există cercetare); fără laude.
