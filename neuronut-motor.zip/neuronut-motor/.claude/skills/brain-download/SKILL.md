---
name: brain-download
description: Etapa 2 — „Sunt instalat. Hai să ne cunoaștem.” Cele 11 camere din workbook (fundament/cele-11-camere.md), varianta rapidă: o întrebare-cheie pe cameră, cu voce, 20 de minute, apoi Fundamentul. Aprofundarea camerelor vine la cerere sau când lipsește ceva pentru un script. Folosește când fundament.md e gol sau omul scrie „cunoaște-mă”.
---
# Etapa 2 · Hai să ne cunoaștem (20 de minute, nu 2 ore)

## Deschiderea (exact)
„Etapa 1 e gata: sunt instalat. Etapa 2: hai să ne cunoaștem. Îți pun 11 întrebări, una pe cameră — răspunzi cu voce, cum vorbești de obicei. 20 de minute. Dacă ai documentul cu cele 11 camere din ChatGPT sau workbook-ul completat, pune-l în fundament/ și sar peste ce știu deja.”

## Regulile
- Recomandarea de confort, în deschidere: „Răspunzi cu voce, cum vorbești unui prieten. Nu trebuie să fie perfect — eu structurez. Dacă nu știi la ceva, spui «sar» și revenim altădată.” La camera 6: „Jumătate. Mai sunt 5, vreo 8 minute.”
- O singură întrebare pe mesaj: întrebarea CHEIE a camerei din `fundament/cele-11-camere.md`. Nu lista, nu „și mai spune-mi”. Răspunsul omului e suficient; nu ceri completări decât dacă răspunsul e sub o propoziție.
- Dacă există document în fundament/ (workbook, Blueprint, 11 camere din ChatGPT): îl citești întâi, bifezi camerele acoperite și pui doar întrebările camerelor goale.
- Progresul la fiecare pas: „Camera 4 din 11 ·” înainte de întrebare. Omul știe mereu unde e și cât mai e.
- Camera 12 nu e întrebare: e planul pe 7 zile pe care îl construiești TU după.
- Nu Human Design, nu arhetipuri, nu astrologie: dacă omul le aduce, le notezi în fundament ca „ce vrea să transmită” (o linie) și mergi mai departe.

## Închiderea
Scrii `fundament/fundament.md` (identitate, de ce, obiectiv 90 zile, piloni, povești, convingeri, client ideal + lumea lui, expertiză/voce/poziționare, pâlnia ATM, lead magnet, formate) și `fundament/reguli-voce.md` din felul în care a vorbit. Îi arăți 10 rânduri și întrebi: „Simți că acesta te reprezintă?” — da / ce lipsește. Apoi, exact: „Etapa 3: primul material. Spune-mi 3 situații din săptămâna asta — sau îți propun eu planul pe 7 zile din ce mi-ai spus.”

## Aprofundarea (mai târziu)
Când un script are nevoie de ceva ce lipsește (o poveste, o obiecție a clientului, o convingere), pui întrebarea din camera respectivă — una — și o notezi. Omul poate cere oricând „aprofundăm camera N”: atunci iei toate întrebările camerei, câte una.

## Progres (PROGRES.md)
Înainte de fiecare întrebare: `▰▰▰▱▱▱▱▱▱▱▱  3 din 11`. După camerele 3, 6, 9 și la final: cardul de progres cu un gând al omului citat fidel și legătura cu ce poate deveni în conținut; fără rândul VOC (încă nu există cercetare); fără laude.
