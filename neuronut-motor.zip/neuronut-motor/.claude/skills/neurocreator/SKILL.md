---
name: neurocreator
description: Modul „Provocarea NeuroCreator” (40 de zile, 15 nov – 24 dec 2026). Se pornește când omul scrie „Ziua N din provocarea NeuroCreator” (cu „Nevo,” sau „Neuronuț,” în față — amândouă merg), lipește promptul zilei din Stan, sau scrie „ziua”, „ziua 7”, „unde sunt în provocare”. Pentru ziua respectivă: cercetare în nișa omului după cei 3 indicatori + testul prietenului, apoi 5 idei de reel legate de misiunea zilei, cu formatul luat din reel-uri care au mers acum, una recomandată, apoi scriptul.
---
# Provocarea NeuroCreator

Zilele sunt în `provocare/provocare-40-zile.json`. Progresul omului e în `fundament/provocare.json` (ținta, ziua curentă, postările publicate, conversațiile pornite, formatul câștigător). Nu inventezi nimic din provocare: ce nu e în fișiere, întrebi.

## 0. Prima dată (o singură dată)
Întrebi ținta, cu cifre: 1 Pornesc de la zero · 2 Am deja o afacere · 3 Am deja o comunitate. Salvezi în `fundament/provocare.json`. „schimbă ținta” o schimbă. Ziua 1 = 15 nov 2026; „ziua” = ziua de azi după calendar; „ziua 7” = ziua cerută.

## 1. Context înainte de întrebări (regula Elenei)
Citești cele 11 camere (`fundament/`), `fundament/voc.md` dacă există, `fundament/indicatori.md` dacă există, postările publicate din `fundament/provocare.json`. Spui în 2–3 rânduri ce știi relevant pentru ziua de azi și ce îți lipsește. Pui doar întrebările necesare, una pe rând. Nu ceri a doua oară ce ai deja.

## 2. Cercetarea zilei (obligatorie, skill `research`)
Cauți în nișa omului reel-uri de pe tema misiunii zilei, ultimele 30–60 de zile, întâi în limba lui, apoi în nișa-mamă în engleză (și rusă dacă nișa e bilingvă) — în română multe nișe sunt goale, iar formatele validate vin din engleză. Ordinea: cei 3 indicatori (`research` → „Cei 3 indicatori”): multiplul față de media contului (10× și peste = semn de trimiteri), aprecieri ÷ vizualizări, și testul prietenului la fiecare piesă. Reții 3–5 piese care trec; notezi la fiecare STRUCTURA (hook în prima secundă, ce se vede pe ecran, durata, cum se închide), nu textul. Salvezi în `referinte/ziua-N.md`.

## 3. Cele 5 idei (livrabilul care deschide ziua)
Pe baza misiunii zilei + rolul ATM + cercetare + ce știi despre om, dai 5 idei de reel, fiecare cu exact această formă:

**N · [misiunea zilei] ([rol ATM])**
Hook (ce se aude și ce se vede în prima secundă): …
Format: [structura unui reel din cercetare, numit: cont + ce a făcut]. [GOL: …] acolo unde îți lipsește un fapt al omului.
Testul prietenului: cine îl trimite cui, cu ce gând — concret, un om anume.
Invitația: [invitația zilei din fișier, neschimbată].

Reguli pentru idei:
- Pornesc din cuvintele omului (11 camere, VOC, ce a spus azi). Niciun fapt, cifră sau scenă inventată; lipsa = [GOL] + întrebare.
- Hook-uri cu dovadă pe ecran înaintea explicației (cifre contrastante, ecranul cu procesul, comentariul real) — asta a mers în toate nișele cercetate.
- Rol Atenție / Încredere: nicio cerere de vânzare. Rol Monetizare: o singură cerere, cea a zilei.
- Ținta: „de la zero” — vorbești ca pentru omul care a pus întrebarea; „deja vând” — vorbele clienților doar cu acord și fără nume; „comunitate” — fără cuvânt-cheie în comentarii, ceri omului să-și descrie situația.
- Recomanzi UNA, într-o propoziție, cu motivul din cercetare și din `indicatori.md` (dacă există). Omul corectează, nu alege dintr-o listă goală.

## 4. Apoi, în ordinea obișnuită
Scriptul (`scenariu-reel`, cu testul prietenului sub el) → filmare → montaj → copertă → caption care se termină cu invitația zilei → publicare. După publicare: „ce mi-au spus oamenii” → notezi cuvintele exacte în `fundament/voc.md` (sursa, problema, ce a încercat) și bifezi ziua în `fundament/provocare.json`.

## 5. „unde sunt”
Ziua și etapa, câte postări publicate din câte, conversațiile pornite (din ce a raportat omul), formatul câștigător dacă e după ziua 15, și misiunea de azi. Indicatorul: `▰▰▰▱▱ ziua 3 din 40`.

## Zi fără timp
Cel mult o dată pe etapă, niciodată în zile de Monetizare: o postare de rezervă — un rând de text pe un cadru filmat deja, cu invitația zilei.
