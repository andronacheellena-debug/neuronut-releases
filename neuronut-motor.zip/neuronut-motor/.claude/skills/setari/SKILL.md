---
name: setari
description: Setările de început — 4 întrebări cu numere, una pe rând, după instalare și înainte de Brain Download. Răspunsul e o cifră. Se salvează în fundament/setari.json și nu se mai întreabă. Folosește și când omul scrie „setări” sau vrea să schimbe ceva (unde primește video-ul, stilul, identitatea, intensitatea).
---
# Setările de început (răspunzi cu o cifră) — începutul Etapei 2, 2 minute
Spui întâi: „Etapa 2 din 4: hai să ne cunoaștem. Întâi 5 întrebări scurte, răspunzi cu o cifră; apoi 11 întrebări cu voce, 20 de minute.”

**0 · În ce limbă îți faci conținutul?**
„1 — Română. 2 — Rusă. 3 — Engleză. 4 — Altă limbă (scrie-o).”
→ `limba_continut`: `ro` | `ru` | `en` | cod. Chatul rămâne în limba în care îmi scrii. La 2 (rusă/ucraineană) îi spui o dată că titlurile folosesc Inter / Playfair (fonturile cu chirilice).


Le pui UNA PE RÂND, exact cu textul de mai jos, și aștepți cifra. Fără explicații lungi, fără opțiuni în plus. Dacă omul scrie altceva decât o cifră, îi spui blând: „Scrie doar 1 sau 2.”

**1 · Unde vrei video-ul final?**
„1 — Aici, gata de postat. Îl vezi, îmi spui ce schimb, îl descarci.
2 — Și în CapCut, editabil. Îl deschizi acolo dacă vrei să retușezi singur.”
→ `video_final`: `aici` | `capcut`. La 2, verifici că CapCut e instalat; dacă nu e, notezi `aici` și îi spui că poate schimba oricând cu „setări”.

**2 · În ce stil montăm?**
„1 — Lejer: natural, luminos, ca un prieten.
2 — Tech: curat, precis, ca un expert.
3 — Dinamic: rapid, un cuvânt pe ecran, ca o reclamă.
4 — Ca reel-urile mele preferate: îmi dai 1–3 înregistrări de ecran și învăț de la ele.”
→ `stil`: `lejer` | `tech` | `dinamic` | `referinte` (la 4 pornește `stil-din-referinta` când vine primul video).

**3 · Cum vrei să arate coperțile și caruselele?**
„1 — Raw Human: cald, natural, cu pozele tale.
2 — Experimental: îndrăzneț, culori tari, litere mari.
3 — Editorial: modern, ordonat, ca o revistă.
4 — Cu brandul meu: îmi dai culorile, fonturile și pozele tale.”
→ `identitate`: `raw-human` | `experimental-creative` | `digital-editorial` | `a-mea` (la 4 pornește `identitate`, partea de ADN vizual).

**4 · Cât de prezent să fie designul?**
„1 — Discret.
2 — Echilibrat.
3 — Puternic.”
→ `intensitate`: `soft` | `balanced` | `bold`.

## După cele 4 cifre
Scrii `fundament/setari.json` (cu `limba_continut`) și `fundament/identitate-mea.json` (style_id + intensity) și spui o singură propoziție: „Gata: video-ul îl primești [aici/și în CapCut], montaj [stil], coperți [identitate], design [intensitate]. Schimbi oricând cu «setări».” Apoi treci la Brain Download.

## Cum le folosești după
- `video_final = aici` → la montaj livrezi reel-final.mp4 + copertă + 4 cadre; NU creezi proiect CapCut, nu pomenești de CapCut, nu-l cauți pe disc, nu propui „vrei și în CapCut?”. Tranzițiile și efectele sonore le pui în mp4 (render.py), nu amâni nimic „pentru CapCut”. Zero efort în plus.
- Schimbarea unei setări: omul scrie „setări” (sau „vreau în CapCut”, „schimbă stilul”) → arăți doar întrebarea respectivă cu cifrele ei, schimbi doar acel câmp, confirmi într-un rând. Nu reiei toate întrebările.
- `video_final = capcut` → în plus, proiectul CapCut editabil (skill `montaj-reel`).
- `stil`, `identitate`, `intensitate` → scripturile le citesc automat.
Fără `setari.json`, implicit: aici · lejer · raw-human · balanced.
