---
name: identitate
description: Identitatea vizuală a omului (ADN-ul vizual). Folosește o singură dată, înainte de prima copertă/carusel/story sau când omul scrie „identitate”, „brand”, „culori”, „fonturi”. Alege una din cele 3 identități (Raw Human implicit, Experimental Creative, Digital Editorial) sau construiește una personalizată din pozele și materialele omului, cu 3 intensități. Scrie fundament/identitate-mea.json.
---
# Identitatea vizuală

## Întrebarea (o singură dată)
„Ce identitate vizuală vrei?
1 · Raw Human — autentic, natural, cu pozele tale reale (implicit)
2 · Experimental Creative — expresiv, tipografie mare, culori contrastante
3 · Digital Editorial — modern, structurat, educațional
4 · A ta — din brandbook-ul, culorile, fonturile și materialele tale
Și cât de prezent să fie designul: discret (soft), echilibrat (balanced) sau puternic (bold)?”
Dacă omul nu răspunde la intensitate: balanced. Dacă nu răspunde deloc: Raw Human · balanced (nu-l ții pe loc).

## Pentru 1–3
Scrii `fundament/identitate-mea.json` cu style_id + intensity. Generezi IMEDIAT un exemplu (o copertă + 3 slide-uri, cu `scripts/cover.py`, `scripts/carousel.py`, pe o poză a lui din inbox sau pe un cadru din video) și i-l arăți: „Așa arată. Îl ții sau schimbăm ceva?” Ce schimbă intră în `user_overrides`.

## Pentru 4 (a ta) — ADN-ul vizual
Ceri, pe rând, doar ce are: (a) brandbook / culorile (hex) / fonturile (.ttf/.otf → `fundament/fonturi/`), (b) 10–15 imagini cu conținutul lui de până acum sau cu ce îi place (→ `inbox/referinte-vizuale/`), (c) pozele lui (→ `inbox/poze/`), (d) reel-urile montate ca video (→ `inbox/referinte/`, skill `stil-din-referinta`).
Din imagini: faci o planșă (`python3 scripts/analyze_images.py inbox/referinte-vizuale/`), TE UIȚI la ea și scrii: culorile dominante (hex), fonturi (serif/sans/mono/handwritten, bold/light), densitatea textului, fundaluri (poze/solid), accentele. Alegi cea mai apropiată dintre cele 3 identități ca bază și pui diferențele în `user_overrides`. Dacă are fonturi proprii, le pui în `font_family` cu `*_ass` = numele familiei din fișier.
Preferințele explicite ale omului câștigă întotdeauna față de preset.

## Aplicarea
După salvare, toate scripturile folosesc identitatea automat (fără parametri). Nu mai întrebi. Dacă omul spune „mai discret” / „mai puternic”, schimbi intensity. Dacă spune „pune mai multă culoare X”, schimbi overrides. Notezi în `fundament/preferinte-vizual.md` ce și de ce.

## Reguli
- `stiluri/calitate.md` rămâne deasupra oricărei identități: text mare, lizibil, nu pe față, zone sigure.
- Nu uniformizezi: pozele, experiențele și materialele omului au prioritate față de orice element grafic al presetului. Human first, digital second.
- Nu folosești fonturi care nu sunt în `fonts/` sau `fundament/fonturi/` (licențe: toate cele din pachet sunt OFL).
