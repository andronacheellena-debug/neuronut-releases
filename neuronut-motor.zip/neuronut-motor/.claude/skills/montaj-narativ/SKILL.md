---
name: montaj-narativ
description: OPȚIUNE (nu standard). Montaj după structura psihologică a reel-urilor care performează — hook, rehook, problemă, valoare, dovadă, CTA — construit din ce există deja în clip: Nevo citește transcrierea, găsește fraza cea mai puternică pentru fiecare rol și rearanjează. Folosește când omul cere „montaj narativ”, „pune hook-ul cel mai bun în față” sau când clipul e vorbit liber, fără script.
---
# Montajul narativ

## Când
- Omul a filmat liber (fără script) sau a vorbit mult și hook-ul bun e la mijloc.
- Omul cere explicit. Nu-l aplici din proprie inițiativă pe un clip filmat după script — acolo ordinea e deja gândită.
- Îl propui o singură dată, ca alternativă: „Pot să-ți fac și o variantă narativă: hook-ul cel mai puternic în față, apoi de ce să rămână, apoi miezul. Vrei s-o vezi lângă varianta normală?”

## Structura (rolurile, în ordinea finală)
1. **Hook (0–3 s)** — o singură propoziție care oprește degetul: o afirmație tare, o întrebare, un rezultat, o contradicție. Cea mai puternică din tot clipul, oriunde ar fi fost spusă.
2. **Rehook (3–8 s)** — de ce să rămână: ce urmează, ce pierde dacă pleacă, „și nu e ce crezi”.
3. **Problema / contextul** — situația reală, cu cuvintele omului.
4. **Valoarea** — ideea centrală, explicația, pasul concret.
5. **Dovada** — rezultat, cifră, exemplu (doar dacă există în clip; nu inventezi).
6. **CTA** — pasul următor, aliniat cu decizia Attract/Convert.
Rolurile 3–5 pot avea 1–3 segmente fiecare; 1, 2 și 6 câte unul. Țintă 30–45 s.

## Cum lucrezi
1. Ai transcrierea cu timpi (`.words.json`). O citești ca pe un text și marchezi candidații pentru fiecare rol, cu secundele. Pentru hook alegi între 3 candidați și notezi de ce ai ales (în `taieturi.md`).
2. `python3 scripts/narrative_plan.py inbox/<video>.words.json --order "hook=…,rehook=…,problema=…,valoare=…,dovada=…,cta=…" --out inbox/<video>.narativ.cuts.json`
   Intervalele se aliniază singure la marginile cuvintelor. Dacă o frază bună e „murdară” (respirații, umpluturi în interior), dai două intervale mai mici în loc de unul.
3. Randezi ca de obicei, în alt folder: `render.py … <video>.narativ.cuts.json --out output/<dir>-narativ/`. Hook-ul pe ecran = primele cuvinte ale segmentului hook.
4. Verificarea obligatorie în plus față de `calitate.md`: **continuitatea** — asculți tăieturile dintre segmente reordonate (ton, volum, poziția capului); unde sare urât, pui o tăietură pe un cuvânt de legătură sau alegi alt segment. Nu livrezi o reordonare care se aude ca un colaj.
5. Îi arăți omului AMBELE variante (normală + narativă) cu o propoziție despre diferență și îl lași să aleagă. Ce alege devine preferință în `preferinte-montaj.md` („preferă montajul narativ când filmează liber”).

## Ce nu faci
- Nu schimbi sensul: fraza din hook nu promite ceva ce clipul nu livrează.
- Nu tai o propoziție la mijloc ca să „sune” a hook.
- Nu-l faci standard. E o unealtă pentru clipurile vorbite liber.
