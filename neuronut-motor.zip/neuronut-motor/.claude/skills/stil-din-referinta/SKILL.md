---
name: stil-din-referinta
description: Stilul omului din reel-urile care îi plac. Folosește înainte de PRIMUL montaj (obligatoriu) și ori de câte ori omul pune un screen record în inbox/referinte/ sau spune „vreau ca reel-ul ăsta”. Analizează referința cadru cu cadru și scrie stiluri/al-meu.md; montajul pornește de acolo.
---
# Stilul din referință

## De ce există etapa asta
Omul nu știe să descrie un stil de montaj; știe să arate un reel care îi place. Un link nu-l pot vedea. Un screen record, da. Deci la primul montaj, înainte de orice, îi ceri 1–3 referințe:

„Înainte să montez primul reel vreau să montez ca pentru tine, nu ca pentru oricine. Fă un lucru simplu: deschide pe telefon 1–3 reel-uri care îți plac ca montaj (nu ca subiect), pornește înregistrarea ecranului și lasă fiecare să ruleze până la capăt. Pune fișierele în `inbox/referinte/`. Eu mă uit la ele cadru cu cadru și scriu stilul tău. Dacă nu ai niciunul, alegi unul din cele 3 ale noastre: Lejer, Tech, Dinamic.”

## Ce faci cu fiecare referință
1. `python3 scripts/analyze_ref.py inbox/referinte/<fisier>.mp4` → contact-sheet.png, taieturi.json, rezumat.md în `referinte/stil-<fisier>/`.
2. Te uiți la contact-sheet.png (obligatoriu — nu scrii stil fără să-l fi văzut). Completezi rezumat.md: poziția textului, font, culori, B-roll, zoom, lumină, ritm (din taieturi.json).
3. Cu 2–3 referințe: ce revine în toate e regula; ce apare o dată e opțional.
4. Scrii `stiluri/al-meu.md` cu aceleași rubrici ca lejer/tech/dinamic (Cadru și lumină, Text pe ecran, Inserturi, Ritm, Sunet, Preset render) + „Referințe: …”. Preset-ul render e cel mai apropiat dintre cele 3 (sau neurolab) cu ajustări (poziție, număr de cuvinte).
5. Îi arăți omului stilul în 5–6 rânduri, în cuvinte simple („text sub bărbie, 2 cuvinte, tăietură la ~2 secunde, lumină de zi, fără zoom”) și întrebi: „Așa vrei?” La „da” notezi în preferinte-montaj.md „Stil: al meu (din referințe), <data>” și treci la montaj.

## Reguli
- `stiluri/calitate.md` rămâne deasupra: dacă referința are text pe față sau tranziții de 2015, nu le copiezi — îi spui omului că le-ai lăsat deoparte și de ce.
- Nu copiezi conținutul referinței, doar forma.
- Referința e a omului, nu a ta: dacă în ea e un stil pe care nu-l poți reproduce automat (animații complexe), spui ce reproduci și ce rămâne de făcut în CapCut, cu secunda exactă.
