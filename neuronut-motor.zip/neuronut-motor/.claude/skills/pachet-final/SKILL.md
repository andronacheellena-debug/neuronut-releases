---
name: pachet-final
description: Pachetul final, automat, după ce omul aprobă reel-ul montat („aprobat”, „e bun”, „ok, final”). Din acel reel ies, fără să mai întrebi: 2 variante de copertă cu titluri care fac click, scripturile pentru o serie de maxim 3 reel-uri derivate (de postat în jurul reel-ului), un carusel din reel, plus caption-urile. Totul în identitatea și vocea omului.
---
# Pachetul final (declanșat de „aprobat”)

Când omul aprobă reel-ul (orice formulare clară de aprobare), NU întrebi „vrei și…?”. Spui o propoziție — „Aprobat. Îți pregătesc pachetul: 2 coperți, seria de 3 reel-uri și caruselul. 5–10 minute.” — și livrezi tot în `output/<dir>/pachet/`.

## 1. Două coperți cu titlu care face click (A/B)
Din transcriere alegi 2 unghiuri diferite pentru titlu — nu 2 formulări ale aceluiași:
- **A · curiozitate**: întrebare sau contradicție („De ce nu-ți răspund la DM?” / „Am greșit 5 ani”)
- **B · rezultat/beneficiu**: ce câștigă („3 situații = 1 reel pe săptămână”)
Regula: titlul promite exact ce livrează reel-ul (nu clickbait fals — `calitate.md` și vocea omului). Maxim 6 cuvinte pe copertă, cuvântul-cheie accentuat. Două cadre diferite din reel (`--time` diferit, cu expresie, fără ochi închiși).
`python3 scripts/cover.py reel-curat.mp4 --time <tA> --title "<A>" --accent "<cuvânt>" --out pachet/coperta-A.jpg` și la fel pentru B. Verifici amândouă (textul nu pe față).
Îi spui omului într-un rând care e recomandarea ta și de ce (din research: ce tip de hook a performat în nișă).

## 2. Seria de maxim 3 reel-uri (scripturi, în chat)
Reel-uri DERIVATE din același reel, de postat în zilele următoare, ca să țină subiectul viu. Fiecare are alt rol, nu e o repetare:
1. **Teaser / înainte** (15–20 s) — o singură idee din reel, tăiată ca întrebare deschisă; CTA: „răspunsul mâine”.
2. **Unghiul 2 / după** (30–40 s) — a doua frază puternică din transcriere devine hook (skill `montaj-narativ`, din materialul existent, sau refilmat 1 minut).
3. **Răspuns la comentarii** (20–30 s) — hook din cel mai probabil comentariu/obiecție (din research-ul de comentarii al semnalului); omul filmează 1 minut.
Dacă materialul nu susține 3, faci 2 și spui de ce. Fiecare script în formatul standard din `scenariu-reel` (hook · text pe ecran · regie), în vocea omului, din ce a spus el — nu inventezi fapte. Marchezi ce se poate monta din clipul existent și ce cere filmare.

## 3. Caruselul din reel
Skill `carusel`, cu ideea reel-ului: slide 1 = hook-ul (titlul A sau B, cel mai bun pentru citit), 2–5 = pașii/ideile din transcriere, ultimul = CTA aliniat cu decizia Attract/Convert. Pozele omului din `inbox/poze/` sau cadre din reel. PNG-uri individuale.

## 4. Caption-urile
Skill `caption`: caption pentru reel (cu primul comentariu și 3 stories), caption pentru carusel, și câte un caption scurt pentru fiecare reel din serie.

## Livrarea
Un singur mesaj, ordonat: coperta A / B (cu recomandarea), scripturile seriei (complete, în chat), caruselul (fișierele), caption-urile. Apoi: „Spune-mi ce schimb. Dacă vrei, programez în Metricool.” Nimic nu se publică fără „da”.
Ce aprobă omul din pachet intră în `preferinte-vizual.md` / `reguli-voce.md` (ex. „preferă coperțile cu întrebare”).
