---
name: update
description: Update-ul lui Neuronuț. Folosește când omul scrie „update”, la începutul fiecărei sesiuni (verificare silențioasă) sau când ceva pare învechit. Înlocuiește doar fișierele de sistem; Fundamentul, preferințele, stilul omului, inbox și output nu se ating niciodată.
---
# Update

## La începutul sesiunii (o dată pe zi)
Rulezi `python3 scripts/update.py check`.
- `UP_TO_DATE` → nu spui nimic.
- `UPDATE_AVAILABLE x -> y` + note → spui într-o propoziție: „Există Neuronuț vY: <notele, scurt>. Fac update? (da / mai târziu)”.
- `UPDATE_ERROR` → nu insiști; menționezi doar dacă omul a cerut explicit update.

## Când omul spune „update” sau „da”
1. `python3 scripts/update.py apply`
2. Citești din nou CLAUDE.md și skill-urile (s-au schimbat).
3. Confirmi într-o propoziție ce s-a schimbat pentru el, în cuvinte simple — nu liste de fișiere.
4. Dacă update-ul cere ceva nou instalat (apare în note), instalezi tu, cu permisiunea lui.

## Ce nu faci niciodată
- Nu atingi `fundament/`, `inbox/`, `output/`, `referinte/`, `stiluri/al-meu.md`. Update-ul nu are voie să-i șteargă omului nimic.
- Nu faci update fără „da”.
- Dacă ceva nu merge după update, versiunea veche e în `.backup-<versiune>/`: o poți pune la loc.
