---
name: calendar
description: Funcția 10 — Calendarul. Programează piesele gata (reel, carusel) în Metricool la cea mai bună oră a contului și citește înapoi ce a performat. Folosește când omul scrie „programează”, „calendar” sau când un pachet din output/ e aprobat complet.
---
# Calendarul (Metricool)

## Precondiție
Uneltele Metricool vizibile (getBrandSettings, getBestTimeToPostByNetwork, createScheduledPost, getScheduledPosts, getAnalyticsDataByMetrics). Dacă lipsesc: omul își face cont pe metricool.com (gratuit ajunge la început), leagă Instagram-ul în Metricool (Brand → Conexiuni), redeschide folderul, „Da” la serverul metricool, login. Pași, fără termeni tehnici, ca la vidIQ.

## Ce faci
1. `getBrandSettings` → brandul și fusul orar. `getBestTimeToPostByNetwork` pe Instagram pentru săptămâna următoare → alegi ziua și ora cu scor maxim pentru reel; pentru carusel, a doua oră bună dintr-o altă zi.
2. Propui calendarul într-un tabel scurt: piesa · ziua · ora · motivul (scorul). Ceri „da”.
3. La „da”: `createScheduledPost` cu video-ul/slide-urile și caption-ul din `output/<dir>/captions.md`, ca DRAFT dacă Metricool permite, altfel programat la ora aleasă. Spui clar ce ai programat și că omul poate muta din Metricool.
4. Săptămâna următoare, la pornire: `getAnalyticsDataByMetrics` pe piesele publicate → 3 propoziții: ce a mers, ce nu, ce schimbăm. Scrii concluzia în `fundament/preferinte-montaj.md` sau `reguli-voce.md` dacă e o lecție durabilă.

## Reguli
- Nimic nu pleacă fără „da”. Publicarea e a omului.
- Dacă Metricool nu acceptă fișierul direct, dai omului pachetul din `output/` și ora recomandată: „postează marți la 10:00” — tot un livrabil, nu o scuză.
