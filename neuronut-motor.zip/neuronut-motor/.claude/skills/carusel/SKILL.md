---
name: carusel
description: Funcția 7 — Caruselul vizual. Din același semnal scrie textele slide-urilor și le randează 4:5 (1080×1350) cu scripts/carousel.py, pe pozele omului dacă există. Folosește după scenariu sau când omul cere un carusel.
---
# Caruselul

## Structura (5–7 slide-uri)
1. HOOK — titlu mare, max 8 cuvinte, un cuvânt accentuat. Pe poza omului dacă are una bună în inbox/.
2–5. O idee pe slide: titlu scurt (max 6 cuvinte) + 1–3 rânduri de corp (max 25 de cuvinte). Fiecare slide trebuie să aibă sens și singur.
6. (opțional) DOVADA — doar dacă există în Fundament.
7. CTA — un singur pas, potrivit deciziei ATTRACT/CONVERT. Rozul e doar pentru CTA.

## Identitatea (o singură dată)
Dacă `fundament/identitate-mea.json` nu există, rulezi întâi skill-ul `identitate`. Apoi scripturile aplică identitatea automat.

## Cum lucrezi
1. Scrii textele în `output/<dir>/carusel.json` (format în scripts/carousel.py), din reguli-voce.md.
2. Identitatea vine din `fundament/identitate-mea.json` (presetul + intensitatea + suprascrierile omului). Nu mai pui `brand` în JSON.
3. `python3 scripts/carousel.py output/<dir>/carusel.json --out output/<dir>/carusel/` (opțional `--identity … --intensity …` ca să arăți omului o alternativă)
   Stories: `python3 scripts/story.py --text "…" --sub "…" --photo inbox/poze/x.jpg --out output/<dir>/story-1.jpg`
4. Te uiți la slide-uri (deschide PNG-urile). Textul mare și lizibil pe telefon e obligatoriu: dacă un titlu trece de 3 rânduri, îl scurtezi, nu micșorezi fontul.

## Reguli
- Nu e un rezumat al reel-ului; e aceeași idee, spusă pentru cine citește, nu pentru cine ascultă.
- Fără fraze de umplutură („în acest carusel”). Primul slide trebuie să oprească degetul.
- După aprobare: ce a schimbat omul (font, culoare, poziție, lungime) intră în `fundament/preferinte-vizual.md`, datat.
