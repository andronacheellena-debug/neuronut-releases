---
name: montaj-reel
description: Funcția 6 — Montajul reel-ului. Din video-ul brut (inbox/) produce reel-curat.mp4 (pentru CapCut), subtitrari.srt, reel-final.mp4 cu subtitrări arse și hook, coperta și lista tăieturilor. Folosește când apare un video în inbox/ sau omul cere „montează”.
---
# Montajul

## Pasul -3 · Ghidarea omului
Început: „Montez. Îți dau varianta de verificare în ~[N] minute — un video mai mic, doar ca să te uiți și să-mi spui ce schimb. Între timp, dacă vrei, scrie-mi cum vrei coperta.” Mijloc (dacă durează peste 3 minute): un rând de stare. Sfârșit: „Gata, am montat. Uită-te la varianta de verificare și spune-mi ce schimb…” + ce urmează („spui ce schimb → aprobat → pachetul, 5–10 minute”).

## Pasul -2 · Viteza (regulile care au ieșit din 3 noiembrie — nu se negociază)
- **Rundele de feedback se fac pe PREVIEW** (`render.py … --preview`, 540×960, secunde). Clipul mare (1080×1920) se randează O SINGURĂ DATĂ, la final, după ce omul spune „aprobat”. Niciodată nu re-randezi clipul mare după o corectură.
- Fiecare segment se randează separat și se ține în cache (`output/<dir>/.cache`): după o corectură se re-randează doar segmentele schimbate, restul se lipesc fără re-encodare. Encoderul hardware se alege singur (Mac: videotoolbox; Windows: nvenc/qsv/amf).
- Spui omului timpul estimat înainte de orice randare și îl respecți. Un preview de 2 minute de clip = sub 1 minut; finalul = 2–4 minute pe laptop.

## Pasul -1.5 · Secunda pe care ți-o dă omul e exactă — nu ghicești
Când omul dă o secundă și ce se aude acolo: `python3 scripts/snippet.py inbox/<video> --at <secunda> --words inbox/<video>.words.json` → îi arăți cuvintele cu timpii lor din jur și bucata de 6 secunde. Tai pe marginea cuvântului pe care îl numește el. Dacă sunt două sunete apropiate și nu e clar care, ÎNTREBI O DATĂ („plescăitul e înainte de «Pe» sau după?”) — nu refaci clipul de trei ori.
Niciodată nu scoți o frază rostită de om și nu o înlocuiești cu text. Dacă o luare e greșită („Reu” în loc de „Leu”): `python3 scripts/find_take.py "regele leu"` caută fraza în TOATE clipurile transcrise din inbox și îți dă luările; pui segmentul bun în cuts.json cu `"src": "<clipul bun>"` (render.py lipește din mai multe clipuri). Dacă nu există nicio luare bună, îi spui omului și îl rogi să refilmeze fraza (10 secunde), nu decizi tu.

## Pasul -1 · Calitatea (citești de fiecare dată)
`stiluri/calitate.md` e deasupra oricărui stil: fără text pe față, fără deformare, tranziție la fiecare idee nouă, fără sunete sintetizate, verificare pe 4 cadre înainte de livrare. Nu livrezi ce n-ai văzut.

## Pasul 0 · Stilul (o singură dată) — METODOLOGIA ELENEI
Dacă `fundament/setari.json` are deja `stil` (din setările de început), îl folosești fără să întrebi; la `referinte` ceri screen record-urile.
Primul reel trebuie să iasă (a) editabil în CapCut și (b) în dinamica referinței date de om. Deci dacă `fundament/preferinte-montaj.md` nu are o linie „Stil: …”, înainte de orice rulezi skill-ul `stil-din-referinta`: îi ceri 1–3 screen record-uri cu reel-uri care îi plac, le analizezi cadru cu cadru, scrii `stiluri/al-meu.md`, îi arăți stilul în cuvinte simple și aștepți „da”. Dacă n-are referințe, alege unul din cele 3 (Lejer / Tech / Dinamic) sau „Din CapCut-ul meu”. Nu montezi niciodată „generic” și apoi aștepți corecturi: primul montaj e deja în stilul lui. Citești fișierul stilului ales și îl aplici la toți pașii de mai jos: pragul de pauză, preset-ul de randare, inserțiile, sunetul. Notezi alegerea în preferinte-montaj.md. Pentru „Al meu” și „Din CapCut-ul meu” scrii `stiluri/al-meu.md` cu aceleași rubrici ca celelalte.

## Pașii (rulezi tu, în ordine)
1. Transcriere: `python3 scripts/transcribe.py inbox/<video> ro --model <din preferinte-montaj.md: small în mod eveniment, medium pe procesor, large-v3 cu NVIDIA>` (prima rulare descarcă modelul o singură dată). Spui omului cât durează înainte să pornești.
   Deschizi `.words.json` și citești transcrierea. Dacă vezi cuvinte greșite (nume proprii, moldovenisme), le corectezi în JSON înainte de pasul 2 și le notezi în `fundament/preferinte-montaj.md` → secțiunea „Dicționar”.
2. Plan de tăieri — DINAMIC, implicit: `python3 scripts/cut_plan.py inbox/<video>.words.json`
   Pragurile implicite sunt strânse (pauze > 0,28 s ies; respirații, gândire, umpluturi, cuvinte duble, luări repetate — toate ies). Deschizi `.cuts.json` și verifici față de script: o singură luare pe propoziție (cea mai bună), divagațiile afară. Toate pauzele ies, fără excepție — nu mai există pauze marcate care rămân. Scriptul raportează și „variantă reluată mai târziu” (fraza spusă greșit, apoi corect): verifici că a rămas varianta bună, și cauți tu, după sens, ce n-a prins (aceeași idee spusă cu alte cuvinte). Ce a adăugat omul cu vorbele lui, în afara scriptului, rămâne. Regulile complete: `stiluri/calitate.md` → „Montajul după sens”.
   Verifici și sunetul: extragi forma de undă (`ffmpeg -i reel-curat.mp4 -filter_complex showwavespic=s=1080x200 wave.png`) și te uiți dacă au rămas goluri între tăieturi; dacă da, scazi `--max-pause` și refaci.
   Dacă `preferinte-montaj.md` spune altceva (ex. „pauze > 0,9 s”, „păstrează râsul”), aplici ce spune.
3. Preview pentru feedback: `python3 scripts/render.py … --preview` → `reel-preview.mp4` (540×960, în secunde). Omul dă feedback pe el. La „aprobat” randezi fără `--preview` → `reel-final.mp4` (1080×1920, calitate înaltă). NICIODATĂ nu livrezi `reel-preview.mp4` ca final; scriptul refuză finalul dacă nu e 1080 lățime. Calitatea nu depinde de model sau de abonament — e fixată în cod.
   Fața, cadru cu cadru: `python3 scripts/face_zones.py output/<dir>/reel-curat.mp4` → `faces.json` (unde e capul și bărbia în fiecare moment). Randarea și proiectul CapCut folosesc acest fișier ca textul să NU cadă pe față nici când omul se mișcă: subtitrarea coboară sub bărbie când capul coboară, urcă deasupra capului când jos nu e loc, hook-ul se mută dacă creștetul e sus. Dacă detecția e sub 60 % din cadre, spui și verifici manual pe 8 cadre, nu 4.
   Randare: `python3 scripts/render.py inbox/<video> inbox/<video>.cuts.json --words inbox/<video>.words.json --out output/<data>-<slug>/ --hook "<hook pe ecran>" --faces output/<dir>/faces.json` (subtitrările iau fontul, culorile și numărul de cuvinte din identitatea omului; `--preset lejer|tech|dinamic|neurolab` doar dacă stilul de montaj cere altă poziție/ritm)
   Inserțiile (B-roll, carduri de capitol, zoom-uri) din fișierul stilului nu le face render.py: le pui în draft-ul CapCut sau le listezi în taieturi.md cu secunda exactă, ca omul să le adauge în CapCut.
4. Copertă: `python3 scripts/cover.py output/<dir>/reel-curat.mp4 --time <secunda cu cea mai bună expresie> --title "<text copertă>" --accent "<cuvântul colorat>" --out output/<dir>/coperta.jpg` — în identitatea omului; textul evită fața automat.
   Alege cadrul uitându-te la 3–4 momente (extrage frame-uri cu ffmpeg și privește-le); ochii deschiși, gura închisă sau zâmbind.
5. Verifici rezultatul: durata finală (ideal 25–45 s), subtitrările au diacritice, hook-ul nu acoperă fața, nimic nu e tăiat la mijloc de cuvânt. Dacă nu, corectezi `cuts.json` și re-randezi.

## Tranzițiile și efectele sonore ÎN mp4 (nu doar în CapCut)
În cuts.json, segmentul care începe o idee nouă primește `"transition": true` (cut_plan.py le marchează singur; adaugi tu unde sensul se schimbă și scriptul n-a prins) → render.py pune o trecere scurtă (dip spre alb, 0,12 s) între segmente. Cu `--sfx inbox/sfx/<sunet>.wav` (sunetul omului, din biblioteca lui, pus de el în folder) se adaugă efectul pe fiecare tranziție. Fără sfx în folder, tranziția e doar vizuală — și îi spui omului că poate pune un sunet în `inbox/sfx/`.

## Proiectul CapCut editabil (doar dacă `setari.json` → video_final = capcut)
Omul vrea să poată retușa în CapCut. Asta înseamnă un PROIECT în lista lui de proiecte, nu un mp4 importat manual. Drumul corect e scrierea fișierelor de proiect, direct:
1. `python3 scripts/capcut_draft.py list` → proiectele existente ale omului. Dacă CapCut nu e găsit, îi spui să-l instaleze/deschidă o dată și continui fără (livrezi mp4 + srt).
2. Alegi ca șablon proiectul omului cel mai apropiat de stilul ales (sau orice proiect al lui dacă e primul) și rulezi:
   `python3 scripts/capcut_draft.py create --template "<proiect>" --video output/<dir>/reel-curat.mp4 --cuts inbox/<video>.cuts.json --name "<Titlu reel> 1.0" --fx-from-template --hits <secunde cuvinte-cheie>`
   Scriptul clonează șablonul (fonturile și stilul lui rămân), pune clipul nou, rescrie segmentele după tăieturi și — cu `--fx-from-template` — pune pe FIECARE tăietură tranziția și efectul sonor din proiectul-șablon (biblioteca CapCut a omului, nu sunete generate), plus un hit sonor la secundele din `--hits` (cuvintele-cheie din script, ex. „fraudă”, „țeapă”, calculate pe cronologia tăiată). Alege ca șablon proiectul omului cu tranzițiile și sunetele care îi plac (ex. cel cu „KF – Cinematic Hit”); dacă șablonul n-are tranziții/efecte, scriptul spune și îi ceri omului un proiect care le are sau le adaugă el în CapCut o singură dată. Nu atinge proiectul original.
3. Subtitrările: deschizi `draft_content.json` din noul proiect, iei ca model un segment de text din proiectul-șablon al omului (păstrezi fontul, mărimea, culoarea) și generezi segmentele de text din `subtitrari.srt`. POZIȚIA nu o iei din șablon: o calculezi din `faces.json`, pentru FIECARE segment de text, după bărbia din intervalul lui: `y = -(2*chin - 1) - 0,12` (în CapCut y negativ = jos, 0 = centru; chin normalizat 0–1 în jos) — adică mereu puțin sub bărbia din momentul respectiv; dacă rezultatul e sub -0,70 (zona butoanelor), pui textul deasupra capului: `y = -(2*head - 1) + 0,12`. Hook-ul: deasupra creștetului din primele 3 secunde. `x` = 0. Nimic între sprâncene și claviculă, niciodată. Dacă e prima dată și n-ai model, omul importă `subtitrari.srt` în CapCut (Text → Import) — îi spui exact asta.
4. Îi spui: „Deschide CapCut: proiectul «…» e în listă.”

NU folosești niciodată Computer use / click-uri în aplicație pentru CapCut. Nu încerci să „apeși butoane”. Dacă scriptul dă eroare, spui exact care și livrezi mp4 + srt + copertă — tot un livrabil complet.

## Când omul aprobă
La „aprobat” (sau orice aprobare clară) pornești imediat `pachet-final`, fără întrebări.

## Ce îi arăți omului
Înainte de livrare faci verificarea din `stiluri/calitate.md` (nicio repetiție, nicio variantă greșită, nicio pauză, tranziții între idei, nimic din ce a adăugat omul tăiat).
Începi mereu cu propoziția: „Gata, am montat. Verifică prima versiune: reel-final.mp4 și cele 4 cadre.” Apoi, pe scurt, ce ai tăiat și unde (secundele din filmare: „0:17 — varianta greșită cu «pe la 3 noaptea», am păstrat-o pe cea de la 0:24”). Apoi: „Spune-mi ce schimbăm — tăiere, culori, texte, tranziții/sunete, muzică.”
- Proiectul CapCut „<Titlu> 1.0” — cu tăieturi strânse, tranziții și sunete din biblioteca lui: ASTA e versiunea de postat când omul are CapCut (export din CapCut)
- `reel-final.mp4` — versiunea curată, gata de postat dacă nu deschide CapCut
- `reel-curat.mp4` + `subtitrari.srt` — „deschide-le în CapCut dacă vrei să retușezi: importă clipul, apoi Text → Import subtitles → .srt”
- `coperta.jpg`
- `taieturi.md` — cu întrebarea: „E vreo tăietură pe care nu o vrei?”

## Memoria de montaj
După aprobare scrii în `fundament/preferinte-montaj.md`, datat: pragul de pauză care i-a plăcut, dacă vrea subtitrări cu majuscule sau nu, poziția textului, cuvintele corectate, ce tăieturi a anulat și de ce. Data viitoare pornești de la ele, nu de la implicit.

## Când ceva nu merge
- faster-whisper lipsește → `pip install faster-whisper`; ffmpeg lipsește → `brew install ffmpeg` (Mac) / `winget install ffmpeg` (Windows).
- Video filmat orizontal: render.py decupează centrul la 9:16; spui omului că a pierdut marginile și că data viitoare filmează vertical.
- Nu simulezi niciodată un rezultat. Dacă nu ai putut randa, spui exact ce a crăpat.

## Progres (PROGRES.md)
Indicator după fiecare pas (transcriere → tăieturi → verificare → montaj → copertă): `▰▰▱▱▱  2 din 5`. Card după montaj și la final, cu VOC din `referinte/` dacă există.
