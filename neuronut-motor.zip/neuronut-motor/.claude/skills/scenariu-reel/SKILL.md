---
name: scenariu-reel
description: Funcția 5 — Scenariul de reel. Scrie scriptul talking-head în vocea omului (din reguli-voce.md și transcrierile lui), cu hook, structură, CTA și indicații de filmare. Folosește după semnal + research, sau când omul cere direct un script pe o idee.
---
# Scenariul de reel

## Înainte să scrii
POARTĂ: există `referinte/<data>-<slug>.md` făcut cu date reale din vidIQ pentru semnalul ăsta? Dacă nu, oprește-te și mergi la skill-ul `research`. Nu scrii scenarii fără referințe. Nu există excepție, nici la cererea omului.

Citești obligatoriu: `fundament/fundament.md`, `fundament/reguli-voce.md`, `referinte/` pentru semnalul respectiv. Fără reguli de voce nu scrii: ceri 2–3 mostre.

## Testul prietenului (înainte de orice script)
Întrebarea care decide dacă scriptul merită filmat: „Ar trimite cineva reel-ul ăsta unui prieten? Cine, cui și cu ce gând?” Răspunzi în scris, sub script, într-o singură propoziție concretă (de exemplu: o antreprenoare care a pierdut un client din cauza prețului îl trimite partenerului de afaceri cu „uite de ce”). Dacă răspunsul e vag sau e „oricine, pentru că e util”, rescrii hook-ul și miezul până devine concret. Dacă `fundament/indicatori.md` există, folosești ce a învățat deja contul omului (ce i-a fost trimis mai departe, unde se pierde atenția).

## Structura scriptului (30–60 s vorbit, 90–150 de cuvinte)
1. HOOK (0–3 s) — o propoziție, din unghiul semnalului; ales dintre hook-urile care au mers în nișă, rescris în vocea lui. Scrii 3 variante, recomanzi una.
2. CONTEXT (3–10 s) — situația reală, ca în viață, nu ca în reclamă. Doar ce a spus omul.
3. MIEZUL (10–40 s) — ideea centrală + de ce îi pasă clientului + dovada (dacă există în Fundament).
4. CTA (ultimele 5 s) — un singur pas următor, potrivit deciziei: ATTRACT → urmărește / salvează / comentează un cuvânt; CONVERT → scrie-mi „X” / link în bio / întrebarea care deschide DM-ul.

## Cum arată livrarea
```
# Reel: <titlu de lucru>
Semnal: … · Decizie: ATTRACT/CONVERT · Unghi: …
Hook (3 variante, ★ recomandată): …
--- SCRIPT (citește-l natural, nu-l memora) ---
[hook] …
[context] …
[miez] …
[cta] …
--- MARCAJE PENTRU MONTAJ ---
[hit] după cuvântul-cheie pe care vrem efect sonor (max 2–3 pe reel)
--- TEXT PE ECRAN ---
Hook pe ecran (max 8 cuvinte): …
Copertă (max 6 cuvinte): …
--- FILMARE ---
Cadru: vertical, de la piept în sus, ochii în treimea de sus. Lumină din față (fereastră). Telefonul la nivelul ochilor.
Ton: ca și cum i-ai explica unui client la o cafea. O singură luare bună e de ajuns; dacă greșești, repeți propoziția, nu tot clipul — montajul taie.
```
**Livrarea se face ÎN CHAT, complet, în formatul de mai sus** — hook cu cele 3 variante și cea recomandată, scriptul pe secțiuni, textul pe ecran, coperta, regia de filmare. Omul citește scriptul aici și îl aprobă aici. Nu-i spui „l-am scris în script.md” ca rezumat. Fișierul `output/<data>-<slug>/script.md` e doar copia.
Golurile ([GOL]) le pui în script, vizibile, și le întrebi pe toate într-un singur mesaj la final — nu una câte una.

## Reguli de voce (în plus față de reguli-voce.md)
- Fraze scurte, ritm de vorbire, nu de scris. Fără „în acest articol”, fără „haide să vedem”, fără liste în vorbire.
- Fără metafore traduse din engleză („game changer”, „la nivelul următor”). Dacă ai nevoie de o imagine, e din limba română vie.
- Niciun fapt despre om care nu e în Fundament. Lipsește → `[GOL: …]` și întrebi înainte să livrezi.
- După ce omul corectează scriptul, scrii în `fundament/reguli-voce.md` o regulă scurtă, datată, cu ce ai învățat („nu spune „clienți”, spune „oamenii cu care lucrez” — 21.10”).

## Feedback vag → întrebi, nu rescrii
Întâi `fundament/reguli-voce.md` → „Feedback vag: întreabă înainte să rescrii”. Feedback vag (adjective fără exemplu, versiuni după număr, 2+ direcții deodată) = nu rescrii; rezumi miezul, arăți hook-urile versiunilor, pui max 2 întrebări. Feedback concret = aplici direct.
