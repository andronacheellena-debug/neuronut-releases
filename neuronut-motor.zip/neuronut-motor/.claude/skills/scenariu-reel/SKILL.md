---
name: scenariu-reel
description: Funcția 5 — Scenariul de reel. Din dictarea omului (brainstorm brut, pe voce) construiește un singur text gata de citit în cameră, în vocea lui, după fluxul Elenei din stiluri/scriere.md: mesajul zilei → dictare → structură → punți → redactare → lungime. Folosește după semnal + research, după alegerea ideii din provocare, sau când omul cere direct un script.
---
# Scenariul de reel

## Înainte să scrii
POARTĂ: există `referinte/<data>-<slug>.md` (sau `referinte/ziua-N.md` în provocare) făcut cu date reale din vidIQ? Dacă nu, mergi întâi la skill-ul `research`. Din referințe iei formatul și felul în care se deschide reel-ul, nu textul.

Citești obligatoriu, în ordinea asta:
1. `stiluri/scriere.md` — regulile Elenei pentru orice text. Le aplici întocmai.
2. `fundament/reguli-voce.md` (profilul de voce) și `fundament/corecturi.md` (dacă există).
3. `fundament/fundament.md`, referințele și, doar dacă `fundament/provocare.json` are `"mod": "neurocreator"`, ziua din provocare.

## Fluxul (detaliat în `stiluri/scriere.md`)
1. **Mesajul zilei** — propoziția ta „La final, omul care privește înțelege că ___, iar îi spunem asta azi pentru că ___.” O scrii pentru tine; dacă nu reiese, o singură întrebare către om.
2. **Dictarea** — nu scrii textul până nu dictează omul. Întâi cauți în ce a spus deja. Dacă lipsește, 2–3 întrebări simple, legate de zi și de ideea aleasă, la care răspunde pe voce, ca unei prietene. Închei cu: „Răspunde cu voce, liber, nu trebuie să fie ordonat. Eu fac ordinea.”
3. **Structura** — situație reală sau cifră → reacția lui sinceră → contextul pe scurt (cu termenii explicați) → drumul gândului → redeschiderea curiozității → întoarcerea spre privitor, cu întrebări → o deschidere și invitația la conversație. În modul provocare, invitația zilei, neschimbată; în modul obișnuit, o invitație din ce a spus omul, fără nimic din provocare (vezi „Două moduri” în `stiluri/scriere.md`).
4. **Punțile** — construiești legăturile pe care dictarea le-a sărit (întrebări, tensiune, completări de sens). Faptele nu le construiești.
5. **Redactarea** — vocea lui, ca după un curs de dicție.
6. **Lungimea** — 130–150 de cuvinte pe minut: 200–230 pentru 90 de secunde, cel mult 400–450 pentru 3 minute. Tai repetițiile, nu punțile.

## Testul prietenului (înainte să livrezi)
„Ar trimite cineva reel-ul ăsta unui prieten? Cine, cui și cu ce gând?” Răspunsul, într-o propoziție concretă, sub text. Dacă e vag („oricine, e util”), refaci deschiderea și miezul până devine concret. Dacă `fundament/indicatori.md` există, folosești ce a învățat contul omului.

## Cum arată livrarea (în chat, complet)
```
# Reel: <titlu de lucru>
Mesajul zilei: …
--- TEXTUL (citește-l cu voce tare, natural) ---
…un singur text, cu paragrafe după respirație…
--- CE AM CORECTAT SAU DEDUS DIN DICTARE ---
- „…” → am înțeles „…” (eroare de transcriere)
- am adăugat puntea „…” între … și …
--- O ÎNTREBARE DE CONFIRMAT (cel mult una) ---
…
Testul prietenului: …
--- PENTRU MONTAJ ---
Titlul pe ecran (max 8 cuvinte): …
Copertă (max 6 cuvinte): …
Filmare: vertical, de la piept în sus, lumină din față, telefonul la nivelul ochilor. Dacă greșești, repeți propoziția, nu tot clipul — montajul păstrează varianta bună.
```
Un singur text, fără variante. Golurile ([GOL: …]) rămân vizibile în text; dacă sunt mai multe, le întrebi pe toate într-un singur mesaj. Copia merge în `output/<data>-<slug>/script.md`.

## După livrare
- Omul corectează → aplici; perechea „eu am scris → el a spus” intră în `fundament/corecturi.md`, datată, și regula scurtă în `fundament/reguli-voce.md`.
- Omul îți trimite varianta lui → urmezi „Când omul îți trimite varianta lui” din `stiluri/scriere.md` (3–5 puncte cu ce a adus el în plus, păstrate în profil cu acordul lui).
- Feedback vag (adjective fără exemplu, mai multe direcții deodată) → nu rescrii; rezumi miezul și pui cel mult 2 întrebări (`feedback`). Feedback concret → aplici direct.
