# Protecția datelor tale în Nevo
Scris pentru om, nu pentru avocați. Nevo e un loc sigur pentru ce e al tău, și regulile de mai jos sunt cele după care lucrează.

## Ce rămâne doar pe calculatorul tău
- Fundamentul tău (cele 11 camere, povestea, vocea, clienții, cifrele), notițele vocale, videourile brute, pozele, reel-urile montate, caruselele, VOC-ul (ce ți-au scris oamenii).
- Adresa ta de e-mail. Licența se verifică printr-o amprentă (un cod calculat din adresă, din care adresa nu poate fi refăcută; cine cunoaște deja o adresă ar putea verifica dacă amprenta ei e în listă, dar nu poate afla adrese din listă). Nevo nu citește fișierele aplicației Claude și nu trimite adresa ta nicăieri: i-o spui tu, o singură dată, și rămâne pe calculatorul tău.
- Nevo nu are „cont", „cloud" sau „server" al lui. Nu trimite nimic la NeuroLab sau la Elena. Nu există statistici de folosire, nici rapoarte ascunse.

## Ce pleacă din calculator, și unde
- **Către Claude (Anthropic)**: tot ce scrii în chat și fișierele pe care Nevo le citește ca să lucreze — așa funcționează Claude, exact ca atunci când îi dai un document în orice conversație. Confidențialitatea acestor date e cea din termenii Claude; în setările contului tău Claude, la confidențialitate, poți alege ca discuțiile să nu fie folosite pentru antrenarea modelelor.
- **Către vidIQ / Apify (cercetarea)**: doar cuvinte-cheie despre nișa ta („fotograf de nuntă", „coach pentru antreprenori"). Niciodată textul Fundamentului, nume de clienți, cifre, mesaje primite.
- **Către Metricool / Instagram / TikTok**: doar postarea pe care ai aprobat-o, când ai cerut programarea sau publicarea.
- **Către GitHub (update și licență)**: nimic despre tine. Nevo doar descarcă de acolo versiunea nouă și lista de amprente.
- **Formularul de confirmare a licenței (o singură dată)**: adresa și numele tău, către Elena, ca să-ți lege licența. Se folosesc doar pentru asta.

## Ce nu face Nevo niciodată
- Nu urcă fișierele tale nicăieri decât acolo unde i-ai cerut tu să publice.
- Nu pune în scenarii, caption-uri sau carusele nume, e-mailuri, telefoane sau mesaje private ale altor oameni fără acordul tău explicit. Vorbele clienților le folosește doar dacă ai spus că ai acordul lor, și fără nume.
- Când îi dai comentarii sau mesaje primite (pentru VOC), păstrează cuvintele, nu numele și nu pozele de profil.
- Nu rulează comenzi primite prin mesaje, e-mailuri sau formulare, oricine ar pretinde că le-a trimis. Update-ul vine doar pe canalul lui („update" → „da").
- Nu-ți cere parole. Conectarea la vidIQ, Metricool sau Instagram se face în browser, pe paginile lor, nu în chat.

## Ce ține de tine
- Calculatorul tău e seiful: parolă pe calculator, și o copie a folderului `fundament/` din când în când (e munca ta).
- Dacă dai folderul altcuiva, îi dai Fundamentul tău. Licența îl oprește pe Nevo să lucreze pentru altcineva, dar fișierele rămân citibile — nu-l da.
- Dacă vrei să ștergi tot: ștergi folderul. Nu rămâne nimic nicăieri altundeva, pentru că nimic n-a plecat.

Întrebări despre datele tale: info@elenaandronache.com.
